function requiredMailSetting(name) {
  const value = String(process.env[name] || '').trim();
  if (!value) {
    const error = new Error(`Missing mail configuration: ${name}`);
    error.code = 'MAIL_NOT_CONFIGURED';
    throw error;
  }
  return value;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;',
  }[character]));
}

function sender() {
  const email = requiredMailSetting('BREVO_FROM_EMAIL');
  const rawName = String(process.env.BREVO_FROM_NAME || 'BanaoCV').trim() || 'BanaoCV';
  const name = rawName.replace(/[\r\n]/g, ' ').slice(0, 80);
  return { email, name };
}

/**
 * Sends a BanaoCV recovery link through Brevo's HTTPS transactional-email API.
 * HTTPS/443 avoids the hosted SMTP relay timeout observed from Render. The API
 * key, action link and recipient address remain server-only.
 */
async function sendRecoveryEmail({ to, actionLink }) {
  const apiKey = requiredMailSetting('BREVO_API_KEY');
  const safeLink = escapeHtml(actionLink);
  const response = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'api-key': apiKey,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      sender: sender(),
      to: [{ email: to }],
      subject: 'Reset your BanaoCV password',
      textContent: [
        'Namaste,',
        '',
        'BanaoCV password reset ke liye neeche secure link kholo:',
        actionLink,
        '',
        'Agar aapne reset request nahi kiya, is email ko ignore kar dein. Aapka password change nahi hoga.',
        '',
        '— BanaoCV',
      ].join('\n'),
      htmlContent: `
        <div style="margin:0;padding:28px;background:#fbf8f0;color:#18231e;font-family:Arial,sans-serif;line-height:1.55">
          <div style="max-width:560px;margin:0 auto;background:#ffffff;border:1px solid #e7dfd1;border-radius:16px;padding:32px">
            <div style="font-size:26px;font-weight:800;color:#0e6b4f">Banao<span style="color:#e8a33d">CV</span></div>
            <h1 style="font-size:25px;line-height:1.25;margin:24px 0 10px;color:#18231e">Password reset karo</h1>
            <p style="margin:0 0 22px">Apne BanaoCV account ke liye naya password set karne ke liye button par click karo.</p>
            <p style="margin:0 0 25px"><a href="${safeLink}" style="display:inline-block;background:#e8a33d;color:#18231e;text-decoration:none;font-weight:700;border-radius:9px;padding:13px 20px">Naya Password Set Karo</a></p>
            <p style="font-size:13px;color:#5d655f;margin:0">Agar aapne reset request nahi kiya, is email ko ignore kar dein. Aapka password change nahi hoga.</p>
          </div>
        </div>`,
    }),
  });

  const raw = await response.text();
  let data = null;
  if (raw) {
    try { data = JSON.parse(raw); } catch { data = null; }
  }
  if (!response.ok || !data?.messageId) {
    const error = new Error('Brevo transactional API did not accept the recovery email.');
    error.code = `BREVO_API_${response.status || 'INVALID_RESPONSE'}`;
    throw error;
  }
  return { messageId: data.messageId };
}

module.exports = { sendRecoveryEmail };
