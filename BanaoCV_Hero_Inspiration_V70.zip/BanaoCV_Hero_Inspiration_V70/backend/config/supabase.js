const { createClient } = require('@supabase/supabase-js');

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

const supabaseUrl = required('SUPABASE_URL');
const supabaseServiceKey = required('SUPABASE_SERVICE_KEY');
const supabaseAnonKey = required('SUPABASE_ANON_KEY');

// Service-role client: backend only. It bypasses RLS and must never be sent to a browser.
const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false, flowType: 'implicit' },
});

// Anon client is used for normal Supabase Auth flows (signup, OTP, password reset).
function createAuthClient() {
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: { autoRefreshToken: false, persistSession: false, flowType: 'implicit' },
  });
}

// Normal auth client is used for signup, OTP, login and recovery-session updates.
// A dedicated client is still created for every final password update so recovery
// sessions are never shared between concurrent requests.
const supabaseAuth = createAuthClient();

/**
 * Lists Auth users via the GoTrue Admin HTTP API without relying on the SDK's
 * response parser. This avoids an AuthUnknownError seen on the hosted runtime
 * while preserving the service-role credential on the backend only.
 */
async function listAuthUsersPage(page = 1, perPage = 1000) {
  const target = new URL(`${supabaseUrl.replace(/\/$/, '')}/auth/v1/admin/users`);
  target.searchParams.set('page', String(page));
  target.searchParams.set('per_page', String(perPage));

  const response = await fetch(target, {
    headers: {
      apikey: supabaseServiceKey,
      Authorization: `Bearer ${supabaseServiceKey}`,
      'X-Client-Info': 'banaocv-backend',
    },
  });
  const raw = await response.text();
  let data = null;
  if (raw) {
    try { data = JSON.parse(raw); } catch { data = null; }
  }

  if (!response.ok || !Array.isArray(data?.users)) {
    const error = new Error('Unable to list Auth users.');
    error.code = `AUTH_ADMIN_${response.status || 'INVALID_RESPONSE'}`;
    throw error;
  }
  return data.users;
}

module.exports = { supabaseAdmin, supabaseAuth, createAuthClient, listAuthUsersPage };
