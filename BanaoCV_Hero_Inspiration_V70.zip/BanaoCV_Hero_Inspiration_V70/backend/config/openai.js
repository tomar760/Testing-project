const OpenAI = require('openai');

/**
 * Private server-side AI provider configuration.
 * Current supported providers: NVIDIA, Groq and future OpenAI.
 * No key is ever sent to browser code, GitHub or logs.
 */
function getAI() {
  const provider = (process.env.AI_PROVIDER || 'nvidia').trim().toLowerCase();
  const timeoutMs = Number(process.env.AI_TIMEOUT_MS || 45000);
  const maxTokens = Number(process.env.AI_MAX_TOKENS || 1400);

  if (provider === 'nvidia') {
    if (!process.env.NVIDIA_API_KEY) {
      const error = new Error('NVIDIA AI key abhi configured nahi hai. AI feature baad mein try karo.');
      error.code = 'AI_KEY_MISSING';
      throw error;
    }
    return {
      provider,
      apiKey: process.env.NVIDIA_API_KEY,
      baseURL: (process.env.NVIDIA_BASE_URL || 'https://integrate.api.nvidia.com/v1').replace(/\/$/, ''),
      model: process.env.NVIDIA_MODEL || 'meta/llama-3.3-70b-instruct',
      timeoutMs,
      maxTokens,
      supportsJsonMode: false,
    };
  }

  if (provider === 'groq') {
    if (!process.env.GROQ_API_KEY) {
      const error = new Error('Groq AI key abhi configured nahi hai. AI feature baad mein try karo.');
      error.code = 'AI_KEY_MISSING';
      throw error;
    }
    return {
      provider,
      apiKey: process.env.GROQ_API_KEY,
      // Groq is OpenAI-compatible. Defaults mean Render needs only AI_PROVIDER and GROQ_API_KEY.
      baseURL: (process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/$/, ''),
      model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
      timeoutMs,
      maxTokens,
      // JSON is enforced through prompts/parse validation for widest Groq model compatibility.
      supportsJsonMode: false,
    };
  }

  if (provider === 'openai') {
    if (!process.env.OPENAI_API_KEY) {
      const error = new Error('OpenAI key abhi configured nahi hai. Private provider setup check karo.');
      error.code = 'AI_KEY_MISSING';
      throw error;
    }
    return {
      provider,
      client: new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: timeoutMs, maxRetries: 0 }),
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      timeoutMs,
      maxTokens,
      supportsJsonMode: true,
    };
  }

  const error = new Error(`Unsupported AI provider: ${provider}. NVIDIA, Groq ya OpenAI choose karo.`);
  error.code = 'AI_PROVIDER_INVALID';
  throw error;
}

function providerError(provider, status, providerMessage) {
  const label = provider === 'groq' ? 'Groq' : 'NVIDIA';
  const messages = {
    400: `${label} request/model valid nahi hai. Model setting check karo.`,
    401: `${label} AI key verify nahi hui. Private Render key check karo.`,
    403: `${label} provider access available nahi hai.`,
    404: `${label} model available nahi hai. Exact model slug check karo.`,
    429: `${label} free usage limit active hai. Thodi der baad retry karo.`,
    500: `${label} service abhi response nahi de rahi. Baad mein try karo.`,
    503: `${label} service temporarily unavailable hai. Baad mein try karo.`,
  };
  const error = new Error(messages[status] || `${label} AI request complete nahi ho payi. Baad mein try karo.`);
  error.status = status || 502;
  error.code = `${label.toUpperCase()}_${status || 'REQUEST_FAILED'}`;
  // Provider diagnostics stay server-only and are never returned in normal browser errors.
  error.providerMessage = providerMessage || '';
  return error;
}

async function compatibleCompletion(ai, request) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ai.timeoutMs);
  try {
    const response = await fetch(`${ai.baseURL}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${ai.apiKey}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ...request, stream: false }),
      signal: controller.signal,
    });
    const raw = await response.text();
    let payload = null;
    if (raw) {
      try { payload = JSON.parse(raw); } catch { payload = null; }
    }
    if (!response.ok) {
      const providerMessage = payload?.detail || payload?.message || payload?.error?.message || payload?.error || raw.slice(0, 300);
      throw providerError(ai.provider, response.status, providerMessage);
    }
    if (!payload?.choices?.[0]?.message?.content) {
      throw providerError(ai.provider, 502, `${ai.provider} returned no completion content.`);
    }
    return payload;
  } catch (error) {
    if (error.name === 'AbortError') {
      const label = ai.provider === 'groq' ? 'Groq' : 'NVIDIA';
      const timeout = new Error(`${label} AI response timeout ho gaya. Thodi der baad try karo.`);
      timeout.status = 504;
      timeout.code = `${label.toUpperCase()}_TIMEOUT`;
      throw timeout;
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function createChatCompletion(ai, request) {
  if (ai.provider === 'nvidia' || ai.provider === 'groq') return compatibleCompletion(ai, request);
  return ai.client.chat.completions.create(request);
}

module.exports = { getAI, createChatCompletion };
