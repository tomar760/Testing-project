/* One-command NVIDIA diagnostic. Never print API keys. */
require('dotenv').config();
const { getAI, createChatCompletion } = require('./config/openai');

(async () => {
  try {
    const ai = getAI();
    if (ai.provider !== 'nvidia') throw new Error('AI_PROVIDER ko nvidia set karo before NVIDIA test.');
    console.log(`Testing provider: ${ai.provider}`);
    console.log(`Testing base: ${ai.baseURL}`);
    console.log(`Testing model: ${ai.model}`);
    const response = await createChatCompletion(ai, {
      model: ai.model,
      messages: [
        { role: 'system', content: 'Reply in exactly one word.' },
        { role: 'user', content: 'Reply: READY' },
      ],
      temperature: 0,
      max_tokens: 20,
    });
    console.log('AI TEST SUCCESS:', response.choices?.[0]?.message?.content || '(empty response)');
  } catch (error) {
    console.error('AI TEST FAILED');
    console.error('Status:', error.status || 'unknown');
    console.error('Code:', error.code || 'unknown');
    console.error('Message:', error.message || error);
    if (error.providerMessage) console.error('Provider detail:', error.providerMessage);
    process.exitCode = 1;
  }
})();
