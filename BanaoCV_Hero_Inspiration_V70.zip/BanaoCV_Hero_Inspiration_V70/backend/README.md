# BanaoCV Backend — Foundation v1

This is the structured backend created from the flat source files. It is the first implementation step toward real login, resume autosave and recovery of incomplete drafts on the user dashboard.

## What works at the API layer

- Supabase email signup, OTP verification, login and password-reset email request
- Signed 7-day BanaoCV JWT after login/verification
- Authenticated resume create, list, load, update/autosave and delete APIs
- Provider-selectable AI endpoints for Hindi/Hinglish resume drafting, score, JD match and cover letters (NVIDIA Build/NIM for local testing; production provider later)
- Razorpay order creation plus server-side payment signature/order verification
- Supabase schema for profiles, resumes, payments and AI/template usage
- Helmet, strict CORS allowlist, JSON size limit and API/auth/AI rate limits

## Required setup

1. Create a Supabase project.
2. In **SQL Editor**, run `schema.sql` in full.
3. In Supabase **Authentication → Providers → Email**, enable email provider and email confirmation. Configure the email template to expose an OTP/code if the product keeps the current OTP UI.
4. Copy `.env.example` to `.env`; fill all real values. Never put this file in Git or send the service-role key to the frontend.
5. Run:

```bash
npm install
npm run check
npm run dev
```

The local health URL is `http://localhost:5000/api/health`.

## Environment variables

| Name | Used for |
|---|---|
| `FRONTEND_URL` | Comma-separated allowed frontend origins |
| `JWT_SECRET` | BanaoCV API session tokens |
| `SUPABASE_URL`, `SUPABASE_ANON_KEY` | Supabase normal authentication flows |
| `SUPABASE_SERVICE_KEY` | Backend-only database/admin access |
| `NVIDIA_API_KEY` | One NVIDIA Build/NIM development/test key (do not use free developer endpoint as live production runtime) |
| `AI_PROVIDER`, `NVIDIA_MODEL` | AI provider/model selection for testing |
| `OPENAI_API_KEY` | Optional future production AI provider |
| `RAZORPAY_*` | Checkout and payment verification |
| `CLOUDINARY_*` | Reserved for a later photo upload endpoint |

## Current API contract

### Auth

```text
POST /api/auth/signup              { name, email, password }
POST /api/auth/login               { email, password }
POST /api/auth/verify-otp          { email, otp }
POST /api/auth/forgot-password     { email }
POST /api/auth/reset-password      { access_token, refresh_token, password }
GET  /api/auth/me                  Authorization: Bearer <token>
```

### Resumes — all require Bearer token

```text
GET    /api/resume
GET    /api/resume/:id
POST   /api/resume                 { title, template_slug, content, design, completion_percent }
PUT    /api/resume/:id             partial autosave payload
DELETE /api/resume/:id
```

The dashboard will call `GET /api/resume`, sort by `updated_at`, and show the most recently edited draft as **Continue editing**. This is the persistence behavior requested for unfinished resumes.

### AI — all require Bearer token

```text
POST /api/ai/hindi-to-resume       { text }
POST /api/ai/score                 { resumeData }
POST /api/ai/jd-match              { resumeData, jobDescription }
POST /api/ai/cover-letter          { resumeData, company, role, tone }
```

### Payments — all require Bearer token

```text
POST /api/payment/create-order     { plan: premium | pro_monthly | pro_annual }  # ₹79 launch Premium (₹99 regular later), ₹249/month Pro, ₹1,799/year Pro
POST /api/payment/verify           Razorpay checkout response + plan
POST /api/payment/webhook          Razorpay server webhook (raw body)
```

## What is deliberately next

The static frontend has not been wired to these live APIs yet.

## NVIDIA test setup

For local development, set `AI_PROVIDER=nvidia`, add one NVIDIA key to `NVIDIA_API_KEY`, and confirm a compatible model slug in `NVIDIA_MODEL`. Requests have a 45-second test timeout by default so an unavailable free endpoint returns an error instead of making the editor load forever. NVIDIA Build/NIM developer access is for development/testing only. Do not put the key in GitHub or use multiple free keys to bypass quotas. The server will start without an AI key, but AI endpoints will return a configuration error until one is added. The next coding phase is frontend auth and resume persistence:

1. add a shared browser API client/token store;
2. connect login/signup;
3. create a resume from a selected template;
4. autosave editor content after a short debounce;
5. load recent drafts on dashboard with completion percentage and Continue Editing;
6. then polish dashboard/editor/templates around real data.

## Deployment shape

```text
Frontend static files  → Vercel
Express API            → Render or Railway
Database/Auth          → Supabase
Payments               → Razorpay
```
