const express = require('express');
const { verifyToken } = require('../middleware/auth');
const { requireTemplateEntitlement, requireExistingResumeEntitlement } = require('../middleware/plan');
const controller = require('../controllers/resumeController');

const router = express.Router();
router.use(verifyToken);
router.get('/', controller.listResumes);
router.get('/:id', requireExistingResumeEntitlement, controller.getResume);
router.post('/', requireTemplateEntitlement, controller.createResume);
router.put('/:id', requireExistingResumeEntitlement, controller.updateResume);
router.delete('/:id', controller.deleteResume);
module.exports = router;
