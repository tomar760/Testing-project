const express = require('express');
const multer = require('multer');
const { verifyToken } = require('../middleware/auth');
const {
  getProfile, updateProfile, uploadProfilePhoto, removeProfilePhoto,
  downloadMyData, getDeletionRequest, createDeletionRequest, cancelDeletionRequest,
} = require('../controllers/profileController');

const router = express.Router();
const uploader = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024, files: 1 } });

function photoUpload(req, res, next) {
  uploader.single('photo')(req, res, (error) => {
    if (!error) return next();
    return res.status(400).json({ error: 'Photo JPG, PNG ya WebP aur maximum 4 MB honi chahiye.' });
  });
}

router.use(verifyToken);
router.get('/', getProfile);
router.put('/', updateProfile);
router.post('/photo', photoUpload, uploadProfilePhoto);
router.delete('/photo', removeProfilePhoto);
router.get('/export', downloadMyData);
router.get('/deletion-request', getDeletionRequest);
router.post('/deletion-request', createDeletionRequest);
router.post('/deletion-request/cancel', cancelDeletionRequest);
module.exports = router;
