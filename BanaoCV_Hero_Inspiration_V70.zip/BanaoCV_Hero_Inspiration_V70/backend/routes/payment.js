const express = require('express');
const { verifyToken } = require('../middleware/auth');
const { createOrder, verifyPayment, paymentHistory, ownPaymentReceipt, ownPaymentReceiptPdf, billingChangeRequest, getBillingChangeRequest, cancelBillingChangeRequest } = require('../controllers/paymentController');

const router = express.Router();
router.use(verifyToken);
router.get('/history', paymentHistory);
router.get('/billing-change-request', getBillingChangeRequest);
router.post('/billing-change-request', billingChangeRequest);
router.post('/billing-change-request/cancel', cancelBillingChangeRequest);
router.get('/:id/receipt', ownPaymentReceipt);
router.get('/:id/receipt.pdf', ownPaymentReceiptPdf);
router.post('/create-order', createOrder);
router.post('/verify', verifyPayment);
module.exports = router;
