const express = require('express');
const controller = require('../controllers/companyController');

const router = express.Router();
router.get('/:id', controller.publicCompany);

module.exports = router;
