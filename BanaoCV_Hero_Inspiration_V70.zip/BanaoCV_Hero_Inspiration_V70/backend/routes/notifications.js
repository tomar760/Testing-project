const express = require('express');
const { verifyToken } = require('../middleware/auth');
const controller = require('../controllers/notificationController');

const router = express.Router();
router.use(verifyToken);
router.get('/', controller.listNotifications);
router.patch('/read-all', controller.markAllNotificationsRead);
router.patch('/:id/read', controller.markNotificationRead);

module.exports = router;
