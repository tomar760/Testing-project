const express = require('express');
const { verifyToken } = require('../middleware/auth');
const controller = require('../controllers/jobController');

const router = express.Router();
router.get('/', controller.publicJobs);
router.get('/saved', verifyToken, controller.listSavedJobs);
router.get('/:id', controller.publicJob);
router.post('/:id/save', verifyToken, controller.saveJob);
router.delete('/:id/save', verifyToken, controller.removeSavedJob);
router.post('/:id/apply', verifyToken, controller.applyToJob);
module.exports = router;
