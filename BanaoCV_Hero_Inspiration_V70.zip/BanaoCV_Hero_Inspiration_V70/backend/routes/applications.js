const express = require('express');
const { verifyToken } = require('../middleware/auth');
const controller = require('../controllers/applicationController');

const router = express.Router();
router.use(verifyToken);
router.get('/', controller.listApplications);
router.get('/summary', controller.applicationSummary);
router.get('/:id/timeline', controller.applicationTimeline);
router.post('/', controller.createApplication);
router.post('/:id/withdraw', controller.withdrawEmployerApplication);
router.put('/:id', controller.updateApplication);
router.delete('/:id', controller.deleteApplication);
module.exports = router;
