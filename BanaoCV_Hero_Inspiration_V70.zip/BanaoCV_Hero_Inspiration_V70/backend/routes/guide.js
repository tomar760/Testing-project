const express = require('express');
const { verifyToken } = require('../middleware/auth');
const { guideLimiter } = require('../middleware/rateLimit');
const controller = require('../controllers/guideController');

const router = express.Router();
router.use(verifyToken, guideLimiter);
router.post('/chat', controller.guideChat);

module.exports = router;
