const express = require('express');
const { verifyToken } = require('../middleware/auth');
const { aiLimiter } = require('../middleware/rateLimit');
const controller = require('../controllers/aiController');

const router = express.Router();
router.use(verifyToken, aiLimiter);
router.post('/hindi-to-resume', controller.hindiToResume);
router.post('/score', controller.analyzeScore);
router.post('/jd-match', controller.jdMatch);
router.post('/cover-letter', controller.coverLetter);
router.post('/guided-interview/questions', controller.guidedInterviewQuestions);
router.post('/guided-interview/generate', controller.guidedContentGenerate);
module.exports = router;
