const express = require('express');
const { verifyToken } = require('../middleware/auth');
const controller = require('../controllers/safetyController');

const router = express.Router();
router.post('/reports', verifyToken, controller.createSafetyReport);

module.exports = router;
