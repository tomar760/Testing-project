const express = require('express');
const { verifyToken } = require('../middleware/auth');
const {
  requireAdminAccess,
  requireFullAdmin,
  requireSuperAdmin,
  requireSupportAccess,
} = require('../middleware/admin');
const controller = require('../controllers/adminController');
const safetyController = require('../controllers/safetyController');

const router = express.Router();
router.use(verifyToken, ...requireAdminAccess);

router.get('/me', controller.getAdminMe);
router.get('/overview', requireFullAdmin, controller.getOverview);
router.get('/users', requireFullAdmin, controller.listUsers);
router.patch('/users/:id/role', requireSuperAdmin, controller.updateUserRole);
router.patch('/users/:id/plan', requireSuperAdmin, controller.updateUserPlan);
router.get('/resumes', requireFullAdmin, controller.listResumes);
router.get('/applications', requireFullAdmin, controller.listApplications);
router.get('/payments', requireFullAdmin, controller.listPayments);
router.get('/payments/:id/receipt', requireFullAdmin, controller.adminPaymentReceipt);
router.get('/payments/:id/receipt.pdf', requireFullAdmin, controller.adminPaymentReceiptPdf);
router.get('/support', requireSupportAccess, controller.listTickets);
router.patch('/support/:id', requireSupportAccess, controller.updateTicket);
router.get('/deletion-requests', requireFullAdmin, controller.listDeletionRequests);
router.patch('/deletion-requests/:id', requireSuperAdmin, controller.updateDeletionRequest);
router.get('/billing-change-requests', requireFullAdmin, controller.listBillingChangeRequests);
router.patch('/billing-change-requests/:id', requireSuperAdmin, controller.updateBillingChangeRequest);
router.get('/employers', requireFullAdmin, controller.listEmployers);
router.patch('/employers/:id', requireSuperAdmin, controller.updateEmployerStatus);
router.get('/employer-jobs', requireFullAdmin, controller.listEmployerJobsAdmin);
router.get('/safety-reports', requireFullAdmin, safetyController.listSafetyReports);
router.patch('/safety-reports/:id', requireSuperAdmin, safetyController.updateSafetyReport);
router.patch('/employer-jobs/:id', requireSuperAdmin, controller.updateEmployerJobAdmin);
router.get('/templates', requireFullAdmin, controller.listTemplates);
router.patch('/templates/:slug', requireFullAdmin, controller.updateTemplate);
router.get('/system', requireFullAdmin, controller.getSystem);
router.get('/audit-logs', requireFullAdmin, controller.listAuditLogs);
router.get('/export/:type', requireFullAdmin, controller.exportData);

module.exports = router;
