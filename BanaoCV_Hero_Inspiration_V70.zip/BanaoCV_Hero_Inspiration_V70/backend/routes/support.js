const express = require('express');
const { verifyToken } = require('../middleware/auth');
const { listTickets, createTicket } = require('../controllers/supportController');
const router = express.Router();
router.use(verifyToken);
router.get('/tickets', listTickets);
router.post('/tickets', createTicket);
module.exports = router;
