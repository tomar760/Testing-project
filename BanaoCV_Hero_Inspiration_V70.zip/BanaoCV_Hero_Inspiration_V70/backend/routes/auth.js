const express = require('express');
const { authLimiter, passwordRecoveryLimiter } = require('../middleware/rateLimit');
const { verifyToken } = require('../middleware/auth');
const { signup, login, googleStart, googleSession, resendOtp, verifyOtp, forgotPassword, resetPassword, me } = require('../controllers/authController');

const router = express.Router();
router.post('/signup', authLimiter, signup);
router.post('/login', authLimiter, login);
router.post('/google/start', authLimiter, googleStart);
router.post('/google/session', authLimiter, googleSession);
router.post('/resend-otp', authLimiter, resendOtp);
router.post('/verify-otp', authLimiter, verifyOtp);
router.post('/forgot-password', passwordRecoveryLimiter, forgotPassword);
router.post('/reset-password', authLimiter, resetPassword);
router.get('/me', verifyToken, me);
module.exports = router;
