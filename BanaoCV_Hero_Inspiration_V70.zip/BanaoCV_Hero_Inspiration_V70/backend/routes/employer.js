const express = require('express');
const { verifyToken } = require('../middleware/auth');
const employer = require('../controllers/employerController');
const jobs = require('../controllers/jobController');

const router = express.Router();
router.use(verifyToken);
router.get('/me', employer.getEmployerMe);
router.get('/analytics', employer.getEmployerAnalytics);
router.post('/onboard', employer.onboardEmployer);
router.put('/organization', employer.updateEmployer);
router.get('/jobs', jobs.listEmployerJobs);
router.post('/jobs', jobs.createEmployerJob);
router.put('/jobs/:id', jobs.updateEmployerJob);
router.get('/jobs/:id/submissions', jobs.employerSubmissions);
router.patch('/submissions/:id', jobs.updateSubmission);
router.get('/submissions/:id/resume', jobs.submissionResume);
module.exports = router;
