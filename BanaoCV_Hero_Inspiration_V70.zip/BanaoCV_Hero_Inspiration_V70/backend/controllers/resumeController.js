const { supabaseAdmin } = require('../config/supabase');
const { PREMIUM_TEMPLATE_SLUGS, PAID_PLANS, getUserPlan } = require('../middleware/plan');

const text = (value, max) => typeof value === 'string' && value.trim().length <= max;

function validateCreate(body) {
  if (!text(body.title || 'Untitled Resume', 120)) return 'Resume title valid nahi hai.';
  if (body.template_slug && !text(body.template_slug, 80)) return 'Template valid nahi hai.';
  if (body.content !== undefined && (typeof body.content !== 'object' || Array.isArray(body.content) || body.content === null)) return 'Resume content valid nahi hai.';
  if (body.design !== undefined && (typeof body.design !== 'object' || Array.isArray(body.design) || body.design === null)) return 'Resume design valid nahi hai.';
  return null;
}

async function listResumes(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('resumes')
      .select('id,title,template_slug,content,design,completion_percent,created_at,updated_at')
      .eq('user_id', req.user.id)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    const plan = await getUserPlan(req.user.id);
    const allowedPremium = PAID_PLANS.has(plan);
    const resumes = (data || []).map((resume) => {
      if (PREMIUM_TEMPLATE_SLUGS.has(resume.template_slug) && !allowedPremium) {
        return { ...resume, content: {}, design: {}, locked: true };
      }
      return { ...resume, locked: false };
    });
    return res.json({ resumes });
  } catch (error) { return next(error); }
}

async function getResume(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('resumes').select('*').eq('id', req.params.id).eq('user_id', req.user.id).maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Resume nahi mila.' });
    return res.json({ resume: data });
  } catch (error) { return next(error); }
}

async function createResume(req, res, next) {
  try {
    const invalid = validateCreate(req.body);
    if (invalid) return res.status(400).json({ error: invalid });
    const payload = {
      user_id: req.user.id,
      title: String(req.body.title || 'Untitled Resume').trim(),
      template_slug: req.body.template_slug || 'clean-fresher',
      content: req.body.content || {},
      design: req.body.design || {},
      completion_percent: Number.isFinite(req.body.completion_percent) ? Math.max(0, Math.min(100, Math.round(req.body.completion_percent))) : 0,
    };
    const { data, error } = await supabaseAdmin.from('resumes').insert(payload).select().single();
    if (error) throw error;
    return res.status(201).json({ resume: data });
  } catch (error) { return next(error); }
}

async function updateResume(req, res, next) {
  try {
    const invalid = validateCreate({ ...req.body, title: req.body.title || 'Untitled Resume' });
    if (invalid) return res.status(400).json({ error: invalid });
    const patch = { updated_at: new Date().toISOString() };
    ['title', 'template_slug', 'content', 'design'].forEach((key) => { if (req.body[key] !== undefined) patch[key] = req.body[key]; });
    if (req.body.completion_percent !== undefined) patch.completion_percent = Math.max(0, Math.min(100, Math.round(Number(req.body.completion_percent) || 0)));

    const { data, error } = await supabaseAdmin
      .from('resumes').update(patch).eq('id', req.params.id).eq('user_id', req.user.id).select().maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Resume nahi mila.' });
    return res.json({ resume: data });
  } catch (error) { return next(error); }
}

async function deleteResume(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('resumes').delete().eq('id', req.params.id).eq('user_id', req.user.id).select('id').maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Resume nahi mila.' });
    return res.json({ message: 'Resume delete ho gaya.' });
  } catch (error) { return next(error); }
}

module.exports = { listResumes, getResume, createResume, updateResume, deleteResume };
