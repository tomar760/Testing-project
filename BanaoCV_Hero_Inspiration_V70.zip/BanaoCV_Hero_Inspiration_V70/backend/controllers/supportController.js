const { supabaseAdmin } = require('../config/supabase');

async function listTickets(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('support_tickets')
      .select('id, subject, category, message, status, priority, admin_reply, created_at, updated_at')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return res.json({ tickets: data || [] });
  } catch (error) { return next(error); }
}

async function createTicket(req, res, next) {
  try {
    const subject = String(req.body.subject || '').trim();
    const category = String(req.body.category || 'Other').trim().slice(0, 80);
    const message = String(req.body.message || '').trim();
    if (subject.length < 3 || subject.length > 160 || message.length < 5 || message.length > 5000) {
      return res.status(400).json({ error: 'Subject aur message valid length mein daalo.' });
    }
    const { data, error } = await supabaseAdmin
      .from('support_tickets')
      .insert({ user_id: req.user.id, subject, category, message })
      .select()
      .single();
    if (error) throw error;
    return res.status(201).json({ ticket: data, message: 'Support ticket create ho gaya.' });
  } catch (error) { return next(error); }
}
module.exports = { listTickets, createTicket };
