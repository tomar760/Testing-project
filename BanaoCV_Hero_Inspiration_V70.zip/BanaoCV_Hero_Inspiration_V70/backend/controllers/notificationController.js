const { supabaseAdmin } = require('../config/supabase');

const clean = (value, max) => String(value || '').trim().slice(0, max);

async function listNotifications(req, res, next) {
  try {
    const limit = Math.min(100, Math.max(10, Number(req.query.limit || 50)));
    const [rows, unread] = await Promise.all([
      supabaseAdmin.from('user_notifications')
        .select('id, notification_type, title, message, action_url, metadata, read_at, created_at')
        .eq('user_id', req.user.id)
        .order('created_at', { ascending: false })
        .limit(limit),
      supabaseAdmin.from('user_notifications')
        .select('id', { head: true, count: 'exact' })
        .eq('user_id', req.user.id)
        .is('read_at', null),
    ]);
    if (rows.error) throw rows.error;
    if (unread.error) throw unread.error;
    return res.json({ notifications: rows.data || [], unreadCount: unread.count || 0 });
  } catch (error) { return next(error); }
}

async function markNotificationRead(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data, error } = await supabaseAdmin.from('user_notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('id', id)
      .eq('user_id', req.user.id)
      .select('id, read_at')
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Notification nahi mili.' });
    return res.json({ notification: data, message: 'Notification read mark ho gayi.' });
  } catch (error) { return next(error); }
}

async function markAllNotificationsRead(req, res, next) {
  try {
    const { error } = await supabaseAdmin.from('user_notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('user_id', req.user.id)
      .is('read_at', null);
    if (error) throw error;
    return res.json({ message: 'Saari notifications read mark ho gayi.' });
  } catch (error) { return next(error); }
}

module.exports = { listNotifications, markNotificationRead, markAllNotificationsRead };
