const { supabaseAdmin, listAuthUsersPage } = require('../config/supabase');
const { paymentReceipt } = require('../utils/receipt');
const { createReceiptPdf } = require('../utils/receiptPdf');

const ROLE_VALUES = new Set(['user', 'support_agent', 'admin', 'super_admin']);
const PLAN_VALUES = new Set(['free', 'premium', 'pro_monthly', 'pro_annual']);
const TICKET_STATUSES = new Set(['open', 'in_progress', 'resolved', 'closed']);
const TICKET_PRIORITIES = new Set(['low', 'normal', 'high']);
const DELETION_STATUSES = new Set(['requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled']);
const BILLING_REQUEST_STATUSES = new Set(['requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled']);
const EMPLOYER_STATUSES = new Set(['pending_verification', 'approved', 'rejected', 'suspended']);
const JOB_REVIEW_STATUSES = new Set(['draft', 'pending_review', 'published', 'paused', 'rejected', 'expired']);

const TEMPLATE_CATALOG = [
  ['clean-fresher', 'Clean Fresher', 'Free', 'Fresher'],
  ['govt-formal', 'Govt Formal', 'Free', 'Government'],
  ['golden-line', 'Golden Line', 'Free', 'Fresher'],
  ['corporate-blue', 'Corporate Blue', 'Free', 'Corporate'],
  ['medical-white', 'Medical White', 'Free', 'Healthcare'],
  ['minimal-classic', 'Minimal Classic', 'Free', 'Professional'],
  ['green-minimal', 'Green Minimal', 'Free', 'Fresher'],
  ['dark-pro', 'Dark Pro', 'Premium', 'Professional'],
  ['creative-split', 'Creative Split', 'Premium', 'Creative'],
  ['tech-dark', 'Tech Dark', 'Premium', 'Technology'],
  ['bold-modern', 'Bold Modern', 'Premium', 'Marketing'],
  ['midnight-gold', 'Midnight Gold', 'Premium', 'Executive'],
  ['saffron-bold', 'Saffron Bold', 'Premium', 'Creative'],
  ['navy-sidebar', 'Navy Sidebar', 'Premium', 'Professional'],
  ['pink-creative', 'Pink Creative', 'Premium', 'Creative'],
  ['teal-modern', 'Teal Modern', 'Premium', 'Technology'],
  ['obsidian-executive', 'Obsidian Executive', 'Premium', 'Executive'],
  ['ivory-signature', 'Ivory Signature', 'Premium', 'Professional'],
  ['signal-tech', 'Signal Tech', 'Premium', 'Technology'],
  ['editorial-creative', 'Editorial Creative', 'Premium', 'Creative'],
  ['sapphire-corporate', 'Sapphire Corporate', 'Premium', 'Corporate'],
  ['clinical-precision', 'Clinical Precision', 'Premium', 'Healthcare'],
  ['sales-momentum', 'Sales Momentum', 'Premium', 'Sales'],
  ['creator-portfolio', 'Creator Portfolio', 'Premium', 'Creative'],
];

const cleanText = (value, max = 500) => String(value || '').trim().slice(0, max);
const dayKey = (value) => new Date(value).toISOString().slice(0, 10);
const startOfDaysAgo = (days) => {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - (days - 1));
  return date;
};
const toIso = (date) => date.toISOString();

async function writeAudit(actorId, action, targetType, targetId, metadata = {}) {
  const { error } = await supabaseAdmin.from('admin_audit_logs').insert({
    actor_id: actorId,
    action: cleanText(action, 120),
    target_type: cleanText(targetType, 80),
    target_id: targetId ? String(targetId).slice(0, 180) : null,
    metadata,
  });
  if (error) throw error;
}

async function fetchAllAuthUsers(maxPages = 20) {
  const users = [];
  const perPage = 1000;
  for (let page = 1; page <= maxPages; page += 1) {
    const chunk = await listAuthUsersPage(page, perPage);
    users.push(...chunk);
    if (chunk.length < perPage) break;
  }
  return users;
}

async function buildDirectory() {
  const [authUsers, profileResponse, resumeResponse] = await Promise.all([
    fetchAllAuthUsers(),
    supabaseAdmin.from('profiles').select('id, full_name, phone, location, career_title, plan, role, account_status, created_at, updated_at'),
    supabaseAdmin.from('resumes').select('id, user_id, completion_percent, updated_at'),
  ]);
  if (profileResponse.error) throw profileResponse.error;
  if (resumeResponse.error) throw resumeResponse.error;

  const profiles = new Map((profileResponse.data || []).map((profile) => [profile.id, profile]));
  const resumeStats = new Map();
  (resumeResponse.data || []).forEach((resume) => {
    const current = resumeStats.get(resume.user_id) || { count: 0, bestCompletion: 0, lastResumeAt: null };
    current.count += 1;
    current.bestCompletion = Math.max(current.bestCompletion, Number(resume.completion_percent || 0));
    if (!current.lastResumeAt || new Date(resume.updated_at) > new Date(current.lastResumeAt)) current.lastResumeAt = resume.updated_at;
    resumeStats.set(resume.user_id, current);
  });

  return new Map(authUsers.map((auth) => {
    const profile = profiles.get(auth.id) || {};
    const stats = resumeStats.get(auth.id) || { count: 0, bestCompletion: 0, lastResumeAt: null };
    return [auth.id, {
      id: auth.id,
      email: auth.email || '',
      name: profile.full_name || auth.user_metadata?.name || auth.user_metadata?.full_name || 'BanaoCV member',
      location: profile.location || '—',
      careerTitle: profile.career_title || '—',
      plan: profile.plan || 'free',
      role: profile.role || 'user',
      accountStatus: profile.account_status || 'active',
      createdAt: profile.created_at || auth.created_at || null,
      lastSignInAt: auth.last_sign_in_at || null,
      resumeCount: stats.count,
      bestCompletion: stats.bestCompletion,
      lastResumeAt: stats.lastResumeAt,
    }];
  }));
}

function publicAdminUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    location: user.location,
    careerTitle: user.careerTitle,
    plan: user.plan,
    role: user.role,
    accountStatus: user.accountStatus,
    createdAt: user.createdAt,
    lastSignInAt: user.lastSignInAt,
    resumeCount: user.resumeCount,
    bestCompletion: user.bestCompletion,
    lastResumeAt: user.lastResumeAt,
  };
}

function percentageChange(current, previous) {
  if (!previous) return current ? 100 : 0;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

async function getAdminMe(req, res) {
  return res.json({ admin: req.admin });
}

async function getOverview(req, res, next) {
  try {
    const requestedDays = Number(req.query.days || 30);
    const days = [7, 30, 90].includes(requestedDays) ? requestedDays : 30;
    const currentStart = startOfDaysAgo(days);
    const previousStart = new Date(currentStart);
    previousStart.setDate(previousStart.getDate() - days);
    const now = new Date();

    const [directory, currentProfiles, previousProfiles, currentResumes, previousResumes, currentPayments, previousPayments, ticketResponse, currentTemplateResumes] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('profiles').select('id, created_at').gte('created_at', toIso(currentStart)),
      supabaseAdmin.from('profiles').select('id, created_at').gte('created_at', toIso(previousStart)).lt('created_at', toIso(currentStart)),
      supabaseAdmin.from('resumes').select('id, user_id, completion_percent, template_slug, created_at, updated_at').gte('created_at', toIso(currentStart)),
      supabaseAdmin.from('resumes').select('id, created_at').gte('created_at', toIso(previousStart)).lt('created_at', toIso(currentStart)),
      supabaseAdmin.from('payments').select('id, amount, paid_at, created_at, status, plan').eq('status', 'paid').gte('created_at', toIso(currentStart)),
      supabaseAdmin.from('payments').select('id, amount, created_at').eq('status', 'paid').gte('created_at', toIso(previousStart)).lt('created_at', toIso(currentStart)),
      supabaseAdmin.from('support_tickets').select('id, user_id, subject, category, status, priority, created_at, updated_at').order('updated_at', { ascending: false }).limit(12),
      supabaseAdmin.from('resumes').select('template_slug, created_at').gte('created_at', toIso(currentStart)),
    ]);

    [currentProfiles, previousProfiles, currentResumes, previousResumes, currentPayments, previousPayments, ticketResponse, currentTemplateResumes].forEach((response) => {
      if (response.error) throw response.error;
    });

    const users = [...directory.values()];
    const currentPaid = currentPayments.data || [];
    const previousPaid = previousPayments.data || [];
    const currentRevenue = currentPaid.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const previousRevenue = previousPaid.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const activeDraftUsers = new Set((currentResumes.data || []).map((row) => row.user_id)).size;
    const completedResumes = (currentResumes.data || []).filter((row) => Number(row.completion_percent || 0) >= 90).length;
    const openTickets = (ticketResponse.data || []).filter((ticket) => !['resolved', 'closed'].includes(ticket.status)).length;

    const chartDays = Math.min(days, 30);
    const chartStart = startOfDaysAgo(chartDays);
    const chart = new Map();
    for (let i = 0; i < chartDays; i += 1) {
      const date = new Date(chartStart);
      date.setDate(chartStart.getDate() + i);
      chart.set(dayKey(date), { date: dayKey(date), users: 0, resumes: 0, revenue: 0 });
    }
    (currentProfiles.data || []).forEach((row) => { const item = chart.get(dayKey(row.created_at)); if (item) item.users += 1; });
    (currentResumes.data || []).forEach((row) => { const item = chart.get(dayKey(row.created_at)); if (item) item.resumes += 1; });
    currentPaid.forEach((row) => { const item = chart.get(dayKey(row.created_at)); if (item) item.revenue += Number(row.amount || 0); });

    const templateCounts = new Map();
    (currentTemplateResumes.data || []).forEach((row) => templateCounts.set(row.template_slug, (templateCounts.get(row.template_slug) || 0) + 1));
    const templateUsage = [...templateCounts.entries()]
      .map(([slug, count]) => ({ slug, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    const activity = [
      ...(currentProfiles.data || []).slice(-5).map((row) => ({ type: 'user', at: row.created_at, userId: row.id, label: 'created an account' })),
      ...(currentResumes.data || []).slice(-5).map((row) => ({ type: 'resume', at: row.updated_at, userId: row.user_id, label: `updated ${row.template_slug} resume` })),
      ...currentPaid.slice(-5).map((row) => ({ type: 'payment', at: row.paid_at || row.created_at, userId: null, label: `${row.plan} payment captured · ₹${Math.round(Number(row.amount || 0) / 100)}` })),
      ...(ticketResponse.data || []).slice(0, 5).map((row) => ({ type: 'support', at: row.updated_at, userId: row.user_id, label: `support ticket: ${row.subject}`, priority: row.priority })),
    ].sort((a, b) => new Date(b.at) - new Date(a.at)).slice(0, 12).map((item) => ({
      ...item,
      user: item.userId ? publicAdminUser(directory.get(item.userId) || { id: item.userId, name: 'Member', email: '', location: '—', careerTitle: '—', plan: 'free', role: 'user', accountStatus: 'active', createdAt: null, lastSignInAt: null, resumeCount: 0, bestCompletion: 0, lastResumeAt: null }) : null,
    }));

    return res.json({
      generatedAt: now.toISOString(),
      days,
      admin: req.admin,
      metrics: {
        totalUsers: users.length,
        newUsers: (currentProfiles.data || []).length,
        newUsersChange: percentageChange((currentProfiles.data || []).length, (previousProfiles.data || []).length),
        totalResumes: users.reduce((sum, user) => sum + user.resumeCount, 0),
        newResumes: (currentResumes.data || []).length,
        newResumesChange: percentageChange((currentResumes.data || []).length, (previousResumes.data || []).length),
        revenuePaise: currentRevenue,
        revenueChange: percentageChange(currentRevenue, previousRevenue),
        paidUsers: users.filter((user) => user.plan !== 'free').length,
        openTickets,
      },
      funnel: {
        signups: (currentProfiles.data || []).length,
        draftUsers: activeDraftUsers,
        completedResumes,
        paidPayments: currentPaid.length,
      },
      chart: [...chart.values()],
      templateUsage,
      activity,
    });
  } catch (error) { return next(error); }
}

async function listUsers(req, res, next) {
  try {
    const query = cleanText(req.query.q, 120).toLowerCase();
    const plan = cleanText(req.query.plan, 30);
    const role = cleanText(req.query.role, 30);
    const status = cleanText(req.query.status, 30);
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(10, Number(req.query.limit || 25)));
    const directory = await buildDirectory();
    let users = [...directory.values()];
    if (query) users = users.filter((user) => `${user.name} ${user.email} ${user.location} ${user.careerTitle}`.toLowerCase().includes(query));
    if (plan && plan !== 'all') users = users.filter((user) => user.plan === plan);
    if (role && role !== 'all') users = users.filter((user) => user.role === role);
    if (status && status !== 'all') users = users.filter((user) => user.accountStatus === status);
    users.sort((a, b) => new Date(b.lastSignInAt || b.createdAt || 0) - new Date(a.lastSignInAt || a.createdAt || 0));
    const total = users.length;
    const offset = (page - 1) * limit;
    return res.json({ users: users.slice(offset, offset + limit).map(publicAdminUser), total, page, limit });
  } catch (error) { return next(error); }
}

async function listResumes(req, res, next) {
  try {
    const query = cleanText(req.query.q, 120).toLowerCase();
    const state = cleanText(req.query.state, 30);
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(10, Number(req.query.limit || 25)));
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('resumes').select('id, user_id, title, template_slug, completion_percent, created_at, updated_at').order('updated_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let rows = (response.data || []).map((resume) => {
      const user = directory.get(resume.user_id);
      const completion = Number(resume.completion_percent || 0);
      const derivedState = completion >= 90 ? 'complete' : completion < 40 && new Date(resume.updated_at) < startOfDaysAgo(3) ? 'stale' : 'draft';
      return { ...resume, completion, state: derivedState, user: user ? publicAdminUser(user) : { name: 'Deleted user', email: '' } };
    });
    if (query) rows = rows.filter((row) => `${row.title} ${row.template_slug} ${row.user.name} ${row.user.email}`.toLowerCase().includes(query));
    if (state && state !== 'all') rows = rows.filter((row) => row.state === state);
    const total = rows.length;
    const offset = (page - 1) * limit;
    return res.json({ resumes: rows.slice(offset, offset + limit), total, page, limit });
  } catch (error) { return next(error); }
}

async function listApplications(req, res, next) {
  try {
    const query = cleanText(req.query.q, 120).toLowerCase();
    const status = cleanText(req.query.status, 30);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('job_applications').select('id, user_id, company, job_title, job_url, location, status, applied_at, follow_up_at, resume_id, created_at, updated_at').order('updated_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let applications = (response.data || []).map((application) => ({
      ...application,
      user: directory.get(application.user_id) ? publicAdminUser(directory.get(application.user_id)) : { name: 'Deleted user', email: '' },
    }));
    if (query) applications = applications.filter((item) => `${item.company} ${item.job_title} ${item.location} ${item.user.name} ${item.user.email}`.toLowerCase().includes(query));
    if (status && status !== 'all') applications = applications.filter((item) => item.status === status);
    const counts = Object.fromEntries(['saved', 'applied', 'interview', 'offer', 'rejected', 'withdrawn'].map((key) => [key, 0]));
    applications.forEach((item) => { counts[item.status] = (counts[item.status] || 0) + 1; });
    const today = new Date().toISOString().slice(0, 10);
    const activeStatuses = new Set(['saved', 'applied', 'interview']);
    const overdueFollowUps = applications.filter((item) => item.follow_up_at && item.follow_up_at < today && activeStatuses.has(item.status)).length;
    const dueTodayFollowUps = applications.filter((item) => item.follow_up_at === today && activeStatuses.has(item.status)).length;
    return res.json({ applications, counts, overdueFollowUps, dueTodayFollowUps });
  } catch (error) { return next(error); }
}

async function listPayments(req, res, next) {
  try {
    const query = cleanText(req.query.q, 120).toLowerCase();
    const status = cleanText(req.query.status, 30);
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(100, Math.max(10, Number(req.query.limit || 25)));
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('payments').select('id, user_id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at').order('created_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let rows = (response.data || []).map((payment) => ({ ...payment, user: directory.get(payment.user_id) ? publicAdminUser(directory.get(payment.user_id)) : { name: 'Deleted user', email: '' } }));
    if (query) rows = rows.filter((row) => `${row.user.name} ${row.user.email} ${row.plan} ${row.razorpay_order_id} ${row.razorpay_payment_id || ''}`.toLowerCase().includes(query));
    if (status && status !== 'all') rows = rows.filter((row) => row.status === status);
    const total = rows.length;
    const offset = (page - 1) * limit;
    return res.json({ payments: rows.slice(offset, offset + limit), total, page, limit });
  } catch (error) { return next(error); }
}

async function adminPaymentReceipt(req, res, next) {
  try {
    const paymentId = cleanText(req.params.id, 80);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('payments').select('id, user_id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at').eq('id', paymentId).maybeSingle(),
    ]);
    if (response.error) throw response.error;
    if (!response.data) return res.status(404).json({ error: 'Payment receipt nahi mila.' });
    if (response.data.status !== 'paid') return res.status(400).json({ error: 'Receipt sirf successful payment ke liye available hai.' });
    const user = directory.get(response.data.user_id) || {};
    await writeAudit(req.admin.id, 'payment_receipt_viewed', 'payment', paymentId, { status: response.data.status });
    return res.json({ receipt: paymentReceipt(response.data, { name: user.name || '', email: user.email || '' }) });
  } catch (error) { return next(error); }
}

async function adminPaymentReceiptPdf(req, res, next) {
  try {
    const paymentId = cleanText(req.params.id, 80);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('payments').select('id, user_id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at').eq('id', paymentId).maybeSingle(),
    ]);
    if (response.error) throw response.error;
    if (!response.data) return res.status(404).json({ error: 'Payment receipt nahi mila.' });
    if (response.data.status !== 'paid') return res.status(400).json({ error: 'Receipt sirf successful payment ke liye available hai.' });
    const user = directory.get(response.data.user_id) || {};
    const receipt = paymentReceipt(response.data, { name: user.name || '', email: user.email || '' });
    const pdf = await createReceiptPdf(receipt);
    await writeAudit(req.admin.id, 'payment_receipt_downloaded', 'payment', paymentId, { status: response.data.status });
    const filename = `BanaoCV-Receipt-${receipt.receiptNumber.replace(/[^a-z0-9-]/gi, '')}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdf.length);
    return res.send(pdf);
  } catch (error) { return next(error); }
}

async function listTickets(req, res, next) {
  try {
    const status = cleanText(req.query.status, 30);
    const priority = cleanText(req.query.priority, 30);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('support_tickets').select('id, user_id, subject, category, message, status, priority, admin_reply, created_at, updated_at').order('updated_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let tickets = (response.data || []).map((ticket) => ({ ...ticket, user: directory.get(ticket.user_id) ? publicAdminUser(directory.get(ticket.user_id)) : { name: 'Deleted user', email: '' } }));
    if (status && status !== 'all') tickets = tickets.filter((ticket) => ticket.status === status);
    if (priority && priority !== 'all') tickets = tickets.filter((ticket) => ticket.priority === priority);
    return res.json({ tickets });
  } catch (error) { return next(error); }
}

async function updateTicket(req, res, next) {
  try {
    const ticketId = cleanText(req.params.id, 80);
    const patch = {};
    if (req.body.status !== undefined) {
      const status = cleanText(req.body.status, 30);
      if (!TICKET_STATUSES.has(status)) return res.status(400).json({ error: 'Support status valid nahi hai.' });
      patch.status = status;
    }
    if (req.body.priority !== undefined) {
      const priority = cleanText(req.body.priority, 30);
      if (!TICKET_PRIORITIES.has(priority)) return res.status(400).json({ error: 'Priority valid nahi hai.' });
      patch.priority = priority;
    }
    if (req.body.admin_reply !== undefined) patch.admin_reply = cleanText(req.body.admin_reply, 5000);
    if (!Object.keys(patch).length) return res.status(400).json({ error: 'Koi ticket change nahi mila.' });
    patch.updated_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin.from('support_tickets').update(patch).eq('id', ticketId).select().maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Ticket nahi mila.' });
    await writeAudit(req.admin.id, 'support_ticket_updated', 'support_ticket', ticketId, { status: data.status, priority: data.priority, hasReply: Boolean(data.admin_reply) });
    return res.json({ ticket: data, message: 'Support ticket update ho gaya.' });
  } catch (error) { return next(error); }
}

async function listDeletionRequests(req, res, next) {
  try {
    const status = cleanText(req.query.status || 'all', 30);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('account_deletion_requests').select('id, user_id, status, reason, admin_note, requested_at, resolved_at, updated_at').order('updated_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let requests = (response.data || []).map((request) => ({
      ...request,
      user: directory.get(request.user_id) ? publicAdminUser(directory.get(request.user_id)) : { name: 'Deleted user', email: '' },
    }));
    if (status && status !== 'all') requests = requests.filter((request) => request.status === status);
    return res.json({ requests });
  } catch (error) { return next(error); }
}

async function updateDeletionRequest(req, res, next) {
  try {
    const id = cleanText(req.params.id, 80);
    const status = cleanText(req.body.status, 30);
    if (!DELETION_STATUSES.has(status)) return res.status(400).json({ error: 'Deletion request status valid nahi hai.' });
    const adminNote = cleanText(req.body.admin_note, 2000);
    const patch = { status, admin_note: adminNote, updated_at: new Date().toISOString() };
    if (['approved', 'rejected', 'completed', 'cancelled'].includes(status)) patch.resolved_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin.from('account_deletion_requests').update(patch).eq('id', id).select().maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Deletion request nahi mili.' });
    await writeAudit(req.admin.id, 'deletion_request_updated', 'account_deletion_request', id, { status });
    return res.json({ request: data, message: 'Deletion request review update ho gaya. Account automatic delete nahi hota.' });
  } catch (error) { return next(error); }
}

async function listBillingChangeRequests(req, res, next) {
  try {
    const status = cleanText(req.query.status || 'all', 30);
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('billing_change_requests').select('id, user_id, request_type, current_plan, status, reason, admin_note, requested_at, resolved_at, updated_at').order('updated_at', { ascending: false }),
    ]);
    if (response.error) throw response.error;
    let requests = (response.data || []).map((request) => ({
      ...request,
      user: directory.get(request.user_id) ? publicAdminUser(directory.get(request.user_id)) : { name: 'Deleted user', email: '' },
    }));
    if (status && status !== 'all') requests = requests.filter((request) => request.status === status);
    return res.json({ requests });
  } catch (error) { return next(error); }
}

async function updateBillingChangeRequest(req, res, next) {
  try {
    const id = cleanText(req.params.id, 80);
    const status = cleanText(req.body.status, 30);
    if (!BILLING_REQUEST_STATUSES.has(status)) return res.status(400).json({ error: 'Billing request status valid nahi hai.' });
    const adminNote = cleanText(req.body.admin_note, 2000);
    const patch = { status, admin_note: adminNote, updated_at: new Date().toISOString() };
    if (['approved', 'rejected', 'completed', 'cancelled'].includes(status)) patch.resolved_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin.from('billing_change_requests').update(patch).eq('id', id).select().maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Billing request nahi mili.' });
    await writeAudit(req.admin.id, 'billing_change_request_updated', 'billing_change_request', id, { status, requestType: data.request_type });
    return res.json({ request: data, message: 'Billing request review update ho gaya. Payment/refund automatic nahi hota.' });
  } catch (error) { return next(error); }
}

async function listEmployers(req, res, next) {
  try {
    const status = cleanText(req.query.status || 'all', 40);
    const { data, error } = await supabaseAdmin.from('employer_organizations')
      .select('id, legal_name, display_name, slug, website, linkedin_url, location, industry, company_size, about, status, verification_note, created_at, updated_at')
      .order('updated_at', { ascending: false });
    if (error) throw error;
    const employers = status && status !== 'all' ? (data || []).filter((org) => org.status === status) : (data || []);
    return res.json({ employers });
  } catch (error) { return next(error); }
}

async function updateEmployerStatus(req, res, next) {
  try {
    const id = cleanText(req.params.id, 80);
    const status = cleanText(req.body.status, 40);
    if (!EMPLOYER_STATUSES.has(status)) return res.status(400).json({ error: 'Company verification status valid nahi hai.' });
    const note = cleanText(req.body.verification_note, 2000);
    const { data, error } = await supabaseAdmin.from('employer_organizations')
      .update({ status, verification_note: note, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Company profile nahi mili.' });
    await writeAudit(req.admin.id, 'employer_verification_updated', 'employer_organization', id, { status });
    return res.json({ employer: data, message: `Company status ${status.replaceAll('_',' ')} ho gaya.` });
  } catch (error) { return next(error); }
}

async function listEmployerJobsAdmin(req, res, next) {
  try {
    const status = cleanText(req.query.status || 'all', 40);
    const { data: jobs, error } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, status, review_note, published_at, created_at, updated_at')
      .order('updated_at', { ascending: false });
    if (error) throw error;
    const orgIds = [...new Set((jobs || []).map((job) => job.organization_id))];
    const { data: orgs, error: orgError } = orgIds.length ? await supabaseAdmin.from('employer_organizations').select('id, display_name, status').in('id', orgIds) : { data: [], error: null };
    if (orgError) throw orgError;
    const orgMap = new Map((orgs || []).map((org) => [org.id, org]));
    let rows = (jobs || []).map((job) => ({ ...job, organization: orgMap.get(job.organization_id) || { display_name: 'Unknown company', status: 'unknown' } }));
    if (status && status !== 'all') rows = rows.filter((job) => job.status === status);
    return res.json({ jobs: rows });
  } catch (error) { return next(error); }
}

async function updateEmployerJobAdmin(req, res, next) {
  try {
    const id = cleanText(req.params.id, 80);
    const status = cleanText(req.body.status, 40);
    if (!JOB_REVIEW_STATUSES.has(status)) return res.status(400).json({ error: 'Job review status valid nahi hai.' });
    const reviewNote = cleanText(req.body.review_note, 2000);
    const patch = { status, review_note: reviewNote, updated_at: new Date().toISOString() };
    if (status === 'published') patch.published_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin.from('employer_jobs').update(patch).eq('id', id).select().maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Employer job nahi mili.' });
    await writeAudit(req.admin.id, 'employer_job_moderation_updated', 'employer_job', id, { status });
    return res.json({ job: data, message: `Job status ${status.replaceAll('_', ' ')} ho gaya.` });
  } catch (error) { return next(error); }
}

async function listTemplates(req, res, next) {
  try {
    const [settingsResponse, usageResponse] = await Promise.all([
      supabaseAdmin.from('template_admin_settings').select('slug, is_enabled, updated_at, updated_by'),
      supabaseAdmin.from('resumes').select('template_slug'),
    ]);
    if (settingsResponse.error) throw settingsResponse.error;
    if (usageResponse.error) throw usageResponse.error;
    const settings = new Map((settingsResponse.data || []).map((row) => [row.slug, row]));
    const usage = new Map();
    (usageResponse.data || []).forEach((row) => usage.set(row.template_slug, (usage.get(row.template_slug) || 0) + 1));
    const templates = TEMPLATE_CATALOG.map(([slug, name, access, category]) => ({
      slug,
      name,
      access,
      category,
      isEnabled: settings.get(slug)?.is_enabled !== false,
      usageCount: usage.get(slug) || 0,
      updatedAt: settings.get(slug)?.updated_at || null,
    }));
    return res.json({ templates });
  } catch (error) { return next(error); }
}

async function updateTemplate(req, res, next) {
  try {
    const slug = cleanText(req.params.slug, 80);
    if (!TEMPLATE_CATALOG.some(([key]) => key === slug)) return res.status(404).json({ error: 'Template nahi mila.' });
    if (typeof req.body.is_enabled !== 'boolean') return res.status(400).json({ error: 'Template availability valid nahi hai.' });
    const { data, error } = await supabaseAdmin.from('template_admin_settings').upsert({
      slug,
      is_enabled: req.body.is_enabled,
      updated_by: req.admin.id,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'slug' }).select().single();
    if (error) throw error;
    await writeAudit(req.admin.id, 'template_availability_updated', 'template', slug, { isEnabled: data.is_enabled });
    return res.json({ template: data, message: `Template ${data.is_enabled ? 'enable' : 'disable'} ho gaya.` });
  } catch (error) { return next(error); }
}

async function updateUserRole(req, res, next) {
  try {
    const userId = cleanText(req.params.id, 80);
    const role = cleanText(req.body.role, 30);
    if (!ROLE_VALUES.has(role)) return res.status(400).json({ error: 'Admin role valid nahi hai.' });
    if (userId === req.admin.id) return res.status(400).json({ error: 'Apna Super Admin role yahan se change nahi kar sakte.' });
    const { data, error } = await supabaseAdmin.from('profiles').update({ role, updated_at: new Date().toISOString() }).eq('id', userId).select('id, role, full_name').maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'User nahi mila.' });
    await writeAudit(req.admin.id, 'user_role_updated', 'user', userId, { role });
    return res.json({ user: data, message: 'User role update ho gaya.' });
  } catch (error) { return next(error); }
}

async function updateUserPlan(req, res, next) {
  try {
    const userId = cleanText(req.params.id, 80);
    const plan = cleanText(req.body.plan, 30);
    if (!PLAN_VALUES.has(plan)) return res.status(400).json({ error: 'Plan valid nahi hai.' });
    const { data, error } = await supabaseAdmin.from('profiles').update({
      plan,
      plan_activated_at: plan === 'free' ? null : new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }).eq('id', userId).select('id, plan, full_name').maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'User nahi mila.' });
    await writeAudit(req.admin.id, 'user_plan_updated', 'user', userId, { plan });
    return res.json({ user: data, message: 'User plan update ho gaya. Razorpay refund ya charge is action se nahi hota.' });
  } catch (error) { return next(error); }
}

async function getSystem(req, res, next) {
  try {
    const started = Date.now();
    const { error } = await supabaseAdmin.from('profiles').select('id', { head: true, count: 'exact' }).limit(1);
    if (error) throw error;
    const aiProvider = (process.env.AI_PROVIDER || 'nvidia').toLowerCase();
    const aiConfigured = aiProvider === 'nvidia'
      ? Boolean(process.env.NVIDIA_API_KEY)
      : aiProvider === 'groq'
        ? Boolean(process.env.GROQ_API_KEY)
        : Boolean(process.env.OPENAI_API_KEY);
    const aiLabel = aiProvider === 'groq' ? 'Groq AI (beta)' : aiProvider === 'nvidia' ? 'NVIDIA AI (development)' : 'OpenAI AI';
    const services = [
      { key: 'api', label: 'BanaoCV API', state: 'healthy', detail: 'Express routes responding' },
      { key: 'database', label: 'Supabase database', state: 'healthy', detail: `Service-role query verified · ${Date.now() - started}ms` },
      { key: 'auth', label: 'Email authentication', state: 'healthy', detail: 'Email/password and recovery flow active' },
      { key: 'payments', label: 'Razorpay', state: process.env.RAZORPAY_KEY_ID ? 'configured' : 'attention', detail: process.env.RAZORPAY_KEY_ID ? 'Order verification configured' : 'Payment keys not configured' },
      { key: 'email', label: 'Brevo transactional email', state: process.env.BREVO_API_KEY ? 'configured' : 'attention', detail: process.env.BREVO_API_KEY ? 'HTTPS recovery delivery configured' : 'Brevo API key not configured' },
      { key: 'ai', label: aiLabel, state: aiConfigured ? 'testing' : 'attention', detail: aiConfigured ? `${aiProvider} configured; run one AI browser test before calling it live` : `${aiProvider} key placeholder is empty` },
    ];
    return res.json({ generatedAt: new Date().toISOString(), services });
  } catch (error) { return next(error); }
}

async function listAuditLogs(req, res, next) {
  try {
    const [directory, response] = await Promise.all([
      buildDirectory(),
      supabaseAdmin.from('admin_audit_logs').select('id, actor_id, action, target_type, target_id, metadata, created_at').order('created_at', { ascending: false }).limit(100),
    ]);
    if (response.error) throw response.error;
    const logs = (response.data || []).map((row) => ({
      ...row,
      actor: directory.get(row.actor_id) ? publicAdminUser(directory.get(row.actor_id)) : { name: 'Deleted administrator', email: '' },
    }));
    return res.json({ logs });
  } catch (error) { return next(error); }
}

function csvEscape(value) {
  const output = String(value ?? '');
  return /[",\n]/.test(output) ? `"${output.replaceAll('"', '""')}"` : output;
}

async function exportData(req, res, next) {
  try {
    const type = cleanText(req.params.type, 30);
    let rows = [];
    let headers = [];
    if (type === 'users') {
      const directory = await buildDirectory();
      headers = ['Name', 'Email', 'Plan', 'Role', 'Status', 'Location', 'Resumes', 'Best completion', 'Joined', 'Last sign-in'];
      rows = [...directory.values()].map((user) => [user.name, user.email, user.plan, user.role, user.accountStatus, user.location, user.resumeCount, user.bestCompletion, user.createdAt, user.lastSignInAt]);
    } else if (type === 'resumes') {
      const directory = await buildDirectory();
      const { data, error } = await supabaseAdmin.from('resumes').select('title, user_id, template_slug, completion_percent, created_at, updated_at').order('updated_at', { ascending: false });
      if (error) throw error;
      headers = ['Title', 'Owner', 'Owner email', 'Template', 'Completion', 'Created', 'Updated'];
      rows = (data || []).map((resume) => { const user = directory.get(resume.user_id) || {}; return [resume.title, user.name || 'Deleted user', user.email || '', resume.template_slug, resume.completion_percent, resume.created_at, resume.updated_at]; });
    } else if (type === 'applications') {
      const directory = await buildDirectory();
      const { data, error } = await supabaseAdmin.from('job_applications').select('user_id, company, job_title, job_url, location, status, applied_at, follow_up_at, created_at, updated_at').order('updated_at', { ascending: false });
      if (error) throw error;
      headers = ['User', 'Email', 'Company', 'Job title', 'Location', 'Status', 'Job URL', 'Applied date', 'Follow-up date', 'Created', 'Updated'];
      rows = (data || []).map((application) => { const user = directory.get(application.user_id) || {}; return [user.name || 'Deleted user', user.email || '', application.company, application.job_title, application.location, application.status, application.job_url || '', application.applied_at || '', application.follow_up_at || '', application.created_at, application.updated_at]; });
    } else if (type === 'payments') {
      const directory = await buildDirectory();
      const { data, error } = await supabaseAdmin.from('payments').select('user_id, plan, amount, currency, status, razorpay_order_id, razorpay_payment_id, paid_at, created_at').order('created_at', { ascending: false });
      if (error) throw error;
      headers = ['User', 'Email', 'Plan', 'Amount paise', 'Currency', 'Status', 'Order ID', 'Payment ID', 'Paid at', 'Created'];
      rows = (data || []).map((payment) => { const user = directory.get(payment.user_id) || {}; return [user.name || 'Deleted user', user.email || '', payment.plan, payment.amount, payment.currency, payment.status, payment.razorpay_order_id, payment.razorpay_payment_id || '', payment.paid_at || '', payment.created_at]; });
    } else if (type === 'support') {
      const directory = await buildDirectory();
      const { data, error } = await supabaseAdmin.from('support_tickets').select('user_id, subject, category, status, priority, admin_reply, created_at, updated_at').order('updated_at', { ascending: false });
      if (error) throw error;
      headers = ['User', 'Email', 'Subject', 'Category', 'Status', 'Priority', 'Admin reply', 'Created', 'Updated'];
      rows = (data || []).map((ticket) => { const user = directory.get(ticket.user_id) || {}; return [user.name || 'Deleted user', user.email || '', ticket.subject, ticket.category, ticket.status, ticket.priority, ticket.admin_reply || '', ticket.created_at, ticket.updated_at]; });
    } else {
      return res.status(404).json({ error: 'Export type valid nahi hai.' });
    }
    await writeAudit(req.admin.id, 'csv_exported', type, null, { rows: rows.length });
    const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="banaocv-${type}-${dayKey(new Date())}.csv"`);
    return res.send(`\uFEFF${csv}`);
  } catch (error) { return next(error); }
}

module.exports = {
  getAdminMe,
  getOverview,
  listUsers,
  listResumes,
  listApplications,
  listPayments,
  adminPaymentReceipt,
  adminPaymentReceiptPdf,
  listTickets,
  updateTicket,
  listDeletionRequests,
  updateDeletionRequest,
  listBillingChangeRequests,
  updateBillingChangeRequest,
  listEmployers,
  updateEmployerStatus,
  listEmployerJobsAdmin,
  updateEmployerJobAdmin,
  listTemplates,
  updateTemplate,
  updateUserRole,
  updateUserPlan,
  getSystem,
  listAuditLogs,
  exportData,
};
