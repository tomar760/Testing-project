const { getAI, createChatCompletion } = require('../config/openai');
const { supabaseAdmin } = require('../config/supabase');

const clean = (value, max) => String(value || '').trim().slice(0, max);


function parseJson(content) {
  const raw = String(content || '').trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/, '');
  try { return JSON.parse(raw); } catch { throw new Error('AI returned invalid JSON'); }
}

async function askAI(system, prompt) {
  const ai = getAI();
  const request = {
    model: ai.model,
    messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }],
    temperature: 0.45,
    max_tokens: ai.maxTokens,
  };
  // NVIDIA models receive JSON-only prompts but not OpenAI-only response_format.
  if (ai.supportsJsonMode) request.response_format = { type: 'json_object' };
  const completion = await createChatCompletion(ai, request);
  return parseJson(completion.choices?.[0]?.message?.content || '{}');
}

function logUsage(userId, feature) {
  // Analytics must never make a paid AI response fail.
  return supabaseAdmin.from('ai_usage').insert({ user_id: userId, feature }).then(() => undefined).catch(() => undefined);
}

async function hindiToResume(req, res, next) {
  try {
    const text = String(req.body.text || '').trim();
    if (!text || text.length > 12000) return res.status(400).json({ error: 'Apni details 1 se 12,000 characters ke beech likho.' });
    const system = `You are BanaoCV's resume-building assistant for Indian job seekers. Convert Hindi, English or Hinglish details into valid JSON only. Use exactly this shape: {"name":"","title":"","email":"","phone":"","location":"","summary":"","experience":[{"jtitle":"","company":"","dates":"","desc":""}],"education":[{"degree":"","school":"","year":""}],"skills":"comma,separated,skills"}. Never invent facts. Use professional English for resume content unless the user specifically requests Hindi.`;
    const resume = await askAI(system, text);
    await logUsage(req.user.id, 'hindi_to_resume');
    return res.json({ resume });
  } catch (error) { return next(error); }
}

async function analyzeScore(req, res, next) {
  try {
    if (!req.body.resumeData || typeof req.body.resumeData !== 'object') return res.status(400).json({ error: 'Resume data chahiye.' });
    const system = `You are an ATS resume reviewer. Return valid JSON only: {"overallScore":0,"breakdown":{"content":0,"ats":0,"skills":0,"completeness":0},"tips":["short Hinglish tip"]}. Every score must be an integer between 0 and 100. Give 3 practical tips.`;
    const result = await askAI(system, JSON.stringify(req.body.resumeData));
    await logUsage(req.user.id, 'score');
    return res.json(result);
  } catch (error) { return next(error); }
}

async function jdMatch(req, res, next) {
  try {
    const { resumeData, jobDescription } = req.body;
    if (!resumeData || typeof resumeData !== 'object' || !String(jobDescription || '').trim()) return res.status(400).json({ error: 'Resume aur job description dono chahiye.' });
    if (String(jobDescription).length > 16000) return res.status(400).json({ error: 'Job description bahut lambi hai.' });
    const system = `You compare a resume to a job description for an Indian applicant. Return valid JSON only: {"matchPercent":0,"matchedKeywords":[""],"missingKeywords":[""],"suggestedSummary":""}. Keep lists concise. Never claim experience that is absent from the resume.`;
    const result = await askAI(system, `RESUME\n${JSON.stringify(resumeData)}\n\nJOB DESCRIPTION\n${jobDescription}`);
    await logUsage(req.user.id, 'jd_match');
    return res.json(result);
  } catch (error) { return next(error); }
}

async function coverLetter(req, res, next) {
  try {
    const { resumeData, company, role, tone = 'professional', jobDescription = '' } = req.body;
    if (!resumeData || typeof resumeData !== 'object' || !String(company || '').trim() || !String(role || '').trim()) return res.status(400).json({ error: 'Resume, company aur role dono chahiye.' });
    const system = `You write concise, professional cover letters for Indian job seekers. Return valid JSON only: {"coverLetter":""}. Keep it below 250 words, use ${String(tone).slice(0,40)} tone, use job description only as context, and never invent achievements absent from the supplied resume.`;
    const result = await askAI(system, `RESUME\n${JSON.stringify(resumeData)}\n\nCOMPANY: ${company}\nROLE: ${role}\nJOB DESCRIPTION (optional): ${String(jobDescription).slice(0,16000)}`);
    await logUsage(req.user.id, 'cover_letter');
    return res.json(result);
  } catch (error) { return next(error); }
}

module.exports = { hindiToResume, analyzeScore, jdMatch, coverLetter };

function guidedFallbackQuestions(resumeData) {
  const questions = [];
  const content = resumeData || {};
  if (!String(content.title || '').trim()) questions.push({ id: 'target_role', label: 'Aap kis role ke liye resume bana rahe ho?', help: 'Role clear hoga toh summary targeted banegi.', options: ['Frontend Developer', 'Software Developer', 'Internship', 'Custom role'] });
  if (!(content.experience || []).some((item) => item?.jtitle || item?.company)) questions.push({ id: 'experience_level', label: 'Aapka experience level kya hai?', help: 'AI sirf aapke actual level ke hisaab se likhega.', options: ['Fresher', 'Internship ki hai', '1–2 years experience', 'More details likho'] });
  if (!String(content.skills || '').trim()) questions.push({ id: 'core_skills', label: 'Aapki strongest skills kya hain?', help: '2–5 skills select ya apni skills type karo.', options: ['HTML, CSS, JavaScript', 'React, Node.js', 'Excel, Communication', 'Apni skills likho'] });
  if (!String(content.summary || '').trim()) questions.push({ id: 'strength', label: 'Resume mein kaunsi strength highlight karni hai?', help: 'AI fact create nahi karega; sirf aapka chosen focus use karega.', options: ['Projects', 'Internship', 'Education', 'Achievements'] });
  return questions.slice(0, 3);
}

function cleanQuestions(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 3).map((item) => ({
    id: clean(item?.id, 50).replace(/[^a-z0-9_]/gi, '_') || 'detail',
    label: clean(item?.label, 180),
    help: clean(item?.help, 300),
    options: Array.isArray(item?.options) ? item.options.slice(0, 5).map((option) => clean(option, 90)).filter(Boolean) : [],
  })).filter((item) => item.label && item.options.length);
}

async function guidedInterviewQuestions(req, res, next) {
  try {
    const resumeData = req.body.resumeData;
    if (!resumeData || typeof resumeData !== 'object') return res.status(400).json({ error: 'Resume data chahiye.' });
    const fallback = guidedFallbackQuestions(resumeData);
    const system = `You are BanaoCV Career Interview. Ask at most 3 concise Hindi/Hinglish follow-up questions only for missing or unclear resume facts. Never invent facts. Options must be varied, relevant and safely selectable; include a custom/detail option where useful. Return valid JSON only: {"questions":[{"id":"","label":"","help":"","options":[""]}]}.`;
    let questions = [];
    try {
      const result = await askAI(system, { resumeData, fallback });
      questions = cleanQuestions(result.questions);
    } catch { questions = []; }
    if (!questions.length) questions = fallback;
    await logUsage(req.user.id, 'guided_interview_questions');
    return res.json({ questions });
  } catch (error) { return next(error); }
}

async function guidedContentGenerate(req, res, next) {
  try {
    const resumeData = req.body.resumeData;
    const mode = clean(req.body.mode, 40);
    const answers = Array.isArray(req.body.answers) ? req.body.answers.slice(0, 6).map((item) => ({ id: clean(item?.id, 50), value: clean(item?.value, 500) })) : [];
    const modes = new Set(['summary_short', 'summary_ats', 'headline', 'skills', 'bullets']);
    if (!resumeData || typeof resumeData !== 'object' || !modes.has(mode)) return res.status(400).json({ error: 'Guided content request valid nahi hai.' });
    const system = `You are BanaoCV Career Interview writer for Indian job seekers. Use only provided resume data and answers; never invent education, employer, dates, metrics, skills or achievements. Return exactly 3 concise alternatives in valid JSON: {"options":[{"label":"","text":""}]}. Mode is ${mode}. For summary modes use professional English, 35-70 words. For headline use one line. For skills use comma-separated skills that are explicitly supported by data/answers. For bullets use 2-3 concise newline-separated bullets.`;
    const result = await askAI(system, { resumeData, answers, mode });
    const options = Array.isArray(result.options) ? result.options.slice(0, 3).map((item, index) => ({ label: clean(item?.label, 80) || `Option ${index + 1}`, text: clean(item?.text, 1800) })).filter((item) => item.text) : [];
    if (!options.length) return res.status(502).json({ error: 'AI ne usable options return nahi kiye. Thodi detail add karke dobara try karo.' });
    await logUsage(req.user.id, 'guided_content_generate');
    return res.json({ options });
  } catch (error) { return next(error); }
}

module.exports.guidedInterviewQuestions = guidedInterviewQuestions;
module.exports.guidedContentGenerate = guidedContentGenerate;
