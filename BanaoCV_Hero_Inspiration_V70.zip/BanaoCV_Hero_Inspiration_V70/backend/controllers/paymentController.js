const crypto = require('crypto');
const Razorpay = require('razorpay');
const { supabaseAdmin } = require('../config/supabase');
const { paymentReceipt } = require('../utils/receipt');
const { createReceiptPdf } = require('../utils/receiptPdf');

// Launch Premium is ₹79 during launch (regular ₹99 later); promotion validation will be server-side.
const PLAN_AMOUNTS = { premium: 7900, pro_monthly: 24900, pro_annual: 179900 };
const PAID_PLANS = new Set(['premium', 'pro_monthly', 'pro_annual']);

function client() {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) throw new Error('Razorpay keys are not configured.');
  return new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
}

function verifySignature(orderId, paymentId, signature) {
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${orderId}|${paymentId}`).digest('hex');
  const received = Buffer.from(String(signature || ''));
  const expectedBuffer = Buffer.from(expected);
  return received.length === expectedBuffer.length && crypto.timingSafeEqual(expectedBuffer, received);
}

async function createOrder(req, res, next) {
  try {
    const plan = String(req.body.plan || '');
    const amount = PLAN_AMOUNTS[plan];
    if (!amount) return res.status(400).json({ error: 'Invalid plan.' });
    const order = await client().orders.create({
      amount,
      currency: 'INR',
      receipt: `bcv_${req.user.id.slice(0,8)}_${Date.now()}`,
      notes: { user_id: req.user.id, plan },
    });
    return res.json({ order, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (error) { return next(error); }
}

async function verifyPayment(req, res, next) {
  try {
    const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature, plan } = req.body;
    if (!orderId || !paymentId || !signature || !PLAN_AMOUNTS[plan]) return res.status(400).json({ error: 'Payment details valid nahi hain.' });
    if (!verifySignature(orderId, paymentId, signature)) return res.status(400).json({ error: 'Payment verify nahi hua.' });

    // Trust the order stored by Razorpay, not a plan value supplied by the browser.
    const order = await client().orders.fetch(orderId);
    if (order.notes?.user_id !== req.user.id || order.notes?.plan !== plan || Number(order.amount) !== PLAN_AMOUNTS[plan] || order.status !== 'paid') {
      return res.status(400).json({ error: 'Order details verify nahi hue.' });
    }

    const { error: paymentError } = await supabaseAdmin.from('payments').upsert({
      user_id: req.user.id, plan, razorpay_order_id: orderId, razorpay_payment_id: paymentId,
      amount: order.amount, currency: order.currency, status: 'paid', paid_at: new Date().toISOString(),
    }, { onConflict: 'razorpay_payment_id' });
    if (paymentError) throw paymentError;

    const creditGrant = plan === 'premium' ? 30 : 150;
    const { error: profileError } = await supabaseAdmin.from('profiles').update({
      plan, ai_credits_remaining: creditGrant, plan_activated_at: new Date().toISOString(), updated_at: new Date().toISOString(),
    }).eq('id', req.user.id);
    if (profileError) throw profileError;
    return res.json({ message: 'Payment successful! Plan activate ho gaya.', plan });
  } catch (error) { return next(error); }
}

async function paymentHistory(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('payments')
      .select('id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return res.json({ payments: data || [] });
  } catch (error) { return next(error); }
}

async function ownPaymentReceipt(req, res, next) {
  try {
    const paymentId = String(req.params.id || '').trim();
    const { data: payment, error } = await supabaseAdmin
      .from('payments')
      .select('id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at')
      .eq('id', paymentId)
      .eq('user_id', req.user.id)
      .maybeSingle();
    if (error) throw error;
    if (!payment) return res.status(404).json({ error: 'Payment receipt nahi mila.' });
    if (payment.status !== 'paid') return res.status(400).json({ error: 'Receipt sirf successful payment ke liye available hai.' });
    const { data: profile, error: profileError } = await supabaseAdmin.from('profiles').select('full_name').eq('id', req.user.id).maybeSingle();
    if (profileError) throw profileError;
    return res.json({ receipt: paymentReceipt(payment, { name: profile?.full_name || '', email: req.user.email || '' }) });
  } catch (error) { return next(error); }
}

async function ownPaymentReceiptPdf(req, res, next) {
  try {
    const paymentId = String(req.params.id || '').trim();
    const { data: payment, error } = await supabaseAdmin
      .from('payments')
      .select('id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at')
      .eq('id', paymentId)
      .eq('user_id', req.user.id)
      .maybeSingle();
    if (error) throw error;
    if (!payment) return res.status(404).json({ error: 'Payment receipt nahi mila.' });
    if (payment.status !== 'paid') return res.status(400).json({ error: 'Receipt sirf successful payment ke liye available hai.' });
    const { data: profile, error: profileError } = await supabaseAdmin.from('profiles').select('full_name').eq('id', req.user.id).maybeSingle();
    if (profileError) throw profileError;
    const receipt = paymentReceipt(payment, { name: profile?.full_name || '', email: req.user.email || '' });
    const pdf = await createReceiptPdf(receipt);
    const filename = `BanaoCV-Receipt-${receipt.receiptNumber.replace(/[^a-z0-9-]/gi, '')}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdf.length);
    return res.send(pdf);
  } catch (error) { return next(error); }
}

async function billingChangeRequest(req, res, next) {
  try {
    const { data: profile, error: profileError } = await supabaseAdmin.from('profiles').select('plan').eq('id', req.user.id).maybeSingle();
    if (profileError) throw profileError;
    const currentPlan = profile?.plan || 'free';
    if (!PAID_PLANS.has(currentPlan)) return res.status(400).json({ error: 'Free plan par cancellation request ki zarurat nahi hai.' });
    const { data: existing, error: existingError } = await supabaseAdmin.from('billing_change_requests')
      .select('id, status, requested_at')
      .eq('user_id', req.user.id)
      .in('status', ['requested', 'in_review', 'approved'])
      .maybeSingle();
    if (existingError) throw existingError;
    if (existing) return res.json({ request: existing, message: 'Aapki billing request already review mein hai.' });
    const reason = String(req.body.reason || '').trim().slice(0, 1000);
    const { data, error } = await supabaseAdmin.from('billing_change_requests')
      .insert({ user_id: req.user.id, current_plan: currentPlan, request_type: 'cancel_plan', reason })
      .select('id, request_type, current_plan, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .single();
    if (error) throw error;
    return res.status(201).json({ request: data, message: 'Plan cancellation request submit ho gayi. Isse payment/refund automatic nahi hota; Admin review karega.' });
  } catch (error) { return next(error); }
}

async function getBillingChangeRequest(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin.from('billing_change_requests')
      .select('id, request_type, current_plan, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .eq('user_id', req.user.id)
      .order('requested_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    return res.json({ request: data || null });
  } catch (error) { return next(error); }
}

async function cancelBillingChangeRequest(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin.from('billing_change_requests')
      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
      .eq('user_id', req.user.id)
      .in('status', ['requested', 'in_review'])
      .select('id, request_type, current_plan, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Active billing request nahi mili.' });
    return res.json({ request: data, message: 'Billing request cancel ho gayi.' });
  } catch (error) { return next(error); }
}

async function webhook(req, res, next) {
  try {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (!secret) return res.status(204).end();
    const signature = req.get('x-razorpay-signature') || '';
    const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
    const received = Buffer.from(signature);
    const expectedBuffer = Buffer.from(expected);
    if (received.length !== expectedBuffer.length || !crypto.timingSafeEqual(expectedBuffer, received)) return res.status(400).json({ error: 'Invalid webhook signature.' });
    // The browser verification is the active flow. This endpoint is intentionally ready for
    // payment-captured reconciliation when Razorpay webhook events are enabled in production.
    return res.status(200).json({ received: true });
  } catch (error) { return next(error); }
}

module.exports = { createOrder, verifyPayment, paymentHistory, ownPaymentReceipt, ownPaymentReceiptPdf, billingChangeRequest, getBillingChangeRequest, cancelBillingChangeRequest, webhook };
