const { supabaseAdmin, listAuthUsersPage } = require('../config/supabase');
const { notifyOrganizationMembers, safeCreateNotifications } = require('../utils/notifications');

const JOB_STATUSES = new Set(['draft', 'pending_review', 'published', 'paused', 'rejected', 'expired']);
const SUBMISSION_STATUSES = new Set(['submitted', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn']);
const EMPLOYER_SUBMISSION_STATUSES = new Set(['submitted', 'shortlisted', 'interview', 'offer', 'rejected']);
const clean = (value, max) => String(value || '').trim().slice(0, max);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function dateOrNull(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : undefined;
}

function skills(value) {
  if (!Array.isArray(value)) return undefined;
  return value.map((item) => clean(item, 50)).filter(Boolean).slice(0, 30);
}

async function employerContext(userId) {
  const { data: membership, error } = await supabaseAdmin.from('employer_members')
    .select('organization_id, member_role, status')
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (error) throw error;
  if (!membership) return null;
  const { data: organization, error: orgError } = await supabaseAdmin.from('employer_organizations')
    .select('id, display_name, legal_name, status')
    .eq('id', membership.organization_id)
    .maybeSingle();
  if (orgError) throw orgError;
  return organization ? { membership, organization } : null;
}

function validateJob(body) {
  const title = clean(body.title, 160);
  const location = clean(body.location, 120);
  const employmentType = clean(body.employment_type, 80);
  const experienceLevel = clean(body.experience_level, 80);
  const description = clean(body.description, 10000);
  const currency = clean(body.currency || 'INR', 3).toUpperCase();
  const salaryMin = body.salary_min === '' || body.salary_min === undefined ? null : Number(body.salary_min);
  const salaryMax = body.salary_max === '' || body.salary_max === undefined ? null : Number(body.salary_max);
  const applyDeadline = dateOrNull(body.apply_deadline);
  const jobSkills = skills(body.skills || []);
  if (title.length < 2 || description.length < 30) return { error: 'Job title aur detailed description daalo.' };
  if (applyDeadline === undefined) return { error: 'Apply deadline date valid nahi hai.' };
  if (!currency || currency.length !== 3) return { error: 'Currency valid nahi hai.' };
  if (jobSkills === undefined) return { error: 'Skills list valid nahi hai.' };
  if ((salaryMin !== null && (!Number.isFinite(salaryMin) || salaryMin < 0)) || (salaryMax !== null && (!Number.isFinite(salaryMax) || salaryMax < 0))) return { error: 'Salary amount valid nahi hai.' };
  if (salaryMin !== null && salaryMax !== null && salaryMax < salaryMin) return { error: 'Maximum salary minimum salary se kam nahi ho sakti.' };
  return { payload: { title, location, employment_type: employmentType, experience_level: experienceLevel, description, currency, salary_min: salaryMin, salary_max: salaryMax, skills: jobSkills, apply_deadline: applyDeadline } };
}

async function listEmployerJobs(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const { data, error } = await supabaseAdmin.from('employer_jobs')
      .select('id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, status, review_note, published_at, created_at, updated_at')
      .eq('organization_id', context.organization.id)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    return res.json({ organization: context.organization, member: context.membership, jobs: data || [] });
  } catch (error) { return next(error); }
}

async function createEmployerJob(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    if (context.organization.status !== 'approved') return res.status(403).json({ error: 'Job post karne se pehle company verification approve honi chahiye.' });
    const validation = validateJob(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const action = clean(req.body.action || 'draft', 30);
    const status = action === 'submit' ? 'pending_review' : 'draft';
    const { data, error } = await supabaseAdmin.from('employer_jobs')
      .insert({ organization_id: context.organization.id, ...validation.payload, status })
      .select()
      .single();
    if (error) throw error;
    return res.status(201).json({ job: data, message: status === 'pending_review' ? 'Job Admin review ke liye submit ho gayi.' : 'Job draft save ho gayi.' });
  } catch (error) { return next(error); }
}

async function updateEmployerJob(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const id = clean(req.params.id, 80);
    const { data: existing, error: existingError } = await supabaseAdmin.from('employer_jobs')
      .select('id, status').eq('id', id).eq('organization_id', context.organization.id).maybeSingle();
    if (existingError) throw existingError;
    if (!existing) return res.status(404).json({ error: 'Job nahi mili.' });
    if (context.organization.status !== 'approved') return res.status(403).json({ error: 'Company verification required hai.' });
    const validation = validateJob(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const action = clean(req.body.action || 'draft', 30);
    let status = existing.status;
    if (action === 'submit' && ['draft', 'rejected', 'paused'].includes(existing.status)) status = 'pending_review';
    if (action === 'pause' && existing.status === 'published') status = 'paused';
    const { data, error } = await supabaseAdmin.from('employer_jobs')
      .update({ ...validation.payload, status, updated_at: new Date().toISOString() })
      .eq('id', id).eq('organization_id', context.organization.id)
      .select()
      .single();
    if (error) throw error;
    return res.json({ job: data, message: status === 'pending_review' ? 'Job review ke liye resubmit ho gayi.' : 'Job update ho gayi.' });
  } catch (error) { return next(error); }
}

async function publicJobs(req, res, next) {
  try {
    const q = clean(req.query.q, 120).toLowerCase();
    const location = clean(req.query.location, 120).toLowerCase();
    const today = new Date().toISOString().slice(0, 10);
    const { data: jobs, error } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, published_at, created_at')
      .eq('status', 'published')
      .order('published_at', { ascending: false });
    if (error) throw error;
    const visible = (jobs || []).filter((job) => !job.apply_deadline || job.apply_deadline >= today);
    const orgIds = [...new Set(visible.map((job) => job.organization_id))];
    const { data: orgs, error: orgError } = orgIds.length ? await supabaseAdmin.from('employer_organizations').select('id, display_name, location, industry, website').in('id', orgIds).eq('status', 'approved') : { data: [], error: null };
    if (orgError) throw orgError;
    const organizations = new Map((orgs || []).map((org) => [org.id, org]));
    let result = visible.map((job) => ({ ...job, company: organizations.get(job.organization_id) })).filter((job) => job.company);
    if (q) result = result.filter((job) => `${job.title} ${job.company.display_name} ${job.skills.join(' ')}`.toLowerCase().includes(q));
    if (location) result = result.filter((job) => `${job.location} ${job.company.location}`.toLowerCase().includes(location));
    return res.json({ jobs: result });
  } catch (error) { return next(error); }
}

async function publicJob(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: job, error } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, published_at')
      .eq('id', id).eq('status', 'published').maybeSingle();
    if (error) throw error;
    if (!job) return res.status(404).json({ error: 'Job available nahi hai.' });
    const { data: company, error: companyError } = await supabaseAdmin.from('employer_organizations')
      .select('id, display_name, location, industry, website, about').eq('id', job.organization_id).eq('status', 'approved').maybeSingle();
    if (companyError) throw companyError;
    if (!company) return res.status(404).json({ error: 'Company available nahi hai.' });
    return res.json({ job: { ...job, company } });
  } catch (error) { return next(error); }
}

async function listSavedJobs(req, res, next) {
  try {
    const { data: savedRows, error: savedError } = await supabaseAdmin.from('candidate_saved_jobs')
      .select('id, job_id, created_at')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });
    if (savedError) throw savedError;
    const jobIds = [...new Set((savedRows || []).map((row) => row.job_id))];
    if (!jobIds.length) return res.json({ savedJobs: [] });
    const [{ data: jobs, error: jobsError }, today] = await Promise.all([
      supabaseAdmin.from('employer_jobs')
        .select('id, organization_id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, published_at')
        .in('id', jobIds)
        .eq('status', 'published'),
      new Date().toISOString().slice(0, 10),
    ]);
    if (jobsError) throw jobsError;
    const visibleJobs = (jobs || []).filter((job) => !job.apply_deadline || job.apply_deadline >= today);
    const orgIds = [...new Set(visibleJobs.map((job) => job.organization_id))];
    const { data: organizations, error: orgError } = orgIds.length
      ? await supabaseAdmin.from('employer_organizations').select('id, display_name, location, industry, website').in('id', orgIds).eq('status', 'approved')
      : { data: [], error: null };
    if (orgError) throw orgError;
    const orgMap = new Map((organizations || []).map((organization) => [organization.id, organization]));
    const jobMap = new Map(visibleJobs.map((job) => {
      const company = orgMap.get(job.organization_id);
      return [job.id, company ? { ...job, company } : null];
    }));
    return res.json({
      savedJobs: (savedRows || []).map((row) => ({
        id: row.id,
        job_id: row.job_id,
        created_at: row.created_at,
        job: jobMap.get(row.job_id) || null,
      })),
    });
  } catch (error) { return next(error); }
}

async function saveJob(req, res, next) {
  try {
    const jobId = clean(req.params.id, 80);
    const today = new Date().toISOString().slice(0, 10);
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, apply_deadline, status')
      .eq('id', jobId)
      .eq('status', 'published')
      .maybeSingle();
    if (jobError) throw jobError;
    if (!job || (job.apply_deadline && job.apply_deadline < today)) return res.status(404).json({ error: 'Yeh job save karne ke liye available nahi hai.' });
    const { data: company, error: companyError } = await supabaseAdmin.from('employer_organizations')
      .select('id')
      .eq('id', job.organization_id)
      .eq('status', 'approved')
      .maybeSingle();
    if (companyError) throw companyError;
    if (!company) return res.status(404).json({ error: 'Company ab job save ke liye available nahi hai.' });
    const { data: existing, error: existingError } = await supabaseAdmin.from('candidate_saved_jobs')
      .select('id, created_at')
      .eq('user_id', req.user.id)
      .eq('job_id', jobId)
      .maybeSingle();
    if (existingError) throw existingError;
    if (existing) return res.json({ savedJob: existing, message: 'Job already Saved Jobs mein hai.' });
    const { data, error } = await supabaseAdmin.from('candidate_saved_jobs')
      .insert({ user_id: req.user.id, job_id: jobId })
      .select('id, job_id, created_at')
      .single();
    if (error) {
      if (error.code === '23505') return res.json({ message: 'Job already Saved Jobs mein hai.' });
      throw error;
    }
    return res.status(201).json({ savedJob: data, message: 'Job Saved Jobs mein add ho gayi.' });
  } catch (error) { return next(error); }
}

async function removeSavedJob(req, res, next) {
  try {
    const jobId = clean(req.params.id, 80);
    const { error } = await supabaseAdmin.from('candidate_saved_jobs')
      .delete()
      .eq('user_id', req.user.id)
      .eq('job_id', jobId);
    if (error) throw error;
    return res.json({ message: 'Job Saved Jobs se remove ho gayi.' });
  } catch (error) { return next(error); }
}

async function applyToJob(req, res, next) {
  try {
    const jobId = clean(req.params.id, 80);
    const resumeId = clean(req.body.resume_id, 80);
    const candidateNote = clean(req.body.candidate_note, 2000);
    if (!UUID.test(resumeId)) return res.status(400).json({ error: 'Apply karne ke liye apna resume choose karo.' });
    const today = new Date().toISOString().slice(0, 10);
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title, location, apply_deadline, status').eq('id', jobId).eq('status', 'published').maybeSingle();
    if (jobError) throw jobError;
    if (!job || (job.apply_deadline && job.apply_deadline < today)) return res.status(404).json({ error: 'Job apply ke liye available nahi hai.' });
    const { data: company, error: companyError } = await supabaseAdmin.from('employer_organizations').select('display_name').eq('id', job.organization_id).eq('status', 'approved').maybeSingle();
    if (companyError) throw companyError;
    if (!company) return res.status(404).json({ error: 'Company apply ke liye available nahi hai.' });
    const { data: resume, error: resumeError } = await supabaseAdmin.from('resumes').select('id, title').eq('id', resumeId).eq('user_id', req.user.id).maybeSingle();
    if (resumeError) throw resumeError;
    if (!resume) return res.status(400).json({ error: 'Selected resume aapke account ka nahi hai.' });
    const { data: existing, error: existingError } = await supabaseAdmin.from('employer_job_submissions')
      .select('id').eq('job_id', jobId).eq('candidate_id', req.user.id).maybeSingle();
    if (existingError) throw existingError;
    if (existing) return res.status(400).json({ error: 'Aap is job ke liye already apply kar chuke ho.' });
    const { data: submission, error } = await supabaseAdmin.from('employer_job_submissions')
      .insert({ job_id: jobId, candidate_id: req.user.id, resume_id: resumeId, candidate_note: candidateNote, status: 'submitted' })
      .select()
      .single();
    if (error) throw error;
    const { data: tracker, error: trackerError } = await supabaseAdmin.from('job_applications')
      .insert({ user_id: req.user.id, company: company.display_name, job_title: job.title, job_url: null, location: job.location || '', status: 'applied', applied_at: today, notes: candidateNote, resume_id: resumeId, employer_job_id: jobId })
      .select()
      .single();
    if (trackerError) throw trackerError;
    await supabaseAdmin.from('application_activity_logs').insert({ application_id: tracker.id, user_id: req.user.id, event_type: 'created', to_status: 'applied', message: 'Applied through BanaoCV Employer Portal.' });
    await notifyOrganizationMembers(job.organization_id, {
      notification_type: 'employer_new_applicant',
      title: `New applicant · ${job.title}`,
      message: 'A candidate selected their BanaoCV resume and submitted an application. Review it in the applicant pipeline.',
      action_url: 'employer-applicants.html',
      metadata: { job_id: job.id, submission_id: submission.id },
    });
    return res.status(201).json({ submission, application: tracker, message: 'Application submit ho gayi. Employer response tracker me update hoga.' });
  } catch (error) { return next(error); }
}

async function candidateDirectory(ids) {
  if (!ids.length) return new Map();
  const users = [];
  const perPage = 1000;
  for (let page = 1; page <= 20; page += 1) {
    const chunk = await listAuthUsersPage(page, perPage);
    users.push(...chunk);
    if (chunk.length < perPage) break;
  }
  const { data: profiles, error } = await supabaseAdmin.from('profiles').select('id, full_name, career_title, location, avatar_path').in('id', ids);
  if (error) throw error;
  const profileMap = new Map((profiles || []).map((profile) => [profile.id, profile]));
  return new Map(users.filter((user) => ids.includes(user.id)).map((user) => {
    const profile = profileMap.get(user.id) || {};
    return [user.id, { id: user.id, name: profile.full_name || user.user_metadata?.name || 'Candidate', email: user.email || '', career_title: profile.career_title || '', location: profile.location || '' }];
  }));
}

async function employerSubmissions(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const jobId = clean(req.params.id, 80);
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs').select('id, title, organization_id').eq('id', jobId).eq('organization_id', context.organization.id).maybeSingle();
    if (jobError) throw jobError;
    if (!job) return res.status(404).json({ error: 'Job nahi mili.' });
    const { data: submissions, error } = await supabaseAdmin.from('employer_job_submissions')
      .select('id, candidate_id, resume_id, candidate_note, employer_note, status, created_at, updated_at').eq('job_id', jobId).order('updated_at', { ascending: false });
    if (error) throw error;
    const candidates = await candidateDirectory([...new Set((submissions || []).filter((item) => item.status !== 'withdrawn').map((item) => item.candidate_id))]);
    return res.json({ job, submissions: (submissions || []).map((item) => {
      if (item.status === 'withdrawn') return {
        ...item,
        resume_id: null,
        candidate_note: 'Candidate withdrew this application.',
        resume_available: false,
        candidate: { name: 'Candidate withdrew application', email: '', career_title: '', location: '' },
      };
      return { ...item, resume_available: true, candidate: candidates.get(item.candidate_id) || { name: 'Candidate', email: '' } };
    }) });
  } catch (error) { return next(error); }
}

async function updateSubmission(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const id = clean(req.params.id, 80);
    const status = clean(req.body.status, 40);
    const employerNote = clean(req.body.employer_note, 2000);
    if (!EMPLOYER_SUBMISSION_STATUSES.has(status)) return res.status(400).json({ error: 'Employer applicant status valid nahi hai.' });
    const { data: current, error: currentError } = await supabaseAdmin.from('employer_job_submissions')
      .select('id, job_id, candidate_id, status').eq('id', id).maybeSingle();
    if (currentError) throw currentError;
    if (!current) return res.status(404).json({ error: 'Applicant submission nahi mili.' });
    if (current.status === 'withdrawn') return res.status(403).json({ error: 'Candidate ne application withdraw kar li hai. Is submission ka status update nahi kar sakte.' });
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs').select('id, organization_id, title').eq('id', current.job_id).eq('organization_id', context.organization.id).maybeSingle();
    if (jobError) throw jobError;
    if (!job) return res.status(403).json({ error: 'Is applicant par company access nahi hai.' });
    const { data, error } = await supabaseAdmin.from('employer_job_submissions')
      .update({ status, employer_note: employerNote, updated_at: new Date().toISOString() })
      .eq('id', id).select().single();
    if (error) throw error;
    const trackerStatus = status === 'interview' ? 'interview' : status === 'offer' ? 'offer' : status === 'rejected' ? 'rejected' : 'applied';
    const { data: tracker } = await supabaseAdmin.from('job_applications')
      .select('id, status').eq('user_id', current.candidate_id).eq('employer_job_id', current.job_id).maybeSingle();
    if (tracker) {
      await supabaseAdmin.from('job_applications').update({ status: trackerStatus, updated_at: new Date().toISOString() }).eq('id', tracker.id);
      await supabaseAdmin.from('application_activity_logs').insert({ application_id: tracker.id, user_id: current.candidate_id, event_type: 'status_changed', from_status: tracker.status, to_status: trackerStatus, message: `Employer updated application to ${status}.` });
    }
    if (status !== current.status) {
      const label = { shortlisted: 'Shortlisted', interview: 'Interview', offer: 'Offer', rejected: 'Rejected', withdrawn: 'Withdrawn', submitted: 'Received' }[status] || status;
      await safeCreateNotifications([{
        user_id: current.candidate_id,
        notification_type: 'candidate_application_status',
        title: `Application update · ${job.title}`,
        message: `Employer ne aapki application status ${label} update ki hai. Details private Application Tracker mein dekho.`,
        action_url: 'applications.html',
        metadata: { job_id: current.job_id, submission_id: current.id, status },
      }], 'candidate_application_status');
    }
    return res.json({ submission: data, message: 'Applicant status update ho gaya. Candidate tracker sync ho gaya.' });
  } catch (error) { return next(error); }
}

async function submissionResume(req, res, next) {
  try {
    const context = await employerContext(req.user.id);
    if (!context) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const id = clean(req.params.id, 80);
    const { data: submission, error } = await supabaseAdmin.from('employer_job_submissions')
      .select('id, job_id, resume_id, status').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!submission) return res.status(404).json({ error: 'Applicant submission nahi mili.' });
    if (submission.status === 'withdrawn') return res.status(403).json({ error: 'Candidate ne application withdraw kar li hai. Resume access revoke ho gaya.' });
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs').select('organization_id').eq('id', submission.job_id).eq('organization_id', context.organization.id).maybeSingle();
    if (jobError) throw jobError;
    if (!job) return res.status(403).json({ error: 'Resume access available nahi hai.' });
    const { data: resume, error: resumeError } = await supabaseAdmin.from('resumes').select('id, title, template_slug, content, completion_percent, updated_at').eq('id', submission.resume_id).maybeSingle();
    if (resumeError) throw resumeError;
    if (!resume) return res.status(404).json({ error: 'Candidate resume available nahi hai.' });
    return res.json({ resume });
  } catch (error) { return next(error); }
}

module.exports = { listEmployerJobs, createEmployerJob, updateEmployerJob, publicJobs, publicJob, listSavedJobs, saveJob, removeSavedJob, applyToJob, employerSubmissions, updateSubmission, submissionResume, JOB_STATUSES, SUBMISSION_STATUSES };
