const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { supabaseAdmin, supabaseAuth, createAuthClient, listAuthUsersPage } = require('../config/supabase');
const { sendRecoveryEmail } = require('../config/brevo');

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const cleanEmail = (email) => String(email || '').trim().toLowerCase();

function tokenFor(user) {
  return jwt.sign(
    { id: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' },
  );
}

function publicUser(user) {
  return { id: user.id, email: user.email, name: user.user_metadata?.name || user.user_metadata?.full_name || '' };
}

async function signup(req, res, next) {
  try {
    const name = String(req.body.name || '').trim();
    const email = cleanEmail(req.body.email);
    const password = String(req.body.password || '');

    if (name.length < 2 || !EMAIL.test(email) || password.length < 8) {
      return res.status(400).json({ error: 'Naam, valid email aur kam se kam 8 character ka password chahiye.' });
    }

    const { data, error } = await supabaseAuth.auth.signUp({
      email,
      password,
      options: { data: { name } },
    });
    if (error) return res.status(400).json({ error: error.message });

    return res.status(201).json({
      message: 'Account ban gaya. Apne email par verification code check karo.',
      userId: data.user?.id,
      needsVerification: !data.session,
    });
  } catch (error) {
    return next(error);
  }
}

async function login(req, res, next) {
  try {
    const email = cleanEmail(req.body.email);
    const password = String(req.body.password || '');
    if (!EMAIL.test(email) || !password) return res.status(400).json({ error: 'Email aur password dono chahiye.' });

    const { data, error } = await supabaseAuth.auth.signInWithPassword({ email, password });
    if (error || !data.user) return res.status(401).json({ error: 'Email ya password galat hai.' });

    return res.json({ token: tokenFor(data.user), user: publicUser(data.user) });
  } catch (error) {
    return next(error);
  }
}

function safeNextPage(value) {
  const next = String(value || '').trim();
  return /^[a-z0-9-]+\.html(?:\?[^#]*)?$/i.test(next) ? next : 'dashboard.html';
}

function googleRedirectUrl(nextPage) {
  const configured = String(process.env.GOOGLE_OAUTH_REDIRECT_URL || '').trim();
  const fallbackOrigin = String(process.env.FRONTEND_URL || 'https://banaocv.in').split(',')[0].trim() || 'https://banaocv.in';
  const target = new URL(configured || `${fallbackOrigin.replace(/\/$/, '')}/login.html`);
  target.searchParams.set('oauth', 'google');
  target.searchParams.set('next', safeNextPage(nextPage));
  return target.toString();
}

async function googleStart(req, res, next) {
  try {
    const { data, error } = await supabaseAuth.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: googleRedirectUrl(req.body?.next),
        skipBrowserRedirect: true,
      },
    });
    if (error || !data?.url) {
      return res.status(503).json({ error: 'Google sign-in abhi start nahi ho paya. Thodi der baad try karo.' });
    }
    return res.json({ url: data.url });
  } catch (error) { return next(error); }
}

async function googleSession(req, res, next) {
  try {
    const accessToken = String(req.body.access_token || '');
    const refreshToken = String(req.body.refresh_token || '');
    if (!accessToken || !refreshToken) return res.status(400).json({ error: 'Google session details nahi mile. Dobara Google se continue karo.' });

    const oauthClient = createAuthClient();
    const { data, error } = await oauthClient.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
    const user = data?.user;
    if (error || !user) return res.status(401).json({ error: 'Google session verify nahi ho paya. Dobara try karo.' });

    const provider = user.app_metadata?.provider || '';
    const hasGoogleIdentity = (user.identities || []).some((identity) => identity.provider === 'google');
    if (provider !== 'google' && !hasGoogleIdentity) {
      return res.status(400).json({ error: 'Valid Google account session nahi mila.' });
    }
    return res.json({ token: tokenFor(user), user: publicUser(user), message: 'Google se secure login ho gaya.' });
  } catch (error) { return next(error); }
}


async function resendOtp(req, res, next) {
  try {
    const email = cleanEmail(req.body.email);
    if (!EMAIL.test(email)) return res.status(400).json({ error: 'Valid email daalo.' });
    const { error } = await supabaseAuth.auth.resend({ type: 'signup', email });
    if (error) return res.status(400).json({ error: error.message });
    return res.json({ message: 'Naya verification code email par bhej diya gaya hai.' });
  } catch (error) { return next(error); }
}

async function verifyOtp(req, res, next) {
  try {
    const email = cleanEmail(req.body.email);
    const otp = String(req.body.otp || '').trim();
    if (!EMAIL.test(email) || !/^\d{6,10}$/.test(otp)) return res.status(400).json({ error: 'Valid email aur OTP daalo.' });

    const { data, error } = await supabaseAuth.auth.verifyOtp({ email, token: otp, type: 'signup' });
    if (error || !data.user) return res.status(400).json({ error: 'OTP galat ya expire ho gaya hai.' });

    return res.json({ token: tokenFor(data.user), user: publicUser(data.user), message: 'Email verify ho gaya!' });
  } catch (error) {
    return next(error);
  }
}

const PASSWORD_RESET_TOKEN_BYTES = 32;
const PASSWORD_RESET_TTL_MINUTES = Math.min(Math.max(Number(process.env.PASSWORD_RESET_TTL_MINUTES || 20), 10), 60);

function hashResetToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

async function findAuthUserByEmail(email) {
  // Auth users are intentionally separate from public tables. This bounded
  // server-side lookup is safe for the current MVP and never exposes results
  // to the browser. A dedicated indexed account-lookup path can replace it as
  // the user base grows.
  const perPage = 1000;
  const maxPages = 20;
  for (let page = 1; page <= maxPages; page += 1) {
    const users = await listAuthUsersPage(page, perPage);
    const user = users.find((candidate) => cleanEmail(candidate.email) === email);
    if (user) return user;
    if (users.length < perPage) break;
  }
  return null;
}

function recoveryLinkFor(rawToken) {
  const target = new URL(process.env.SUPABASE_REDIRECT_URL || '');
  target.searchParams.set('token', rawToken);
  target.searchParams.set('source', 'banaocv');
  return target.toString();
}

async function issueDirectRecoveryToken(userId) {
  const rawToken = crypto.randomBytes(PASSWORD_RESET_TOKEN_BYTES).toString('hex');
  const tokenHash = hashResetToken(rawToken);
  const expiresAt = new Date(Date.now() + (PASSWORD_RESET_TTL_MINUTES * 60 * 1000)).toISOString();

  // Only the newest unused link remains valid for a user.
  const { error: invalidateError } = await supabaseAdmin
    .from('password_reset_tokens')
    .delete()
    .eq('user_id', userId)
    .is('used_at', null);
  if (invalidateError) throw invalidateError;

  const { error: insertError } = await supabaseAdmin
    .from('password_reset_tokens')
    .insert({ token_hash: tokenHash, user_id: userId, expires_at: expiresAt });
  if (insertError) throw insertError;

  return { rawToken, tokenHash };
}

async function forgotPassword(req, res) {
  const email = cleanEmail(req.body.email);
  if (!EMAIL.test(email)) return res.status(400).json({ error: 'Valid email daalo.' });

  let issuedTokenHash = null;
  try {
    // Do not use Supabase's recovery mailer or generateLink endpoint. BanaoCV
    // generates a short-lived, single-use token and Brevo delivers it directly.
    const user = await findAuthUserByEmail(email);
    if (!user || !user.email_confirmed_at) {
      return res.json({
        message: 'Security ke liye hum account availability confirm nahi karte. Registered account ke liye reset process secure tarike se start hota hai.',
      });
    }

    const issued = await issueDirectRecoveryToken(user.id);
    issuedTokenHash = issued.tokenHash;
    await sendRecoveryEmail({ to: email, actionLink: recoveryLinkFor(issued.rawToken) });

    return res.json({
      message: 'Secure reset link email par bhej diya gaya hai. Spam ya Promotions folder bhi check karo.',
    });
  } catch (error) {
    // If delivery fails, remove the unused token so an unseen link cannot stay
    // active. Never log emails, raw tokens, links or SMTP credentials.
    if (issuedTokenHash) {
      await supabaseAdmin.from('password_reset_tokens').delete().eq('token_hash', issuedTokenHash);
    }
    console.error('Direct recovery-email delivery failed:', error.code || error.name || 'unknown error');
    return res.status(503).json({
      error: 'Reset email abhi send nahi ho paya. Thodi der baad try karo ya supportbanaocv@gmail.com par message bhejo.',
    });
  }
}

async function consumeDirectRecoveryToken(rawToken, password) {
  if (!/^[a-f0-9]{64}$/i.test(rawToken)) return { error: 'Reset link invalid ya expire ho gaya hai. Naya reset link request karo.' };

  // This atomic update makes the token single-use even if two requests arrive
  // at the same time. If password update subsequently fails, the safe recovery
  // action is to request a fresh link.
  const { data: tokenRow, error: consumeError } = await supabaseAdmin
    .from('password_reset_tokens')
    .update({ used_at: new Date().toISOString() })
    .eq('token_hash', hashResetToken(rawToken))
    .is('used_at', null)
    .gt('expires_at', new Date().toISOString())
    .select('user_id')
    .maybeSingle();
  if (consumeError) throw consumeError;
  if (!tokenRow?.user_id) return { error: 'Reset link invalid ya expire ho gaya hai. Naya reset link request karo.' };

  const { data, error } = await supabaseAdmin.auth.admin.updateUserById(tokenRow.user_id, { password });
  if (error || !data.user) throw error || new Error('Password update failed.');
  return { ok: true };
}

async function resetPassword(req, res, next) {
  try {
    const password = String(req.body.password || '');
    const directToken = String(req.body.reset_token || '');
    const accessToken = String(req.body.access_token || '');
    const refreshToken = String(req.body.refresh_token || '');
    if (password.length < 8) return res.status(400).json({ error: 'Naya password kam se kam 8 characters ka hona chahiye.' });

    if (directToken) {
      const result = await consumeDirectRecoveryToken(directToken, password);
      if (result.error) return res.status(400).json({ error: result.error });
      return res.json({ message: 'Password successfully update ho gaya. Ab naye password se login karo.' });
    }

    // Backward-compatible handling for previously issued Supabase recovery links.
    if (!accessToken || !refreshToken) return res.status(400).json({ error: 'Reset link mein recovery session nahi mila. Naya reset link request karo.' });
    const recoveryClient = createAuthClient();
    const { error: sessionError } = await recoveryClient.auth.setSession({
      access_token: accessToken,
      refresh_token: refreshToken,
    });
    if (sessionError) return res.status(400).json({ error: 'Reset link invalid ya expire ho gaya hai. Naya reset link request karo.' });

    const { data, error } = await recoveryClient.auth.updateUser({ password });
    if (error || !data.user) return res.status(400).json({ error: error?.message || 'Password update nahi ho paya.' });
    return res.json({ message: 'Password successfully update ho gaya. Ab naye password se login karo.' });
  } catch (error) { return next(error); }
}

async function me(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin.auth.admin.getUserById(req.user.id);
    if (error || !data.user) return res.status(404).json({ error: 'User nahi mila.' });
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('full_name, plan, plan_activated_at, created_at, updated_at')
      .eq('id', req.user.id)
      .maybeSingle();
    if (profileError) throw profileError;
    return res.json({ user: publicUser(data.user), profile: profile || { plan: 'free' } });
  } catch (error) {
    return next(error);
  }
}

module.exports = { signup, login, googleStart, googleSession, resendOtp, verifyOtp, forgotPassword, resetPassword, me };
