const { getAI, createChatCompletion } = require('../config/openai');
const { supabaseAdmin } = require('../config/supabase');

const clean = (value, max) => String(value || '').trim().slice(0, max);
const safeJson = (value, fallback = {}) => {
  try { return JSON.parse(String(value || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')); } catch { return fallback; }
};

const ACTIONS = {
  dashboard: { label: 'Dashboard kholo', href: 'dashboard.html' },
  resume_editor: { label: 'Resume Editor kholo', href: 'editor.html' },
  templates: { label: 'Templates dekho', href: 'templates.html' },
  applications: { label: 'Applications kholo', href: 'applications.html' },
  jobs: { label: 'Jobs dekho', href: 'jobs.html' },
  saved_jobs: { label: 'Saved Jobs kholo', href: 'saved-jobs.html' },
  settings: { label: 'Settings kholo', href: 'settings.html' },
  support: { label: 'Support kholo', href: 'support.html' },
  cover_letter: { label: 'Cover Letter banao', href: 'editor.html' },
  ai_guide: { label: 'BanaoCV Guide kholo', href: 'ai-guide.html' },
};

async function askJson(system, payload) {
  const ai = getAI();
  const response = await createChatCompletion(ai, {
    model: ai.model,
    messages: [{ role: 'system', content: system }, { role: 'user', content: JSON.stringify(payload) }],
    temperature: 0.15,
    max_tokens: Math.min(ai.maxTokens, 900),
  });
  return safeJson(response.choices?.[0]?.message?.content, {});
}

async function queryOrFallback(query, fallback) {
  try {
    const response = await query;
    return response?.error ? fallback : (response?.data ?? fallback);
  } catch { return fallback; }
}

async function safeContext(userId) {
  const [profile, resumes, applications, savedJobs] = await Promise.all([
    queryOrFallback(supabaseAdmin.from('profiles').select('full_name, plan, career_title, location, career_goal, role').eq('id', userId).maybeSingle(), {}),
    queryOrFallback(supabaseAdmin.from('resumes').select('id, completion_percent').eq('user_id', userId), []),
    queryOrFallback(supabaseAdmin.from('job_applications').select('status').eq('user_id', userId), []),
    queryOrFallback(supabaseAdmin.from('candidate_saved_jobs').select('id').eq('user_id', userId), []),
  ]);
  const applicationCounts = {};
  applications.forEach((item) => { applicationCounts[item.status] = (applicationCounts[item.status] || 0) + 1; });
  return {
    firstName: clean(profile.full_name, 120).split(/\s+/)[0] || 'User',
    plan: profile.plan || 'free',
    careerTitle: clean(profile.career_title, 160),
    location: clean(profile.location, 160),
    hasCareerGoal: Boolean(clean(profile.career_goal, 500)),
    role: profile.role || 'user',
    resumeCount: resumes.length,
    bestResumeCompletion: resumes.length ? Math.max(...resumes.map((row) => Number(row.completion_percent || 0))) : 0,
    applicationCounts,
    savedJobsCount: savedJobs.length,
  };
}

function sanitizedHistory(history) {
  if (!Array.isArray(history)) return [];
  return history.slice(-6).map((item) => ({ role: item?.role === 'assistant' ? 'assistant' : 'user', text: clean(item?.text, 900) })).filter((item) => item.text);
}

function fallbackGuide(message, context) {
  const text = clean(message, 2200).toLowerCase();
  const hello = context.firstName ? `${context.firstName}, ` : '';
  if (/(password|otp|reset|api key|key|card|bank|payment id)/i.test(text)) {
    return { reply: 'Main password, OTP, reset token, API key, card/bank details ya sensitive payment data access nahi karta. Account issue ho toh Support kholo.', action_keys: ['support'] };
  }
  if (/(resume|cv|template|editor|banana|banao)/i.test(text)) {
    return { reply: `${hello}resume banane ke liye Templates mein design choose karo ya Resume Editor kholo. Editor mein Personal Info fill karo, phir Summary, Experience, Education aur Skills add karo.`, action_keys: ['templates', 'resume_editor'] };
  }
  if (/(profile|complete|completion|photo|setting)/i.test(text)) {
    const missing = [];
    if (!context.careerTitle) missing.push('career title');
    if (!context.location) missing.push('location');
    if (!context.hasCareerGoal) missing.push('career goal');
    return { reply: `${hello}profile completion ke liye Settings ya Dashboard ka Complete Profile section kholo.${missing.length ? ` Abhi ${missing.join(', ')} add karna useful rahega.` : ' Aapki core details ready lag rahi hain.'}`, action_keys: ['settings', 'dashboard'] };
  }
  if (/(job|apply|application|tracker|withdraw|follow)/i.test(text)) {
    return { reply: `${hello}job dekhne ke liye Jobs kholo. Apply manually selected resume ke saath hota hai. Applications page par status, follow-up aur withdrawal manage kar sakte ho.`, action_keys: ['jobs', 'applications'] };
  }
  if (/(cover|letter)/i.test(text)) {
    return { reply: 'Cover Letter Composer Editor ke AI panel mein hai. Resume automatically connected rahega; company aur role fill karke preview, copy ya download kar sakte ho.', action_keys: ['cover_letter'] };
  }
  if (/(support|issue|problem|ticket|help)/i.test(text)) {
    return { reply: 'Main support ticket draft bana sakta hoon. Aap problem ka page, visible error aur kya action kiya woh batao; submit se pehle aap ticket edit aur confirm karoge.', action_keys: ['support'], support_draft: { subject: 'BanaoCV help request', category: 'Other', message: clean(message, 1200) } };
  }
  if (/(plan|premium|pro|pricing|payment)/i.test(text)) {
    return { reply: 'Plans aur Premium/Pro features Pricing page par clearly available hain. Payment, refund aur plan actions kabhi automatic nahi hote.', action_keys: ['settings'] };
  }
  return { reply: 'Main BanaoCV ke resume, templates, profile, jobs, applications, cover letter, plans aur support ke baare mein help kar sakta hoon. Aap apna sawaal thoda specific likho ya Support kholo.', action_keys: ['dashboard', 'support'] };
}

function normalizeGuideResult(result, fallback) {
  const reply = clean(result?.reply, 2200);
  const actionKeys = Array.isArray(result?.action_keys) ? result.action_keys.slice(0, 3).filter((key) => ACTIONS[key]) : [];
  const support = result?.support_draft && typeof result.support_draft === 'object' ? {
    subject: clean(result.support_draft.subject, 160),
    category: clean(result.support_draft.category, 80) || 'Other',
    message: clean(result.support_draft.message, 5000),
  } : null;
  if (!reply || !actionKeys.length) return fallback;
  return { reply, action_keys: actionKeys, support_draft: support?.subject && support?.message ? support : null };
}

async function guideChat(req, res, next) {
  try {
    const message = clean(req.body.message, 2200);
    const page = clean(req.body.page, 80);
    if (!message) return res.status(400).json({ error: 'Apna sawaal likho.' });
    const context = await safeContext(req.user.id);
    const fallback = fallbackGuide(message, context);
    const system = `You are BanaoCV Guide, a cautious Hindi/English/Hinglish product assistant. Answer only from this verified BanaoCV map: resume creation is Templates → Editor; profile is Dashboard/Settings; jobs are Jobs; applications are Applications; saved jobs are Saved Jobs; Cover Letter Composer is inside Editor; Support tickets need user confirmation; plans are Pricing/Settings. Never invent features, job results, policies, user facts, account data or payment actions. Never request/reveal password, OTP, token, API key, bank/card data, raw payment IDs, private photo binary, full resume data, another user data, employer applicant data or Admin-sensitive data. Use only these action keys: ${Object.keys(ACTIONS).join(', ')}. If uncertain, provide Support action. Return strict JSON only: {"reply":"","action_keys":[""],"support_draft":null|{"subject":"","category":"","message":""}}.`;
    let normalized = fallback;
    try {
      const result = await askJson(system, { message, page, context, history: sanitizedHistory(req.body.history) });
      normalized = normalizeGuideResult(result, fallback);
    } catch (error) {
      console.warn('BanaoCV Guide provider fallback:', error.code || error.message);
    }
    await supabaseAdmin.from('ai_usage').insert({ user_id: req.user.id, feature: 'guide_chat' }).catch(() => undefined);
    return res.json({
      reply: normalized.reply,
      actions: (normalized.action_keys || []).map((key) => ACTIONS[key]).filter(Boolean),
      support_draft: normalized.support_draft || null,
      context: { firstName: context.firstName, plan: context.plan },
      source: normalized === fallback ? 'fallback' : 'ai',
    });
  } catch (error) { return next(error); }
}

module.exports = { guideChat };
