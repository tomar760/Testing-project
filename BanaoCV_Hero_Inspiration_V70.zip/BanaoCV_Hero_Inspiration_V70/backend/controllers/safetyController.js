const { supabaseAdmin, listAuthUsersPage } = require('../config/supabase');
const { notifySuperAdmins } = require('../utils/notifications');

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TARGET_TYPES = new Set(['job', 'company']);
const REPORT_CATEGORIES = new Set(['fraud', 'fee_demand', 'fake_job', 'harassment', 'suspicious_link', 'misleading', 'other']);
const REPORT_STATUSES = new Set(['open', 'in_review', 'resolved', 'dismissed']);
const ACTIONS = new Set(['none', 'pause_job', 'reject_job', 'suspend_company']);

const clean = (value, max) => String(value || '').trim().slice(0, max);
const isHighPriority = (category) => ['fraud', 'fee_demand', 'fake_job', 'harassment', 'suspicious_link'].includes(category);

async function audit(actorId, action, targetType, targetId, metadata = {}) {
  const { error } = await supabaseAdmin.from('admin_audit_logs').insert({
    actor_id: actorId,
    action: clean(action, 120),
    target_type: clean(targetType, 80),
    target_id: targetId ? String(targetId).slice(0, 180) : null,
    metadata,
  });
  if (error) throw error;
}

async function getReportTarget(targetType, targetId) {
  if (targetType === 'job') {
    const { data: job, error } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title, status')
      .eq('id', targetId)
      .eq('status', 'published')
      .maybeSingle();
    if (error) throw error;
    if (!job) return null;
    const { data: organization, error: orgError } = await supabaseAdmin.from('employer_organizations')
      .select('id, display_name, status')
      .eq('id', job.organization_id)
      .eq('status', 'approved')
      .maybeSingle();
    if (orgError) throw orgError;
    if (!organization) return null;
    return {
      jobId: job.id,
      organizationId: organization.id,
      jobTitle: job.title,
      companyName: organization.display_name,
    };
  }

  const { data: organization, error } = await supabaseAdmin.from('employer_organizations')
    .select('id, display_name, status')
    .eq('id', targetId)
    .eq('status', 'approved')
    .maybeSingle();
  if (error) throw error;
  if (!organization) return null;
  return {
    jobId: null,
    organizationId: organization.id,
    jobTitle: '',
    companyName: organization.display_name,
  };
}

async function createSafetyReport(req, res, next) {
  try {
    const targetType = clean(req.body.target_type, 20);
    const targetId = clean(req.body.target_id, 80);
    const category = clean(req.body.category, 40);
    const details = clean(req.body.details, 4000);

    if (!TARGET_TYPES.has(targetType) || !UUID.test(targetId)) {
      return res.status(400).json({ error: 'Report target valid nahi hai. Job Board se dobara try karo.' });
    }
    if (!REPORT_CATEGORIES.has(category)) return res.status(400).json({ error: 'Report category choose karo.' });
    if (details.length < 10) return res.status(400).json({ error: 'Issue samajhne ke liye kam se kam 10 characters likho.' });

    const target = await getReportTarget(targetType, targetId);
    if (!target) return res.status(404).json({ error: 'Yeh job/company report ke liye ab available nahi hai.' });

    let duplicateQuery = supabaseAdmin.from('employer_safety_reports')
      .select('id')
      .eq('reporter_id', req.user.id)
      .eq('target_type', targetType)
      .eq('category', category)
      .in('status', ['open', 'in_review'])
      .limit(1);
    duplicateQuery = targetType === 'job'
      ? duplicateQuery.eq('job_id', target.jobId)
      : duplicateQuery.eq('organization_id', target.organizationId);
    const { data: duplicate, error: duplicateError } = await duplicateQuery.maybeSingle();
    if (duplicateError) throw duplicateError;
    if (duplicate) return res.status(409).json({ error: 'Is issue ki active report already submit hai. Admin review karega.' });

    const { data, error } = await supabaseAdmin.from('employer_safety_reports')
      .insert({
        reporter_id: req.user.id,
        target_type: targetType,
        job_id: target.jobId,
        organization_id: target.organizationId,
        job_title_snapshot: target.jobTitle,
        company_name_snapshot: target.companyName,
        category,
        priority: isHighPriority(category) ? 'high' : 'normal',
        details,
      })
      .select('id, target_type, category, priority, status, created_at')
      .single();
    if (error) throw error;
    await notifySuperAdmins({
      notification_type: 'safety_report_received',
      title: `${data.priority === 'high' ? 'High priority ' : ''}Trust & Safety report`,
      message: `${target.companyName}${target.jobTitle ? ` · ${target.jobTitle}` : ''} has a new ${category.replaceAll('_', ' ')} report. Review the private Trust & Safety Queue.`,
      action_url: 'admin.html#safety',
      metadata: { report_id: data.id, category, priority: data.priority, target_type: targetType },
    });

    return res.status(201).json({
      report: data,
      message: 'Report securely submit ho gayi. Trust & Safety team review karegi; koi fee ya sensitive details share mat karna.',
    });
  } catch (error) { return next(error); }
}

async function reportDirectory(ids) {
  const requested = [...new Set(ids.filter(Boolean))];
  if (!requested.length) return new Map();
  const authUsers = [];
  for (let page = 1; page <= 20; page += 1) {
    const users = await listAuthUsersPage(page, 1000);
    authUsers.push(...users);
    if (users.length < 1000) break;
  }
  const { data: profiles, error } = await supabaseAdmin.from('profiles')
    .select('id, full_name')
    .in('id', requested);
  if (error) throw error;
  const profileMap = new Map((profiles || []).map((profile) => [profile.id, profile]));
  return new Map(authUsers.filter((user) => requested.includes(user.id)).map((user) => {
    const profile = profileMap.get(user.id) || {};
    return [user.id, {
      id: user.id,
      name: profile.full_name || user.user_metadata?.name || user.user_metadata?.full_name || 'BanaoCV member',
      email: user.email || '',
    }];
  }));
}

async function listSafetyReports(req, res, next) {
  try {
    const status = clean(req.query.status || 'all', 30);
    const category = clean(req.query.category || 'all', 40);
    const targetType = clean(req.query.target_type || 'all', 20);
    if (status !== 'all' && !REPORT_STATUSES.has(status)) return res.status(400).json({ error: 'Safety report status valid nahi hai.' });
    if (category !== 'all' && !REPORT_CATEGORIES.has(category)) return res.status(400).json({ error: 'Safety category valid nahi hai.' });
    if (targetType !== 'all' && !TARGET_TYPES.has(targetType)) return res.status(400).json({ error: 'Safety target type valid nahi hai.' });

    let query = supabaseAdmin.from('employer_safety_reports')
      .select('id, reporter_id, target_type, job_id, organization_id, job_title_snapshot, company_name_snapshot, category, priority, details, status, admin_note, action_taken, reviewed_by, reviewed_at, created_at, updated_at')
      .order('priority', { ascending: false })
      .order('updated_at', { ascending: false });
    if (status !== 'all') query = query.eq('status', status);
    if (category !== 'all') query = query.eq('category', category);
    if (targetType !== 'all') query = query.eq('target_type', targetType);
    const { data, error } = await query;
    if (error) throw error;

    const [reporters, openCountResponse] = await Promise.all([
      reportDirectory((data || []).map((report) => report.reporter_id)),
      supabaseAdmin.from('employer_safety_reports').select('id', { head: true, count: 'exact' }).in('status', ['open', 'in_review']),
    ]);
    if (openCountResponse.error) throw openCountResponse.error;
    const reports = (data || []).map((report) => ({
      ...report,
      reporter: report.reporter_id
        ? (reporters.get(report.reporter_id) || { id: report.reporter_id, name: 'BanaoCV member', email: '' })
        : { id: null, name: 'Deleted account', email: '' },
    })).sort((a, b) => {
      const priority = Number(b.priority === 'high') - Number(a.priority === 'high');
      return priority || new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
    });
    return res.json({ reports, openCount: openCountResponse.count || 0 });
  } catch (error) { return next(error); }
}

async function enforceAction(report, action) {
  if (action === 'none') return;
  if ((action === 'pause_job' || action === 'reject_job') && !report.job_id) {
    const error = new Error('Is company report ke saath job action available nahi hai.');
    error.status = 400;
    throw error;
  }
  if (action === 'suspend_company' && !report.organization_id) {
    const error = new Error('Company target available nahi hai.');
    error.status = 400;
    throw error;
  }

  if (action === 'pause_job' || action === 'reject_job') {
    const status = action === 'pause_job' ? 'paused' : 'rejected';
    const { data, error } = await supabaseAdmin.from('employer_jobs')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', report.job_id)
      .select('id, status, organization_id')
      .maybeSingle();
    if (error) throw error;
    if (!data) {
      const missing = new Error('Target job ab available nahi hai.');
      missing.status = 404;
      throw missing;
    }
    return { targetType: 'employer_job', targetId: data.id, status: data.status };
  }

  const { data, error } = await supabaseAdmin.from('employer_organizations')
    .update({ status: 'suspended', updated_at: new Date().toISOString() })
    .eq('id', report.organization_id)
    .select('id, status')
    .maybeSingle();
  if (error) throw error;
  if (!data) {
    const missing = new Error('Target company ab available nahi hai.');
    missing.status = 404;
    throw missing;
  }
  return { targetType: 'employer_organization', targetId: data.id, status: data.status };
}

async function updateSafetyReport(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const requestedStatus = clean(req.body.status, 30);
    const action = clean(req.body.action || 'none', 30);
    const adminNote = clean(req.body.admin_note, 3000);
    if (!REPORT_STATUSES.has(requestedStatus)) return res.status(400).json({ error: 'Safety report status valid nahi hai.' });
    if (!ACTIONS.has(action)) return res.status(400).json({ error: 'Trust & Safety action valid nahi hai.' });

    const { data: current, error: currentError } = await supabaseAdmin.from('employer_safety_reports')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (currentError) throw currentError;
    if (!current) return res.status(404).json({ error: 'Safety report nahi mili.' });

    const enforcement = await enforceAction(current, action);
    const finalStatus = action === 'none' ? requestedStatus : 'resolved';
    const now = new Date().toISOString();
    const patch = {
      status: finalStatus,
      admin_note: adminNote,
      action_taken: action === 'none' ? current.action_taken : action,
      reviewed_by: req.admin.id,
      reviewed_at: now,
      updated_at: now,
    };
    const { data, error } = await supabaseAdmin.from('employer_safety_reports')
      .update(patch)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;

    await audit(req.admin.id, 'trust_safety_report_updated', 'employer_safety_report', id, {
      status: finalStatus,
      action,
      category: current.category,
      targetType: current.target_type,
    });
    if (enforcement) {
      await audit(req.admin.id, 'trust_safety_enforcement_applied', enforcement.targetType, enforcement.targetId, {
        sourceReportId: id,
        action,
        status: enforcement.status,
      });
    }

    const actionMessage = action === 'none' ? 'Review update save ho gaya.' : `Review save ho gayi aur ${action.replaceAll('_', ' ')} action apply ho gaya.`;
    return res.json({ report: data, message: actionMessage });
  } catch (error) { return next(error); }
}

module.exports = {
  createSafetyReport,
  listSafetyReports,
  updateSafetyReport,
};
