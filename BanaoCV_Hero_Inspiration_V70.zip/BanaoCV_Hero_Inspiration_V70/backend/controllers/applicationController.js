const { supabaseAdmin } = require('../config/supabase');
const { notifyOrganizationMembers } = require('../utils/notifications');

const STATUSES = new Set(['saved', 'applied', 'interview', 'offer', 'rejected', 'withdrawn']);
const URL = /^https?:\/\/[^\s]+$/i;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

const clean = (value, max) => String(value || '').trim().slice(0, max);

async function writeActivity(applicationId, userId, eventType, { fromStatus = null, toStatus = null, message = '' } = {}) {
  const { error } = await supabaseAdmin.from('application_activity_logs').insert({
    application_id: applicationId,
    user_id: userId,
    event_type: eventType,
    from_status: fromStatus,
    to_status: toStatus,
    message: clean(message, 2000),
  });
  if (error) throw error;
}

const dateOrNull = (value) => {
  const text = String(value || '').trim();
  if (!text) return null;
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : undefined;
};

async function ownedResumeId(userId, resumeId) {
  if (!resumeId) return null;
  if (!UUID.test(resumeId)) return undefined;
  const { data, error } = await supabaseAdmin.from('resumes').select('id').eq('id', resumeId).eq('user_id', userId).maybeSingle();
  if (error) throw error;
  return data?.id || undefined;
}

function validate(body) {
  const company = clean(body.company, 120);
  const jobTitle = clean(body.job_title, 160);
  const jobUrl = clean(body.job_url, 1000);
  const location = clean(body.location, 120);
  const notes = clean(body.notes, 4000);
  const status = clean(body.status || 'saved', 30);
  const appliedAt = dateOrNull(body.applied_at);
  const followUpAt = dateOrNull(body.follow_up_at);
  if (company.length < 2 || jobTitle.length < 2) return { error: 'Company aur job title dono daalo.' };
  if (jobUrl && !URL.test(jobUrl)) return { error: 'Job link https:// ya http:// se start hona chahiye.' };
  if (!STATUSES.has(status)) return { error: 'Application status valid nahi hai.' };
  if (appliedAt === undefined || followUpAt === undefined) return { error: 'Date valid format mein daalo.' };
  return { payload: { company, job_title: jobTitle, job_url: jobUrl || null, location, notes, status, applied_at: appliedAt, follow_up_at: followUpAt } };
}

async function listApplications(req, res, next) {
  try {
    const status = clean(req.query.status || 'all', 30);
    const { data, error } = await supabaseAdmin
      .from('job_applications')
      .select('id, company, job_title, job_url, location, status, applied_at, follow_up_at, notes, resume_id, employer_job_id, created_at, updated_at')
      .eq('user_id', req.user.id)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    const applications = status !== 'all' ? (data || []).filter((item) => item.status === status) : (data || []);
    return res.json({ applications });
  } catch (error) { return next(error); }
}

async function applicationSummary(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('job_applications')
      .select('id, company, job_title, status, follow_up_at, updated_at')
      .eq('user_id', req.user.id)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    const applications = data || [];
    const counts = Object.fromEntries([...STATUSES].map((status) => [status, 0]));
    applications.forEach((item) => { counts[item.status] += 1; });
    const today = new Date().toISOString().slice(0, 10);
    const activeStatuses = new Set(['saved', 'applied', 'interview']);
    const overdueFollowUps = applications.filter((item) => item.follow_up_at && item.follow_up_at < today && activeStatuses.has(item.status));
    const dueTodayFollowUps = applications.filter((item) => item.follow_up_at === today && activeStatuses.has(item.status));
    const upcomingFollowUps = applications.filter((item) => item.follow_up_at && item.follow_up_at > today && activeStatuses.has(item.status)).sort((a, b) => a.follow_up_at.localeCompare(b.follow_up_at)).slice(0, 3);
    const followUps = [...overdueFollowUps, ...dueTodayFollowUps, ...upcomingFollowUps].slice(0, 4);
    return res.json({
      total: applications.length,
      counts,
      overdueFollowUps: overdueFollowUps.length,
      dueTodayFollowUps: dueTodayFollowUps.length,
      followUps,
      recent: applications.slice(0, 3),
    });
  } catch (error) { return next(error); }
}

async function createApplication(req, res, next) {
  try {
    const validation = validate(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const resumeId = await ownedResumeId(req.user.id, req.body.resume_id);
    if (resumeId === undefined) return res.status(400).json({ error: 'Selected resume aapke account ka nahi hai.' });
    const { data, error } = await supabaseAdmin.from('job_applications').insert({
      user_id: req.user.id,
      ...validation.payload,
      resume_id: resumeId,
    }).select().single();
    if (error) throw error;
    await writeActivity(data.id, req.user.id, 'created', { toStatus: data.status, message: 'Application tracker mein add ki gayi.' });
    return res.status(201).json({ application: data, message: 'Application tracker mein save ho gayi.' });
  } catch (error) { return next(error); }
}

async function updateApplication(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: existing, error: existingError } = await supabaseAdmin.from('job_applications')
      .select('id, status, follow_up_at, notes, employer_job_id').eq('id', id).eq('user_id', req.user.id).maybeSingle();
    if (existingError) throw existingError;
    if (!existing) return res.status(404).json({ error: 'Application nahi mili.' });
    if (existing.employer_job_id) return res.status(400).json({ error: 'Employer portal application ko manually edit nahi kar sakte. Withdraw action available hai.' });
    const validation = validate(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const resumeId = await ownedResumeId(req.user.id, req.body.resume_id);
    if (resumeId === undefined) return res.status(400).json({ error: 'Selected resume aapke account ka nahi hai.' });
    const { data, error } = await supabaseAdmin.from('job_applications').update({
      ...validation.payload,
      resume_id: resumeId,
      updated_at: new Date().toISOString(),
    }).eq('id', id).eq('user_id', req.user.id).select().maybeSingle();
    if (error) throw error;
    if (existing.status !== data.status) {
      await writeActivity(data.id, req.user.id, 'status_changed', { fromStatus: existing.status, toStatus: data.status, message: `Status changed to ${data.status}.` });
    } else if (existing.follow_up_at !== data.follow_up_at) {
      await writeActivity(data.id, req.user.id, 'follow_up_set', { toStatus: data.status, message: data.follow_up_at ? `Follow-up set for ${data.follow_up_at}.` : 'Follow-up date cleared.' });
    } else {
      await writeActivity(data.id, req.user.id, 'updated', { toStatus: data.status, message: 'Application details updated.' });
    }
    return res.json({ application: data, message: 'Application update ho gayi.' });
  } catch (error) { return next(error); }
}

async function applicationTimeline(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: application, error: applicationError } = await supabaseAdmin.from('job_applications')
      .select('id, company, job_title, status, follow_up_at, notes, updated_at').eq('id', id).eq('user_id', req.user.id).maybeSingle();
    if (applicationError) throw applicationError;
    if (!application) return res.status(404).json({ error: 'Application nahi mili.' });
    const { data: activities, error } = await supabaseAdmin.from('application_activity_logs')
      .select('id, event_type, from_status, to_status, message, created_at')
      .eq('application_id', id)
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return res.json({ application, activities: activities || [] });
  } catch (error) { return next(error); }
}

async function withdrawEmployerApplication(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: application, error: applicationError } = await supabaseAdmin.from('job_applications')
      .select('id, employer_job_id, status, company, job_title')
      .eq('id', id)
      .eq('user_id', req.user.id)
      .maybeSingle();
    if (applicationError) throw applicationError;
    if (!application) return res.status(404).json({ error: 'Application nahi mili.' });
    if (!application.employer_job_id) return res.status(400).json({ error: 'Manual tracker entry withdraw nahi hoti. Isse Remove action se delete kar sakte ho.' });
    if (application.status === 'withdrawn') return res.json({ message: 'Application already withdrawn hai.' });

    const { data: submission, error: submissionError } = await supabaseAdmin.from('employer_job_submissions')
      .select('id, job_id, status')
      .eq('job_id', application.employer_job_id)
      .eq('candidate_id', req.user.id)
      .maybeSingle();
    if (submissionError) throw submissionError;
    if (!submission) return res.status(404).json({ error: 'Employer application submission nahi mili.' });
    const { data: job, error: jobError } = await supabaseAdmin.from('employer_jobs')
      .select('id, organization_id, title')
      .eq('id', application.employer_job_id)
      .maybeSingle();
    if (jobError) throw jobError;
    if (!job) return res.status(404).json({ error: 'Employer job available nahi hai.' });

    const now = new Date().toISOString();
    const { error: submissionUpdateError } = await supabaseAdmin.from('employer_job_submissions')
      .update({ status: 'withdrawn', updated_at: now })
      .eq('id', submission.id)
      .eq('candidate_id', req.user.id);
    if (submissionUpdateError) throw submissionUpdateError;
    const { data: updated, error: updateError } = await supabaseAdmin.from('job_applications')
      .update({ status: 'withdrawn', follow_up_at: null, updated_at: now })
      .eq('id', id)
      .eq('user_id', req.user.id)
      .select()
      .single();
    if (updateError) throw updateError;
    await writeActivity(id, req.user.id, 'status_changed', {
      fromStatus: application.status,
      toStatus: 'withdrawn',
      message: 'Candidate withdrew this BanaoCV employer application. Employer resume access was revoked.',
    });
    await notifyOrganizationMembers(job.organization_id, {
      notification_type: 'candidate_application_withdrawn',
      title: `Candidate withdrew · ${job.title}`,
      message: 'A candidate withdrew their application. Their selected resume is no longer available in the applicant pipeline.',
      action_url: 'employer-applicants.html',
      metadata: { job_id: job.id, submission_id: submission.id },
    });
    return res.json({ application: updated, message: 'Application withdraw ho gayi. Employer resume access revoke ho gaya.' });
  } catch (error) { return next(error); }
}

async function deleteApplication(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: existing, error: existingError } = await supabaseAdmin.from('job_applications')
      .select('id, employer_job_id')
      .eq('id', id)
      .eq('user_id', req.user.id)
      .maybeSingle();
    if (existingError) throw existingError;
    if (!existing) return res.status(404).json({ error: 'Application nahi mili.' });
    if (existing.employer_job_id) return res.status(400).json({ error: 'Employer job application ko Remove nahi kar sakte. Withdraw action use karo, jisse employer access bhi revoke ho.' });
    const { error } = await supabaseAdmin.from('job_applications').delete().eq('id', id).eq('user_id', req.user.id);
    if (error) throw error;
    return res.json({ message: 'Application tracker se remove ho gayi.' });
  } catch (error) { return next(error); }
}

module.exports = { listApplications, applicationSummary, createApplication, updateApplication, applicationTimeline, withdrawEmployerApplication, deleteApplication, STATUSES };
