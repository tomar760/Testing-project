const { supabaseAdmin } = require('../config/supabase');

const clean = (value, max) => String(value || '').trim().slice(0, max);

async function publicCompany(req, res, next) {
  try {
    const id = clean(req.params.id, 80);
    const { data: company, error: companyError } = await supabaseAdmin.from('employer_organizations')
      .select('id, display_name, location, industry, company_size, website, about, created_at')
      .eq('id', id)
      .eq('status', 'approved')
      .maybeSingle();
    if (companyError) throw companyError;
    if (!company) return res.status(404).json({ error: 'Verified company available nahi hai.' });
    const today = new Date().toISOString().slice(0, 10);
    const { data: jobs, error: jobsError } = await supabaseAdmin.from('employer_jobs')
      .select('id, title, location, employment_type, experience_level, salary_min, salary_max, currency, skills, description, apply_deadline, published_at')
      .eq('organization_id', company.id)
      .eq('status', 'published')
      .order('published_at', { ascending: false });
    if (jobsError) throw jobsError;
    return res.json({
      company,
      jobs: (jobs || []).filter((job) => !job.apply_deadline || job.apply_deadline >= today),
    });
  } catch (error) { return next(error); }
}

module.exports = { publicCompany };
