const { supabaseAdmin } = require('../config/supabase');

const FIELDS = ['full_name', 'phone', 'location', 'career_title', 'preferred_language', 'career_goal', 'notification_preferences'];
const PHOTO_BUCKET = 'profile-photos';
const MAX_PHOTO_BYTES = 4 * 1024 * 1024;
const PHOTO_TYPES = new Map([
  ['image/jpeg', 'jpg'],
  ['image/png', 'png'],
  ['image/webp', 'webp'],
]);

async function signedAvatarUrl(avatarPath) {
  if (!avatarPath) return null;
  const { data, error } = await supabaseAdmin.storage.from(PHOTO_BUCKET).createSignedUrl(avatarPath, 60 * 60);
  if (error || !data?.signedUrl) return null;
  const separator = data.signedUrl.includes('?') ? '&' : '?';
  return `${data.signedUrl}${separator}v=${Date.now()}`;
}

async function presentProfile(profile) {
  if (!profile) return { plan: 'free', avatar_url: null };
  return { ...profile, avatar_url: await signedAvatarUrl(profile.avatar_path) };
}

async function getProfile(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('profiles')
      .select('full_name, phone, location, career_title, preferred_language, career_goal, avatar_path, notification_preferences, plan, plan_activated_at, ai_credits_remaining, role, created_at, updated_at')
      .eq('id', req.user.id)
      .maybeSingle();
    if (error) throw error;
    return res.json({ profile: await presentProfile(data) });
  } catch (error) { return next(error); }
}

async function updateProfile(req, res, next) {
  try {
    const patch = {};
    FIELDS.forEach((key) => { if (req.body[key] !== undefined) patch[key] = req.body[key]; });
    if (patch.full_name !== undefined) {
      patch.full_name = String(patch.full_name).trim().slice(0, 120);
      if (patch.full_name.length < 2) return res.status(400).json({ error: 'Valid naam daalo.' });
    }
    ['phone', 'location', 'career_title', 'preferred_language', 'career_goal'].forEach((key) => {
      if (patch[key] !== undefined) patch[key] = String(patch[key]).trim().slice(0, key === 'career_goal' ? 500 : 160);
    });
    if (patch.notification_preferences !== undefined && (typeof patch.notification_preferences !== 'object' || Array.isArray(patch.notification_preferences))) {
      return res.status(400).json({ error: 'Notification settings valid nahi hain.' });
    }
    if (!Object.keys(patch).length) return res.status(400).json({ error: 'Koi profile change nahi mila.' });
    patch.updated_at = new Date().toISOString();
    const { data, error } = await supabaseAdmin.from('profiles').update(patch).eq('id', req.user.id).select().single();
    if (error) throw error;
    return res.json({ profile: await presentProfile(data), message: 'Profile save ho gaya.' });
  } catch (error) { return next(error); }
}

async function uploadProfilePhoto(req, res, next) {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'JPG, PNG ya WebP photo choose karo.' });
    const extension = PHOTO_TYPES.get(file.mimetype);
    if (!extension || !file.buffer || file.size > MAX_PHOTO_BYTES) {
      return res.status(400).json({ error: 'Photo JPG, PNG ya WebP aur maximum 4 MB honi chahiye.' });
    }

    const { data: existing, error: existingError } = await supabaseAdmin
      .from('profiles').select('avatar_path').eq('id', req.user.id).maybeSingle();
    if (existingError) throw existingError;
    const avatarPath = `${req.user.id}/profile.${extension}`;

    if (existing?.avatar_path && existing.avatar_path !== avatarPath) {
      const { error: removeOldError } = await supabaseAdmin.storage.from(PHOTO_BUCKET).remove([existing.avatar_path]);
      if (removeOldError) console.warn('Old profile photo cleanup failed:', removeOldError.code || removeOldError.message);
    }

    const { error: uploadError } = await supabaseAdmin.storage.from(PHOTO_BUCKET).upload(avatarPath, file.buffer, {
      contentType: file.mimetype,
      upsert: true,
      cacheControl: '3600',
    });
    if (uploadError) throw uploadError;

    const { data, error } = await supabaseAdmin.from('profiles')
      .update({ avatar_path: avatarPath, updated_at: new Date().toISOString() })
      .eq('id', req.user.id)
      .select()
      .single();
    if (error) throw error;
    return res.json({ profile: await presentProfile(data), message: 'Profile photo safely update ho gayi.' });
  } catch (error) {
    if (error?.message?.toLowerCase().includes('bucket')) {
      return res.status(503).json({ error: 'Photo storage abhi setup ho raha hai. Thodi der baad try karo.' });
    }
    return next(error);
  }
}

async function removeProfilePhoto(req, res, next) {
  try {
    const { data: existing, error: existingError } = await supabaseAdmin
      .from('profiles').select('avatar_path').eq('id', req.user.id).maybeSingle();
    if (existingError) throw existingError;
    if (existing?.avatar_path) {
      const { error: removeError } = await supabaseAdmin.storage.from(PHOTO_BUCKET).remove([existing.avatar_path]);
      if (removeError) throw removeError;
    }
    const { data, error } = await supabaseAdmin.from('profiles')
      .update({ avatar_path: null, updated_at: new Date().toISOString() })
      .eq('id', req.user.id)
      .select()
      .single();
    if (error) throw error;
    return res.json({ profile: await presentProfile(data), message: 'Profile photo remove ho gayi.' });
  } catch (error) { return next(error); }
}

async function downloadMyData(req, res, next) {
  try {
    const [profileResponse, resumesResponse, applicationsResponse, ticketsResponse, paymentsResponse, deletionResponse] = await Promise.all([
      supabaseAdmin.from('profiles').select('full_name, phone, location, career_title, preferred_language, career_goal, avatar_path, notification_preferences, plan, plan_activated_at, created_at, updated_at').eq('id', req.user.id).maybeSingle(),
      supabaseAdmin.from('resumes').select('id, title, template_slug, content, design, completion_percent, created_at, updated_at').eq('user_id', req.user.id).order('updated_at', { ascending: false }),
      supabaseAdmin.from('job_applications').select('id, company, job_title, job_url, location, status, applied_at, follow_up_at, notes, resume_id, created_at, updated_at').eq('user_id', req.user.id).order('updated_at', { ascending: false }),
      supabaseAdmin.from('support_tickets').select('id, subject, category, message, status, priority, admin_reply, created_at, updated_at').eq('user_id', req.user.id).order('created_at', { ascending: false }),
      supabaseAdmin.from('payments').select('id, plan, razorpay_order_id, razorpay_payment_id, amount, currency, status, paid_at, created_at').eq('user_id', req.user.id).order('created_at', { ascending: false }),
      supabaseAdmin.from('account_deletion_requests').select('id, status, reason, admin_note, requested_at, resolved_at, updated_at').eq('user_id', req.user.id).order('requested_at', { ascending: false }),
    ]);
    [profileResponse, resumesResponse, applicationsResponse, ticketsResponse, paymentsResponse, deletionResponse].forEach((response) => { if (response.error) throw response.error; });
    const payload = {
      export_format: 'BanaoCV user data export v1',
      generated_at: new Date().toISOString(),
      account: { id: req.user.id, email: req.user.email || '' },
      profile: profileResponse.data || null,
      resumes: resumesResponse.data || [],
      applications: applicationsResponse.data || [],
      support_tickets: ticketsResponse.data || [],
      payments: paymentsResponse.data || [],
      account_deletion_requests: deletionResponse.data || [],
      notes: ['Payment export contains BanaoCV payment references only, never card/bank information.', 'Profile photo binary is stored privately and is not embedded in this JSON export.'],
    };
    const filename = `BanaoCV-My-Data-${new Date().toISOString().slice(0, 10)}.json`;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(JSON.stringify(payload, null, 2));
  } catch (error) { return next(error); }
}

async function getDeletionRequest(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin.from('account_deletion_requests')
      .select('id, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .eq('user_id', req.user.id)
      .order('requested_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    return res.json({ request: data || null });
  } catch (error) { return next(error); }
}

async function createDeletionRequest(req, res, next) {
  try {
    const { data: existing, error: existingError } = await supabaseAdmin.from('account_deletion_requests')
      .select('id, status, requested_at')
      .eq('user_id', req.user.id)
      .in('status', ['requested', 'in_review', 'approved'])
      .maybeSingle();
    if (existingError) throw existingError;
    if (existing) return res.json({ request: existing, message: 'Aapki account deletion request already review mein hai.' });
    const reason = String(req.body.reason || '').trim().slice(0, 1000);
    const { data, error } = await supabaseAdmin.from('account_deletion_requests')
      .insert({ user_id: req.user.id, reason })
      .select('id, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .single();
    if (error) throw error;
    return res.status(201).json({ request: data, message: 'Account deletion request submit ho gayi. Support/Admin review ke baad next step milega.' });
  } catch (error) { return next(error); }
}

async function cancelDeletionRequest(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin.from('account_deletion_requests')
      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
      .eq('user_id', req.user.id)
      .in('status', ['requested', 'in_review'])
      .select('id, status, reason, admin_note, requested_at, resolved_at, updated_at')
      .maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: 'Active deletion request nahi mili.' });
    return res.json({ request: data, message: 'Account deletion request cancel ho gayi.' });
  } catch (error) { return next(error); }
}

module.exports = { getProfile, updateProfile, uploadProfilePhoto, removeProfilePhoto, downloadMyData, getDeletionRequest, createDeletionRequest, cancelDeletionRequest };
