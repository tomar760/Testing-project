const crypto = require('crypto');
const { supabaseAdmin } = require('../config/supabase');

const URL = /^https?:\/\/[^\s]+$/i;

const clean = (value, max) => String(value || '').trim().slice(0, max);
const slugify = (value) => clean(value, 120).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 76);

function validate(body) {
  const legalName = clean(body.legal_name, 180);
  const displayName = clean(body.display_name, 120);
  const website = clean(body.website, 1000);
  const linkedin = clean(body.linkedin_url, 1000);
  const location = clean(body.location, 120);
  const industry = clean(body.industry, 120);
  const companySize = clean(body.company_size, 80);
  const about = clean(body.about, 3000);
  if (legalName.length < 2 || displayName.length < 2) return { error: 'Legal company name aur display name dono daalo.' };
  if (website && !URL.test(website)) return { error: 'Company website http:// ya https:// se start honi chahiye.' };
  if (linkedin && !URL.test(linkedin)) return { error: 'LinkedIn link http:// ya https:// se start honi chahiye.' };
  return { payload: { legal_name: legalName, display_name: displayName, website: website || null, linkedin_url: linkedin || null, location, industry, company_size: companySize, about } };
}

async function membershipFor(userId) {
  const { data: membership, error } = await supabaseAdmin.from('employer_members')
    .select('id, organization_id, member_role, status')
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (error) throw error;
  return membership || null;
}

async function employerPayload(userId) {
  const membership = await membershipFor(userId);
  if (!membership) return { employer: null };
  const { data: organization, error } = await supabaseAdmin.from('employer_organizations')
    .select('id, legal_name, display_name, slug, website, linkedin_url, location, industry, company_size, about, status, verification_note, created_at, updated_at')
    .eq('id', membership.organization_id)
    .maybeSingle();
  if (error) throw error;
  return { employer: organization ? { organization, membership } : null };
}

async function getEmployerMe(req, res, next) {
  try { return res.json(await employerPayload(req.user.id)); } catch (error) { return next(error); }
}

async function onboardEmployer(req, res, next) {
  try {
    const existing = await membershipFor(req.user.id);
    if (existing) return res.status(400).json({ error: 'Aapka employer organization already active hai.' });
    const validation = validate(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const base = slugify(validation.payload.display_name) || 'company';
    const slug = `${base}-${crypto.randomBytes(3).toString('hex')}`;
    const { data: organization, error: orgError } = await supabaseAdmin.from('employer_organizations')
      .insert({ ...validation.payload, slug, status: 'pending_verification' })
      .select()
      .single();
    if (orgError) throw orgError;
    const { data: membership, error: memberError } = await supabaseAdmin.from('employer_members')
      .insert({ organization_id: organization.id, user_id: req.user.id, member_role: 'owner' })
      .select()
      .single();
    if (memberError) {
      await supabaseAdmin.from('employer_organizations').delete().eq('id', organization.id);
      throw memberError;
    }
    return res.status(201).json({ employer: { organization, membership }, message: 'Company profile submit ho gayi. Admin verification ke baad job posting unlock hogi.' });
  } catch (error) { return next(error); }
}

async function updateEmployer(req, res, next) {
  try {
    const membership = await membershipFor(req.user.id);
    if (!membership || membership.member_role !== 'owner') return res.status(403).json({ error: 'Sirf company owner profile update kar sakta hai.' });
    const { data: current, error: currentError } = await supabaseAdmin.from('employer_organizations')
      .select('status').eq('id', membership.organization_id).maybeSingle();
    if (currentError) throw currentError;
    if (!current) return res.status(404).json({ error: 'Company profile nahi mili.' });
    if (current.status === 'suspended') return res.status(403).json({ error: 'Suspended company profile update nahi kar sakti. Support se contact karo.' });
    const validation = validate(req.body);
    if (validation.error) return res.status(400).json({ error: validation.error });
    const { data: organization, error } = await supabaseAdmin.from('employer_organizations')
      .update({ ...validation.payload, updated_at: new Date().toISOString() })
      .eq('id', membership.organization_id)
      .select()
      .single();
    if (error) throw error;
    return res.json({ employer: { organization, membership }, message: 'Company profile update ho gayi.' });
  } catch (error) { return next(error); }
}

async function getEmployerAnalytics(req, res, next) {
  try {
    const payload = await employerPayload(req.user.id);
    if (!payload.employer) return res.status(403).json({ error: 'Employer portal profile nahi mila.' });
    const { organization } = payload.employer;
    const { data: jobs, error: jobsError } = await supabaseAdmin.from('employer_jobs')
      .select('id, status, updated_at')
      .eq('organization_id', organization.id);
    if (jobsError) throw jobsError;
    const jobIds = (jobs || []).map((job) => job.id);
    const [submissionsResponse, reportsResponse] = await Promise.all([
      jobIds.length
        ? supabaseAdmin.from('employer_job_submissions').select('id, status, job_id, created_at, updated_at').in('job_id', jobIds)
        : { data: [], error: null },
      supabaseAdmin.from('employer_safety_reports').select('id, status').eq('organization_id', organization.id),
    ]);
    if (submissionsResponse.error) throw submissionsResponse.error;
    if (reportsResponse.error) throw reportsResponse.error;
    const jobCounts = Object.fromEntries(['draft', 'pending_review', 'published', 'paused', 'rejected', 'expired'].map((key) => [key, 0]));
    (jobs || []).forEach((job) => { jobCounts[job.status] = (jobCounts[job.status] || 0) + 1; });
    const submissionCounts = Object.fromEntries(['submitted', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn'].map((key) => [key, 0]));
    (submissionsResponse.data || []).forEach((submission) => { submissionCounts[submission.status] = (submissionCounts[submission.status] || 0) + 1; });
    const openSafetyReports = (reportsResponse.data || []).filter((report) => ['open', 'in_review'].includes(report.status)).length;
    return res.json({
      organization,
      jobCounts,
      submissionCounts,
      totalApplicants: (submissionsResponse.data || []).length,
      openSafetyReports,
    });
  } catch (error) { return next(error); }
}

module.exports = { getEmployerMe, onboardEmployer, updateEmployer, getEmployerAnalytics };
