require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { apiLimiter } = require('./middleware/rateLimit');
const paymentController = require('./controllers/paymentController');
const authRoutes = require('./routes/auth');
const resumeRoutes = require('./routes/resume');
const aiRoutes = require('./routes/ai');
const paymentRoutes = require('./routes/payment');
const profileRoutes = require('./routes/profile');
const supportRoutes = require('./routes/support');
const adminRoutes = require('./routes/admin');
const applicationRoutes = require('./routes/applications');
const employerRoutes = require('./routes/employer');
const jobsRoutes = require('./routes/jobs');
const safetyRoutes = require('./routes/safety');
const notificationRoutes = require('./routes/notifications');
const companyRoutes = require('./routes/companies');
const guideRoutes = require('./routes/guide');

const app = express();
app.set('trust proxy', 1);

const origins = (process.env.FRONTEND_URL || '').split(',').map((value) => value.trim()).filter(Boolean);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  credentials: true,
  origin(origin, callback) {
    if (!origin || origins.includes(origin)) return callback(null, true);
    return callback(new Error('This origin is not allowed by CORS.'));
  },
}));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Razorpay requires the unparsed request body to verify webhook signatures.
app.post('/api/payment/webhook', express.raw({ type: 'application/json' }), paymentController.webhook);
app.use(express.json({ limit: '1mb' }));
app.use('/api', apiLimiter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'BanaoCV API', timestamp: new Date().toISOString() }));
app.use('/api/auth', authRoutes);
app.use('/api/resume', resumeRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/support', supportRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/employer', employerRoutes);
app.use('/api/jobs', jobsRoutes);
app.use('/api/safety', safetyRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/companies', companyRoutes);
app.use('/api/guide', guideRoutes);
app.use('/api/admin', adminRoutes);

app.use((req, res) => res.status(404).json({ error: 'Route nahi mila.' }));
app.use((error, req, res, next) => {
  console.error(error);
  const status = error.status || (error.message === 'This origin is not allowed by CORS.' ? 403 : 500);
  res.status(status).json({ error: status === 500 ? 'Server mein kuch galat ho gaya. Baad mein try karo.' : error.message });
});

const port = Number(process.env.PORT || 5000);
app.listen(port, () => console.log(`BanaoCV API listening on port ${port}`));
