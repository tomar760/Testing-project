-- BanaoCV Application Tracker Phase 2
-- Per-application activity timeline and follow-up audit.

create table if not exists public.application_activity_logs (
  id bigint generated always as identity primary key,
  application_id uuid not null references public.job_applications(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null check (event_type in ('created', 'status_changed', 'updated', 'follow_up_set', 'follow_up_completed')),
  from_status text,
  to_status text,
  message text not null default '' check (char_length(message) <= 2000),
  created_at timestamptz not null default now()
);

create index if not exists application_activity_logs_application_created_idx
  on public.application_activity_logs (application_id, created_at desc);
create index if not exists application_activity_logs_user_created_idx
  on public.application_activity_logs (user_id, created_at desc);

alter table public.application_activity_logs enable row level security;
drop policy if exists "application activity own" on public.application_activity_logs;
create policy "application activity own" on public.application_activity_logs
  for select using (auth.uid() = user_id);
