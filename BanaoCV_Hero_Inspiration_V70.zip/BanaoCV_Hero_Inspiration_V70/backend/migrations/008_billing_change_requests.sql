-- BanaoCV billing lifecycle: cancellation/downgrade review requests
-- Run once after migrations 001–007.
-- This does not automatically cancel Razorpay or refund a payment.

create table if not exists public.billing_change_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null default 'cancel_plan' check (request_type in ('cancel_plan', 'downgrade_free')),
  current_plan text not null check (current_plan in ('premium', 'pro_monthly', 'pro_annual')),
  status text not null default 'requested' check (status in ('requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled')),
  reason text not null default '' check (char_length(reason) <= 1000),
  admin_note text not null default '' check (char_length(admin_note) <= 2000),
  requested_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);

create unique index if not exists billing_change_requests_one_active_idx
  on public.billing_change_requests (user_id)
  where status in ('requested', 'in_review', 'approved');
create index if not exists billing_change_requests_status_updated_idx
  on public.billing_change_requests (status, updated_at desc);

alter table public.billing_change_requests enable row level security;
drop policy if exists "billing change requests own" on public.billing_change_requests;
create policy "billing change requests own" on public.billing_change_requests
  for select using (auth.uid() = user_id);

drop trigger if exists billing_change_requests_touch_updated_at on public.billing_change_requests;
create trigger billing_change_requests_touch_updated_at before update on public.billing_change_requests
for each row execute procedure public.touch_updated_at();
