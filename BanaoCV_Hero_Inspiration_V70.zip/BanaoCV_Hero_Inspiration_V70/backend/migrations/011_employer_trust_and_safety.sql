-- BanaoCV Employer Portal Phase 4D
-- Candidate trust & safety reporting, Super Admin review and controlled enforcement.
-- Run once after migration 010.

create table if not exists public.employer_safety_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references auth.users(id) on delete set null,
  target_type text not null check (target_type in ('job', 'company')),
  job_id uuid references public.employer_jobs(id) on delete set null,
  organization_id uuid references public.employer_organizations(id) on delete set null,
  job_title_snapshot text not null default '' check (char_length(job_title_snapshot) <= 160),
  company_name_snapshot text not null default '' check (char_length(company_name_snapshot) <= 120),
  category text not null check (category in ('fraud', 'fee_demand', 'fake_job', 'harassment', 'suspicious_link', 'misleading', 'other')),
  priority text not null default 'normal' check (priority in ('normal', 'high')),
  details text not null check (char_length(details) between 10 and 4000),
  status text not null default 'open' check (status in ('open', 'in_review', 'resolved', 'dismissed')),
  admin_note text not null default '' check (char_length(admin_note) <= 3000),
  action_taken text not null default 'none' check (action_taken in ('none', 'pause_job', 'reject_job', 'suspend_company')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    (target_type = 'job' and job_id is not null)
    or (target_type = 'company' and organization_id is not null)
  )
);

create index if not exists employer_safety_reports_status_updated_idx
  on public.employer_safety_reports (status, priority desc, updated_at desc);
create index if not exists employer_safety_reports_job_idx
  on public.employer_safety_reports (job_id, created_at desc);
create index if not exists employer_safety_reports_org_idx
  on public.employer_safety_reports (organization_id, created_at desc);
create index if not exists employer_safety_reports_reporter_idx
  on public.employer_safety_reports (reporter_id, created_at desc);

alter table public.employer_safety_reports enable row level security;

-- Reports are written/read only through authenticated backend routes.
-- Browser clients do not receive direct table policies.

drop trigger if exists employer_safety_reports_touch_updated_at on public.employer_safety_reports;
create trigger employer_safety_reports_touch_updated_at before update on public.employer_safety_reports
for each row execute procedure public.touch_updated_at();
