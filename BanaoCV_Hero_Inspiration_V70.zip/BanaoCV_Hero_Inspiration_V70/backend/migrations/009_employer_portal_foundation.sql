-- BanaoCV Employer Portal Phase 4A
-- Separate company organizations, members and verification state.
-- Run once after migrations 001–008.

create table if not exists public.employer_organizations (
  id uuid primary key default gen_random_uuid(),
  legal_name text not null check (char_length(legal_name) between 2 and 180),
  display_name text not null check (char_length(display_name) between 2 and 120),
  slug text not null unique check (slug ~ '^[a-z0-9-]{3,90}$'),
  website text,
  linkedin_url text,
  location text not null default '' check (char_length(location) <= 120),
  industry text not null default '' check (char_length(industry) <= 120),
  company_size text not null default '' check (char_length(company_size) <= 80),
  about text not null default '' check (char_length(about) <= 3000),
  status text not null default 'pending_verification' check (status in ('pending_verification', 'approved', 'rejected', 'suspended')),
  verification_note text not null default '' check (char_length(verification_note) <= 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.employer_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.employer_organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'owner' check (member_role in ('owner', 'recruiter', 'hiring_manager')),
  status text not null default 'active' check (status in ('active', 'inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create unique index if not exists employer_members_one_active_org_per_user_idx
  on public.employer_members (user_id)
  where status = 'active';
create index if not exists employer_organizations_status_updated_idx
  on public.employer_organizations (status, updated_at desc);

alter table public.employer_organizations enable row level security;
alter table public.employer_members enable row level security;

-- Browser does not write these tables directly. Backend service role and
-- server-side membership checks mediate all employer actions.

drop trigger if exists employer_organizations_touch_updated_at on public.employer_organizations;
create trigger employer_organizations_touch_updated_at before update on public.employer_organizations
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_members_touch_updated_at on public.employer_members;
create trigger employer_members_touch_updated_at before update on public.employer_members
for each row execute procedure public.touch_updated_at();
