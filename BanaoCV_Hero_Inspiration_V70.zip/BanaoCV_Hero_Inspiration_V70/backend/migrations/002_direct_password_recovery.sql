-- BanaoCV direct Brevo password-recovery tokens
-- Run once in Supabase SQL Editor before deploying the direct recovery flow.
-- Tokens are random, SHA-256 hashed on the server, single-use and expire quickly.

create table if not exists public.password_reset_tokens (
  token_hash text primary key check (char_length(token_hash) = 64),
  user_id uuid not null references auth.users(id) on delete cascade,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists password_reset_tokens_user_active_idx
  on public.password_reset_tokens (user_id, expires_at desc)
  where used_at is null;

-- No browser/client policies: only the BanaoCV backend service-role client may
-- create, consume or invalidate recovery tokens.
alter table public.password_reset_tokens enable row level security;
