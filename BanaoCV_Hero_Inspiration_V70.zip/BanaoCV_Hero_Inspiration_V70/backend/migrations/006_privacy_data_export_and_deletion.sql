-- BanaoCV privacy controls: account deletion request workflow
-- Run once after migrations 001–005.
-- This records a user request; it does not automatically delete an account.

create table if not exists public.account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'requested' check (status in ('requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled')),
  reason text not null default '' check (char_length(reason) <= 1000),
  admin_note text not null default '' check (char_length(admin_note) <= 2000),
  requested_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);

create unique index if not exists account_deletion_requests_one_active_idx
  on public.account_deletion_requests (user_id)
  where status in ('requested', 'in_review', 'approved');
create index if not exists account_deletion_requests_status_updated_idx
  on public.account_deletion_requests (status, updated_at desc);

alter table public.account_deletion_requests enable row level security;
drop policy if exists "deletion requests own" on public.account_deletion_requests;
create policy "deletion requests own" on public.account_deletion_requests
  for select using (auth.uid() = user_id);

drop trigger if exists account_deletion_requests_touch_updated_at on public.account_deletion_requests;
create trigger account_deletion_requests_touch_updated_at before update on public.account_deletion_requests
for each row execute procedure public.touch_updated_at();
