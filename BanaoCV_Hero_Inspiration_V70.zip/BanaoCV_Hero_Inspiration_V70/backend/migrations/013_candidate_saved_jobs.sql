-- BanaoCV Employer Portal Phase 4F
-- Private candidate saved jobs for approved, moderated BanaoCV opportunities.
-- Run once after migration 012.

create table if not exists public.candidate_saved_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid not null references public.employer_jobs(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, job_id)
);

create index if not exists candidate_saved_jobs_user_created_idx
  on public.candidate_saved_jobs (user_id, created_at desc);
create index if not exists candidate_saved_jobs_job_idx
  on public.candidate_saved_jobs (job_id, created_at desc);

alter table public.candidate_saved_jobs enable row level security;

-- Saved jobs are accessed only through authenticated backend routes.
-- Browser clients never receive direct table write policies.
