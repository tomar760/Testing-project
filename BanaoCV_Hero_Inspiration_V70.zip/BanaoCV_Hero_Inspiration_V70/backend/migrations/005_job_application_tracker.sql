-- BanaoCV real Job Application Tracker
-- Run once after migrations 001–004.
-- This is a private manual tracker. It never auto-submits a job application.

create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  company text not null check (char_length(company) between 2 and 120),
  job_title text not null check (char_length(job_title) between 2 and 160),
  job_url text,
  location text not null default '' check (char_length(location) <= 120),
  status text not null default 'saved' check (status in ('saved', 'applied', 'interview', 'offer', 'rejected')),
  applied_at date,
  follow_up_at date,
  notes text not null default '' check (char_length(notes) <= 4000),
  resume_id uuid references public.resumes(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists job_applications_user_updated_idx on public.job_applications (user_id, updated_at desc);
create index if not exists job_applications_user_status_idx on public.job_applications (user_id, status, updated_at desc);
create index if not exists job_applications_follow_up_idx on public.job_applications (user_id, follow_up_at) where follow_up_at is not null;

alter table public.job_applications enable row level security;
drop policy if exists "job applications own" on public.job_applications;
create policy "job applications own" on public.job_applications
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop trigger if exists job_applications_touch_updated_at on public.job_applications;
create trigger job_applications_touch_updated_at before update on public.job_applications
for each row execute procedure public.touch_updated_at();
