-- BanaoCV secure Admin Command Centre
-- Run once in Supabase SQL Editor AFTER migrations 001 and 002.
-- This migration adds no browser-accessible admin policy. All admin access is
-- enforced through BanaoCV's backend service role plus server-side role checks.

-- Existing projects created before the full schema need these fields confirmed.
alter table public.profiles add column if not exists role text not null default 'user';
alter table public.profiles add column if not exists account_status text not null default 'active';

-- Recreate role/status checks in an idempotent manner.
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('user', 'support_agent', 'admin', 'super_admin'));
alter table public.profiles drop constraint if exists profiles_account_status_check;
alter table public.profiles add constraint profiles_account_status_check
  check (account_status in ('active', 'suspended'));

create index if not exists profiles_role_idx on public.profiles (role);
create index if not exists profiles_plan_created_idx on public.profiles (plan, created_at desc);
create index if not exists resumes_updated_idx on public.resumes (updated_at desc);
create index if not exists payments_status_created_idx on public.payments (status, created_at desc);
create index if not exists support_tickets_status_priority_idx on public.support_tickets (status, priority, created_at desc);

-- Each admin-side change writes an immutable append-only row through the API.
create table if not exists public.admin_audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid not null references auth.users(id) on delete restrict,
  action text not null check (char_length(action) between 3 and 120),
  target_type text not null check (char_length(target_type) between 2 and 80),
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists admin_audit_logs_created_idx on public.admin_audit_logs (created_at desc);
create index if not exists admin_audit_logs_actor_idx on public.admin_audit_logs (actor_id, created_at desc);
alter table public.admin_audit_logs enable row level security;

-- Availability setting is server-enforced before a new resume using that
-- template can be created. Missing rows are treated as enabled by default.
create table if not exists public.template_admin_settings (
  slug text primary key check (char_length(slug) between 2 and 80),
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.template_admin_settings enable row level security;

-- OWNER ASSIGNMENT (run privately after the migration, replacing only your
-- own logged-in BanaoCV email; never paste that email into a public repo/chat):
-- update public.profiles set role = 'super_admin'
-- where id = (select id from auth.users where lower(email) = lower('YOUR_EMAIL_HERE'));
