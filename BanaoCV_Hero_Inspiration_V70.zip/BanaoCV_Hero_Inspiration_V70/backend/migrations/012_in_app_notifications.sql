-- BanaoCV Employer Portal Phase 4E
-- Private in-app notifications for candidate, employer and Super Admin workflows.
-- Run once after migration 011.

create table if not exists public.user_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  notification_type text not null check (notification_type in ('employer_new_applicant', 'candidate_application_status', 'safety_report_received', 'system')),
  title text not null check (char_length(title) between 2 and 180),
  message text not null default '' check (char_length(message) <= 1200),
  action_url text not null default '' check (char_length(action_url) <= 500),
  metadata jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists user_notifications_user_created_idx
  on public.user_notifications (user_id, created_at desc);
create index if not exists user_notifications_unread_idx
  on public.user_notifications (user_id, read_at, created_at desc);

alter table public.user_notifications enable row level security;

-- The browser never writes notification rows directly. Backend event handlers
-- create them and authenticated backend routes return only the current user's rows.
