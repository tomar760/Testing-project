-- BanaoCV Employer Portal Phase 4B + 4C
-- Moderated job posting, public approved jobs and consent-based applicant pipeline.
-- Run once after migration 009.

create table if not exists public.employer_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.employer_organizations(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 160),
  location text not null default '' check (char_length(location) <= 120),
  employment_type text not null default '' check (char_length(employment_type) <= 80),
  experience_level text not null default '' check (char_length(experience_level) <= 80),
  salary_min integer,
  salary_max integer,
  currency text not null default 'INR' check (char_length(currency) = 3),
  skills jsonb not null default '[]'::jsonb,
  description text not null check (char_length(description) between 30 and 10000),
  apply_deadline date,
  status text not null default 'draft' check (status in ('draft', 'pending_review', 'published', 'paused', 'rejected', 'expired')),
  review_note text not null default '' check (char_length(review_note) <= 2000),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (salary_min is null or salary_min >= 0),
  check (salary_max is null or salary_max >= 0),
  check (salary_min is null or salary_max is null or salary_max >= salary_min)
);

create table if not exists public.employer_job_submissions (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.employer_jobs(id) on delete cascade,
  candidate_id uuid not null references auth.users(id) on delete cascade,
  resume_id uuid not null references public.resumes(id) on delete restrict,
  candidate_note text not null default '' check (char_length(candidate_note) <= 2000),
  employer_note text not null default '' check (char_length(employer_note) <= 2000),
  status text not null default 'submitted' check (status in ('submitted', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (job_id, candidate_id)
);

alter table public.job_applications add column if not exists employer_job_id uuid references public.employer_jobs(id) on delete set null;

create index if not exists employer_jobs_org_status_updated_idx on public.employer_jobs (organization_id, status, updated_at desc);
create index if not exists employer_jobs_public_idx on public.employer_jobs (status, apply_deadline, published_at desc);
create index if not exists employer_job_submissions_job_status_idx on public.employer_job_submissions (job_id, status, updated_at desc);
create index if not exists employer_job_submissions_candidate_idx on public.employer_job_submissions (candidate_id, updated_at desc);
create index if not exists job_applications_employer_job_idx on public.job_applications (employer_job_id, user_id);

alter table public.employer_jobs enable row level security;
alter table public.employer_job_submissions enable row level security;

-- Browser clients never write employer/job/submission tables directly.
-- Backend membership, candidate ownership and Admin role checks mediate all access.

drop trigger if exists employer_jobs_touch_updated_at on public.employer_jobs;
create trigger employer_jobs_touch_updated_at before update on public.employer_jobs
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_job_submissions_touch_updated_at on public.employer_job_submissions;
create trigger employer_job_submissions_touch_updated_at before update on public.employer_job_submissions
for each row execute procedure public.touch_updated_at();
