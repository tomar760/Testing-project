-- BanaoCV private profile photo storage
-- Run once after migrations 001, 002 and 003.
-- Browser clients never receive direct Storage upload permission; BanaoCV backend
-- service-role validates and writes files to this private bucket.

alter table public.profiles add column if not exists avatar_path text;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'profile-photos',
  'profile-photos',
  false,
  4194304,
  array['image/jpeg', 'image/png', 'image/webp']
)
on conflict (id) do update
set public = false,
    file_size_limit = 4194304,
    allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];

-- No storage.objects browser policies are added on purpose.
-- Upload/download is mediated by authenticated BanaoCV backend endpoints only.
