-- BanaoCV Employer Portal Phase 4G
-- Candidate withdrawal and consent revocation for employer-sourced applications.
-- Run once after migration 013.

-- Candidate tracker needs a distinct withdrawn state instead of silently deleting
-- a linked employer submission.
alter table public.job_applications
  drop constraint if exists job_applications_status_check;
alter table public.job_applications
  add constraint job_applications_status_check
  check (status in ('saved', 'applied', 'interview', 'offer', 'rejected', 'withdrawn'));

-- Active employer members receive a private withdrawal notice.
alter table public.user_notifications
  drop constraint if exists user_notifications_notification_type_check;
alter table public.user_notifications
  add constraint user_notifications_notification_type_check
  check (notification_type in (
    'employer_new_applicant',
    'candidate_application_status',
    'candidate_application_withdrawn',
    'safety_report_received',
    'system'
  ));
