-- Run once in Supabase SQL Editor for existing BanaoCV projects.
-- Safe to rerun: uses IF NOT EXISTS / idempotent policies.

alter table public.profiles add column if not exists phone text default '';
alter table public.profiles add column if not exists location text default '';
alter table public.profiles add column if not exists career_title text default '';
alter table public.profiles add column if not exists preferred_language text default 'Hinglish';
alter table public.profiles add column if not exists career_goal text default '';
alter table public.profiles add column if not exists notification_preferences jsonb not null default '{"resume_reminder":true,"ai_tips":true,"job_alerts":false,"billing_updates":true}'::jsonb;
alter table public.profiles add column if not exists role text not null default 'user' check (role in ('user','support_agent','admin','super_admin'));
alter table public.profiles add column if not exists ai_credits_remaining integer not null default 0;

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 160),
  category text not null default 'Other',
  message text not null check (char_length(message) between 5 and 5000),
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  priority text not null default 'normal' check (priority in ('low','normal','high')),
  admin_reply text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists support_tickets_user_created_idx on public.support_tickets (user_id, created_at desc);
drop trigger if exists support_tickets_touch_updated_at on public.support_tickets;
create trigger support_tickets_touch_updated_at before update on public.support_tickets
for each row execute procedure public.touch_updated_at();
alter table public.support_tickets enable row level security;
drop policy if exists "support tickets own" on public.support_tickets;
create policy "support tickets own" on public.support_tickets for select using (auth.uid() = user_id);
