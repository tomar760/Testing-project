const PDFDocument = require('pdfkit');

function inr(value) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(value || 0));
}

function formatDate(value) {
  if (!value) return '—';
  return new Date(value).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
}

function safe(value) {
  return String(value || '—').replace(/[\r\n]+/g, ' ').slice(0, 240);
}

function createReceiptPdf(receipt) {
  return new Promise((resolve, reject) => {
    try {
      const document = new PDFDocument({ size: 'A4', margin: 48, info: { Title: `BanaoCV Receipt ${receipt.receiptNumber}`, Author: 'BanaoCV' } });
      const chunks = [];
      document.on('data', (chunk) => chunks.push(chunk));
      document.on('end', () => resolve(Buffer.concat(chunks)));
      document.on('error', reject);

      const emerald = '#0E6B4F';
      const amber = '#E8A33D';
      const deep = '#16281F';
      const muted = '#617168';
      const line = '#DCE7DF';

      document.rect(0, 0, document.page.width, 11).fill(emerald);
      document.fillColor(emerald).font('Helvetica-Bold').fontSize(27).text('Banao', 48, 52, { continued: true });
      document.fillColor(amber).text('CV');
      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('CAREER DOCUMENT · VERIFIED PAYMENT RECEIPT', 48, 85, { characterSpacing: 1.1 });

      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('RECEIPT NUMBER', 390, 53, { width: 157, align: 'right' });
      document.fillColor(emerald).font('Helvetica-Bold').fontSize(11).text(safe(receipt.receiptNumber), 350, 66, { width: 197, align: 'right' });
      document.roundedRect(415, 87, 132, 20, 10).fill('#DFF3E6');
      document.fillColor('#117443').font('Helvetica-Bold').fontSize(8).text('PAYMENT SUCCESSFUL', 415, 94, { width: 132, align: 'center' });

      document.moveTo(48, 122).lineTo(547, 122).strokeColor(emerald).lineWidth(1.5).stroke();
      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('BILLED TO', 48, 145);
      document.fillColor(deep).font('Helvetica-Bold').fontSize(14).text(safe(receipt.customer?.name), 48, 158);
      document.fillColor(muted).font('Helvetica').fontSize(10).text(safe(receipt.customer?.email), 48, 178);
      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('PAYMENT DATE', 335, 145);
      document.fillColor(deep).font('Helvetica-Bold').fontSize(11).text(formatDate(receipt.paidAt), 335, 158);
      document.fillColor(muted).font('Helvetica').fontSize(9).text(`Currency: ${safe(receipt.currency || 'INR')}`, 335, 176);

      document.roundedRect(48, 220, 499, 110, 12).strokeColor(line).lineWidth(1).stroke();
      document.roundedRect(48, 220, 499, 30, 12).fill('#EAF5EE');
      document.fillColor('#0B3D2D').font('Helvetica-Bold').fontSize(8).text('DESCRIPTION', 64, 232);
      document.text('AMOUNT', 435, 232, { width: 96, align: 'right' });
      document.fillColor(deep).font('Helvetica-Bold').fontSize(14).text(safe(receipt.planLabel), 64, 270);
      document.fillColor(muted).font('Helvetica').fontSize(9.5).text('BanaoCV career and resume platform access', 64, 290);
      document.fillColor(emerald).font('Helvetica-Bold').fontSize(18).text(inr(receipt.amountInr), 395, 274, { width: 136, align: 'right' });

      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('PAYMENT REFERENCE', 48, 365);
      document.fillColor(deep).font('Helvetica').fontSize(9).text(safe(receipt.paymentId), 48, 378, { width: 225 });
      document.fillColor(muted).font('Helvetica-Bold').fontSize(8).text('ORDER REFERENCE', 335, 365);
      document.fillColor(deep).font('Helvetica').fontSize(9).text(safe(receipt.orderId), 335, 378, { width: 212 });

      document.moveTo(48, 437).lineTo(547, 437).strokeColor(line).lineWidth(1).stroke();
      document.fillColor(muted).font('Helvetica').fontSize(8.5).text('This receipt is generated from BanaoCV\'s verified payment record. It does not contain card or banking data.', 48, 451, { width: 335 });
      document.text(`Help: ${safe(receipt.issuer?.supportEmail || 'supportbanaocv@gmail.com')}`, 340, 451, { width: 207, align: 'right' });
      document.fillColor(emerald).font('Helvetica-Bold').fontSize(9).text('Thank you for building your next opportunity with BanaoCV.', 48, 508, { width: 499, align: 'center' });
      document.end();
    } catch (error) { reject(error); }
  });
}

module.exports = { createReceiptPdf };
