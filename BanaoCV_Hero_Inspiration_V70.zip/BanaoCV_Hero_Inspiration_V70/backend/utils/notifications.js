const { supabaseAdmin } = require('../config/supabase');

const TYPES = new Set(['employer_new_applicant', 'candidate_application_status', 'candidate_application_withdrawn', 'safety_report_received', 'system']);
const clean = (value, max) => String(value || '').trim().slice(0, max);

function normalize(row) {
  const userId = clean(row.user_id, 80);
  const type = clean(row.notification_type, 50);
  const title = clean(row.title, 180);
  if (!userId || !TYPES.has(type) || title.length < 2) return null;
  return {
    user_id: userId,
    notification_type: type,
    title,
    message: clean(row.message, 1200),
    action_url: clean(row.action_url, 500),
    metadata: row.metadata && typeof row.metadata === 'object' && !Array.isArray(row.metadata) ? row.metadata : {},
  };
}

async function createNotifications(rows) {
  const payload = (rows || []).map(normalize).filter(Boolean);
  if (!payload.length) return [];
  const { data, error } = await supabaseAdmin.from('user_notifications').insert(payload).select();
  if (error) throw error;
  return data || [];
}

async function safeCreateNotifications(rows, eventName) {
  try {
    return await createNotifications(rows);
  } catch (error) {
    // A notification must never cancel a successfully completed application,
    // moderation or safety action. Render logs retain the operational signal.
    console.error(`Notification event failed: ${eventName || 'unknown'}`, error.message);
    return [];
  }
}

async function notifyOrganizationMembers(organizationId, notification) {
  try {
    const { data: members, error } = await supabaseAdmin.from('employer_members')
      .select('user_id')
      .eq('organization_id', organizationId)
      .eq('status', 'active');
    if (error) throw error;
    return safeCreateNotifications((members || []).map((member) => ({
      ...notification,
      user_id: member.user_id,
    })), 'employer_new_applicant');
  } catch (error) {
    console.error('Notification recipient lookup failed: employer_new_applicant', error.message);
    return [];
  }
}

async function notifySuperAdmins(notification) {
  try {
    const { data: admins, error } = await supabaseAdmin.from('profiles')
      .select('id')
      .eq('role', 'super_admin')
      .eq('account_status', 'active');
    if (error) throw error;
    return safeCreateNotifications((admins || []).map((admin) => ({
      ...notification,
      user_id: admin.id,
    })), 'safety_report_received');
  } catch (error) {
    console.error('Notification recipient lookup failed: safety_report_received', error.message);
    return [];
  }
}

module.exports = {
  TYPES,
  createNotifications,
  safeCreateNotifications,
  notifyOrganizationMembers,
  notifySuperAdmins,
};
