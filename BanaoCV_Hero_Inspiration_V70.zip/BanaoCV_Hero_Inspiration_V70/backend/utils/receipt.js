const PLAN_LABELS = {
  premium: 'Premium · One-time unlock',
  pro_monthly: 'Pro · Monthly',
  pro_annual: 'Pro · Annual',
};

function paymentReceipt(payment, customer = {}) {
  const amountPaise = Number(payment.amount || 0);
  return {
    receiptNumber: `BCV-${String(payment.id || payment.razorpay_payment_id || payment.razorpay_order_id).replace(/[^a-zA-Z0-9]/g, '').slice(-12).toUpperCase()}`,
    paymentId: payment.razorpay_payment_id || null,
    orderId: payment.razorpay_order_id || null,
    status: payment.status,
    plan: payment.plan,
    planLabel: PLAN_LABELS[payment.plan] || payment.plan,
    amountPaise,
    amountInr: amountPaise / 100,
    currency: payment.currency || 'INR',
    paidAt: payment.paid_at || payment.created_at,
    createdAt: payment.created_at,
    customer: {
      name: customer.name || customer.full_name || 'BanaoCV member',
      email: customer.email || '',
    },
    issuer: {
      name: 'BanaoCV',
      supportEmail: 'supportbanaocv@gmail.com',
    },
  };
}

module.exports = { paymentReceipt, PLAN_LABELS };
