-- BanaoCV: run this once in Supabase SQL Editor before starting the API.
-- This schema intentionally stores flexible resume/design JSON while preserving secure ownership.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  location text not null default '',
  career_title text not null default '',
  preferred_language text not null default 'Hinglish',
  career_goal text not null default '',
  avatar_path text,
  notification_preferences jsonb not null default '{"resume_reminder":true,"ai_tips":true,"job_alerts":false,"billing_updates":true}'::jsonb,
  role text not null default 'user' check (role in ('user', 'support_agent', 'admin', 'super_admin')),
  account_status text not null default 'active' check (account_status in ('active', 'suspended')),
  ai_credits_remaining integer not null default 0,
  plan text not null default 'free' check (plan in ('free', 'premium', 'pro_monthly', 'pro_annual')),
  plan_activated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.resumes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Untitled Resume' check (char_length(title) <= 120),
  template_slug text not null default 'clean-fresher' check (char_length(template_slug) <= 80),
  content jsonb not null default '{}'::jsonb,
  design jsonb not null default '{}'::jsonb,
  completion_percent smallint not null default 0 check (completion_percent between 0 and 100),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists resumes_user_updated_idx on public.resumes (user_id, updated_at desc);
create index if not exists resumes_updated_idx on public.resumes (updated_at desc);
create index if not exists profiles_role_idx on public.profiles (role);
create index if not exists profiles_plan_created_idx on public.profiles (plan, created_at desc);

-- Private manual Job Application Tracker; never performs automatic job submission.
create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  company text not null check (char_length(company) between 2 and 120),
  job_title text not null check (char_length(job_title) between 2 and 160),
  job_url text,
  location text not null default '' check (char_length(location) <= 120),
  status text not null default 'saved' check (status in ('saved', 'applied', 'interview', 'offer', 'rejected')),
  applied_at date,
  follow_up_at date,
  notes text not null default '' check (char_length(notes) <= 4000),
  resume_id uuid references public.resumes(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists job_applications_user_updated_idx on public.job_applications (user_id, updated_at desc);
create index if not exists job_applications_user_status_idx on public.job_applications (user_id, status, updated_at desc);
create index if not exists job_applications_follow_up_idx on public.job_applications (user_id, follow_up_at) where follow_up_at is not null;

create table if not exists public.application_activity_logs (
  id bigint generated always as identity primary key,
  application_id uuid not null references public.job_applications(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null check (event_type in ('created', 'status_changed', 'updated', 'follow_up_set', 'follow_up_completed')),
  from_status text,
  to_status text,
  message text not null default '' check (char_length(message) <= 2000),
  created_at timestamptz not null default now()
);
create index if not exists application_activity_logs_application_created_idx on public.application_activity_logs (application_id, created_at desc);
create index if not exists application_activity_logs_user_created_idx on public.application_activity_logs (user_id, created_at desc);


create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (char_length(subject) between 3 and 160),
  category text not null default 'Other',
  message text not null check (char_length(message) between 5 and 5000),
  status text not null default 'open' check (status in ('open', 'in_progress', 'resolved', 'closed')),
  priority text not null default 'normal' check (priority in ('low', 'normal', 'high')),
  admin_reply text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists support_tickets_user_created_idx on public.support_tickets (user_id, created_at desc);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null check (plan in ('premium', 'pro_monthly', 'pro_annual')),
  razorpay_order_id text not null unique,
  razorpay_payment_id text unique,
  amount integer not null check (amount > 0),
  currency text not null default 'INR',
  status text not null default 'created' check (status in ('created', 'paid', 'failed', 'refunded')),
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists payments_user_created_idx on public.payments (user_id, created_at desc);

create table if not exists public.ai_usage (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  feature text not null check (feature in ('hindi_to_resume', 'score', 'jd_match', 'cover_letter')),
  created_at timestamptz not null default now()
);
create index if not exists ai_usage_user_created_idx on public.ai_usage (user_id, created_at desc);

create table if not exists public.template_usage (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  template_slug text not null,
  created_at timestamptz not null default now()
);
create index if not exists template_usage_template_idx on public.template_usage (template_slug, created_at desc);

-- Direct Brevo password recovery: raw tokens are never stored; only a SHA-256
-- hash is retained. The backend service role is the only actor allowed to use it.
create table if not exists public.password_reset_tokens (
  token_hash text primary key check (char_length(token_hash) = 64),
  user_id uuid not null references auth.users(id) on delete cascade,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists password_reset_tokens_user_active_idx
  on public.password_reset_tokens (user_id, expires_at desc)
  where used_at is null;

-- Secure server-side Admin Command Centre data.
create table if not exists public.admin_audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid not null references auth.users(id) on delete restrict,
  action text not null check (char_length(action) between 3 and 120),
  target_type text not null check (char_length(target_type) between 2 and 80),
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists admin_audit_logs_created_idx on public.admin_audit_logs (created_at desc);
create index if not exists admin_audit_logs_actor_idx on public.admin_audit_logs (actor_id, created_at desc);

create table if not exists public.template_admin_settings (
  slug text primary key check (char_length(slug) between 2 and 80),
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

-- Privacy/account deletion review workflow. A request is never an automatic deletion.
create table if not exists public.account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'requested' check (status in ('requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled')),
  reason text not null default '' check (char_length(reason) <= 1000),
  admin_note text not null default '' check (char_length(admin_note) <= 2000),
  requested_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);
create unique index if not exists account_deletion_requests_one_active_idx on public.account_deletion_requests (user_id) where status in ('requested', 'in_review', 'approved');
create index if not exists account_deletion_requests_status_updated_idx on public.account_deletion_requests (status, updated_at desc);

-- Billing plan cancellation/downgrade review workflow. Never auto-refunds or auto-cancels a provider payment.
create table if not exists public.billing_change_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null default 'cancel_plan' check (request_type in ('cancel_plan', 'downgrade_free')),
  current_plan text not null check (current_plan in ('premium', 'pro_monthly', 'pro_annual')),
  status text not null default 'requested' check (status in ('requested', 'in_review', 'approved', 'rejected', 'completed', 'cancelled')),
  reason text not null default '' check (char_length(reason) <= 1000),
  admin_note text not null default '' check (char_length(admin_note) <= 2000),
  requested_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);
create unique index if not exists billing_change_requests_one_active_idx on public.billing_change_requests (user_id) where status in ('requested', 'in_review', 'approved');
create index if not exists billing_change_requests_status_updated_idx on public.billing_change_requests (status, updated_at desc);

-- Future Employer Portal foundation. Company posting/applicant pipeline comes in later phases.
create table if not exists public.employer_organizations (
  id uuid primary key default gen_random_uuid(),
  legal_name text not null check (char_length(legal_name) between 2 and 180),
  display_name text not null check (char_length(display_name) between 2 and 120),
  slug text not null unique check (slug ~ '^[a-z0-9-]{3,90}$'),
  website text,
  linkedin_url text,
  location text not null default '' check (char_length(location) <= 120),
  industry text not null default '' check (char_length(industry) <= 120),
  company_size text not null default '' check (char_length(company_size) <= 80),
  about text not null default '' check (char_length(about) <= 3000),
  status text not null default 'pending_verification' check (status in ('pending_verification', 'approved', 'rejected', 'suspended')),
  verification_note text not null default '' check (char_length(verification_note) <= 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.employer_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.employer_organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'owner' check (member_role in ('owner', 'recruiter', 'hiring_manager')),
  status text not null default 'active' check (status in ('active', 'inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, user_id)
);
create unique index if not exists employer_members_one_active_org_per_user_idx on public.employer_members (user_id) where status = 'active';
create index if not exists employer_organizations_status_updated_idx on public.employer_organizations (status, updated_at desc);

create table if not exists public.employer_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.employer_organizations(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 160),
  location text not null default '' check (char_length(location) <= 120),
  employment_type text not null default '' check (char_length(employment_type) <= 80),
  experience_level text not null default '' check (char_length(experience_level) <= 80),
  salary_min integer,
  salary_max integer,
  currency text not null default 'INR' check (char_length(currency) = 3),
  skills jsonb not null default '[]'::jsonb,
  description text not null check (char_length(description) between 30 and 10000),
  apply_deadline date,
  status text not null default 'draft' check (status in ('draft', 'pending_review', 'published', 'paused', 'rejected', 'expired')),
  review_note text not null default '' check (char_length(review_note) <= 2000),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.employer_job_submissions (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.employer_jobs(id) on delete cascade,
  candidate_id uuid not null references auth.users(id) on delete cascade,
  resume_id uuid not null references public.resumes(id) on delete restrict,
  candidate_note text not null default '' check (char_length(candidate_note) <= 2000),
  employer_note text not null default '' check (char_length(employer_note) <= 2000),
  status text not null default 'submitted' check (status in ('submitted', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (job_id, candidate_id)
);
alter table public.job_applications add column if not exists employer_job_id uuid references public.employer_jobs(id) on delete set null;
create index if not exists employer_jobs_org_status_updated_idx on public.employer_jobs (organization_id, status, updated_at desc);
create index if not exists employer_jobs_public_idx on public.employer_jobs (status, apply_deadline, published_at desc);
create index if not exists employer_job_submissions_job_status_idx on public.employer_job_submissions (job_id, status, updated_at desc);
create index if not exists employer_job_submissions_candidate_idx on public.employer_job_submissions (candidate_id, updated_at desc);
create index if not exists job_applications_employer_job_idx on public.job_applications (employer_job_id, user_id);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists resumes_touch_updated_at on public.resumes;
create trigger resumes_touch_updated_at before update on public.resumes
for each row execute procedure public.touch_updated_at();

drop trigger if exists support_tickets_touch_updated_at on public.support_tickets;
create trigger support_tickets_touch_updated_at before update on public.support_tickets
for each row execute procedure public.touch_updated_at();

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute procedure public.touch_updated_at();

drop trigger if exists job_applications_touch_updated_at on public.job_applications;
create trigger job_applications_touch_updated_at before update on public.job_applications
for each row execute procedure public.touch_updated_at();

drop trigger if exists account_deletion_requests_touch_updated_at on public.account_deletion_requests;
create trigger account_deletion_requests_touch_updated_at before update on public.account_deletion_requests
for each row execute procedure public.touch_updated_at();

drop trigger if exists billing_change_requests_touch_updated_at on public.billing_change_requests;
create trigger billing_change_requests_touch_updated_at before update on public.billing_change_requests
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_organizations_touch_updated_at on public.employer_organizations;
create trigger employer_organizations_touch_updated_at before update on public.employer_organizations
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_members_touch_updated_at on public.employer_members;
create trigger employer_members_touch_updated_at before update on public.employer_members
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_jobs_touch_updated_at on public.employer_jobs;
create trigger employer_jobs_touch_updated_at before update on public.employer_jobs
for each row execute procedure public.touch_updated_at();

drop trigger if exists employer_job_submissions_touch_updated_at on public.employer_job_submissions;
create trigger employer_job_submissions_touch_updated_at before update on public.employer_job_submissions
for each row execute procedure public.touch_updated_at();

-- RLS protects data should a browser ever use the Supabase client directly.
alter table public.profiles enable row level security;
alter table public.resumes enable row level security;
alter table public.payments enable row level security;
alter table public.ai_usage enable row level security;
alter table public.template_usage enable row level security;
alter table public.support_tickets enable row level security;
alter table public.password_reset_tokens enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.template_admin_settings enable row level security;
alter table public.job_applications enable row level security;
alter table public.application_activity_logs enable row level security;
alter table public.account_deletion_requests enable row level security;
alter table public.billing_change_requests enable row level security;
alter table public.employer_organizations enable row level security;
alter table public.employer_members enable row level security;
alter table public.employer_jobs enable row level security;
alter table public.employer_job_submissions enable row level security;

drop policy if exists "profiles read own" on public.profiles;
create policy "profiles read own" on public.profiles for select using (auth.uid() = id);
drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles for update using (auth.uid() = id);

drop policy if exists "resumes own" on public.resumes;
create policy "resumes own" on public.resumes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "job applications own" on public.job_applications;
create policy "job applications own" on public.job_applications for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "application activity own" on public.application_activity_logs;
create policy "application activity own" on public.application_activity_logs for select using (auth.uid() = user_id);

drop policy if exists "deletion requests own" on public.account_deletion_requests;
create policy "deletion requests own" on public.account_deletion_requests for select using (auth.uid() = user_id);

drop policy if exists "billing change requests own" on public.billing_change_requests;
create policy "billing change requests own" on public.billing_change_requests for select using (auth.uid() = user_id);

drop policy if exists "payments read own" on public.payments;
create policy "payments read own" on public.payments for select using (auth.uid() = user_id);
drop policy if exists "ai usage read own" on public.ai_usage;
create policy "ai usage read own" on public.ai_usage for select using (auth.uid() = user_id);
drop policy if exists "support tickets own" on public.support_tickets;
create policy "support tickets own" on public.support_tickets for select using (auth.uid() = user_id);

drop policy if exists "template usage read own" on public.template_usage;
create policy "template usage read own" on public.template_usage for select using (auth.uid() = user_id);
