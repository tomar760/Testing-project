const rateLimit = require('express-rate-limit');

const common = { standardHeaders: true, legacyHeaders: false };

const apiLimiter = rateLimit({
  ...common,
  windowMs: 15 * 60 * 1000,
  max: 150,
  message: { error: 'Bahut zyada requests ho gaye. Thodi der baad try karo.' },
});

const aiLimiter = rateLimit({
  ...common,
  windowMs: 60 * 60 * 1000,
  max: 30,
  message: { error: 'AI feature ki hourly limit khatam ho gayi. Thodi der baad try karo.' },
});

// Guide is a separate account-help assistant budget so it cannot consume resume-generation quota.
const guideLimiter = rateLimit({
  ...common,
  windowMs: 60 * 60 * 1000,
  max: 40,
  message: { error: 'BanaoCV Guide ki hourly limit abhi poori ho gayi. Thodi der baad phir pucho.' },
});

const authLimiter = rateLimit({
  ...common,
  windowMs: 15 * 60 * 1000,
  max: 10,
  skipSuccessfulRequests: true,
  message: { error: 'Bahut zyada attempts ho gaye. 15 minute baad try karo.' },
});

// Recovery emails have a separate strict limit because each accepted request
// creates a real SMTP delivery attempt. This protects the sender reputation.
const passwordRecoveryLimiter = rateLimit({
  ...common,
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: { error: 'Password reset ki limit abhi poori ho gayi hai. 1 ghante baad dobara try karo.' },
});

module.exports = { apiLimiter, aiLimiter, guideLimiter, authLimiter, passwordRecoveryLimiter };
