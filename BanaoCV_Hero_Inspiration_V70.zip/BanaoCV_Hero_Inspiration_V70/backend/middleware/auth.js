const jwt = require('jsonwebtoken');

function verifyToken(req, res, next) {
  const header = req.get('authorization') || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Token nahi mila. Pehle login karo.' });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch (error) {
    return res.status(401).json({ error: 'Session expire ho gaya hai. Dobara login karo.' });
  }
}

module.exports = { verifyToken };
