const { supabaseAdmin } = require('../config/supabase');

const PREMIUM_TEMPLATE_SLUGS = new Set([
  'dark-pro', 'creative-split', 'tech-dark', 'bold-modern', 'midnight-gold',
  'saffron-bold', 'navy-sidebar', 'pink-creative', 'teal-modern',
  'obsidian-executive', 'ivory-signature', 'signal-tech', 'editorial-creative',
  'sapphire-corporate', 'clinical-precision', 'sales-momentum', 'creator-portfolio',
]);

const PAID_PLANS = new Set(['premium', 'pro_monthly', 'pro_annual']);

async function getUserPlan(userId) {
  const { data, error } = await supabaseAdmin.from('profiles').select('plan').eq('id', userId).maybeSingle();
  if (error) throw error;
  return data?.plan || 'free';
}

async function assertTemplateEnabled(slug) {
  if (!slug) return;
  const { data, error } = await supabaseAdmin
    .from('template_admin_settings')
    .select('is_enabled')
    .eq('slug', slug)
    .maybeSingle();
  if (error) throw error;
  if (data?.is_enabled === false) {
    const disabled = new Error('Ye template abhi temporarily available nahi hai. Dusra template choose karo.');
    disabled.status = 403;
    throw disabled;
  }
}

async function requireTemplateEntitlement(req, res, next) {
  try {
    const slug = String(req.body.template_slug || '');
    await assertTemplateEnabled(slug);
    if (!PREMIUM_TEMPLATE_SLUGS.has(slug)) return next();
    const plan = await getUserPlan(req.user.id);
    if (!PAID_PLANS.has(plan)) {
      return res.status(403).json({ error: 'Ye Premium template hai. Premium ya Pro plan unlock karo.' });
    }
    req.userPlan = plan;
    return next();
  } catch (error) { return next(error); }
}

async function requireExistingResumeEntitlement(req, res, next) {
  try {
    const { data: resume, error } = await supabaseAdmin.from('resumes')
      .select('id, template_slug')
      .eq('id', req.params.id)
      .eq('user_id', req.user.id)
      .maybeSingle();
    if (error) throw error;
    if (!resume) return res.status(404).json({ error: 'Resume nahi mila.' });
    await assertTemplateEnabled(resume.template_slug);
    if (!PREMIUM_TEMPLATE_SLUGS.has(resume.template_slug)) return next();
    const plan = await getUserPlan(req.user.id);
    if (!PAID_PLANS.has(plan)) return res.status(403).json({ error: 'Ye Premium resume hai. Access continue karne ke liye Premium ya Pro plan unlock karo.' });
    req.userPlan = plan;
    return next();
  } catch (error) { return next(error); }
}

module.exports = { PREMIUM_TEMPLATE_SLUGS, PAID_PLANS, getUserPlan, assertTemplateEnabled, requireTemplateEntitlement, requireExistingResumeEntitlement };
