const { supabaseAdmin } = require('../config/supabase');

const ADMIN_ROLES = new Set(['support_agent', 'admin', 'super_admin']);
const FULL_ADMIN_ROLES = new Set(['admin', 'super_admin']);
const SUPER_ADMIN_ROLES = new Set(['super_admin']);

async function loadAdminContext(req, res, next) {
  try {
    const { data, error } = await supabaseAdmin
      .from('profiles')
      .select('id, full_name, role, account_status, plan')
      .eq('id', req.user.id)
      .maybeSingle();
    if (error) throw error;
    if (!data || data.account_status === 'suspended') {
      return res.status(403).json({ error: 'Admin access available nahi hai.' });
    }
    req.admin = {
      id: req.user.id,
      email: req.user.email,
      name: data.full_name || '',
      role: data.role || 'user',
    };
    return next();
  } catch (error) { return next(error); }
}

function requireRoles(...roles) {
  const allowed = new Set(roles);
  return (req, res, next) => {
    if (!req.admin || !allowed.has(req.admin.role)) {
      return res.status(403).json({ error: 'Is Admin action ki permission nahi hai.' });
    }
    return next();
  };
}

const requireAdminAccess = [loadAdminContext, requireRoles(...ADMIN_ROLES)];
const requireFullAdmin = requireRoles(...FULL_ADMIN_ROLES);
const requireSuperAdmin = requireRoles(...SUPER_ADMIN_ROLES);
const requireSupportAccess = requireRoles('support_agent', 'admin', 'super_admin');

module.exports = {
  ADMIN_ROLES,
  FULL_ADMIN_ROLES,
  loadAdminContext,
  requireRoles,
  requireAdminAccess,
  requireFullAdmin,
  requireSuperAdmin,
  requireSupportAccess,
};
