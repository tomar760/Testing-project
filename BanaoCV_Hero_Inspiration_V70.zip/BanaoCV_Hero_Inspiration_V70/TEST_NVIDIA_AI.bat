@echo off
setlocal
cd /d "%~dp0backend"
echo.
echo ==============================================
echo   Testing BanaoCV NVIDIA AI configuration
Echo ==============================================
echo.
node test-nvidia.js
pause
