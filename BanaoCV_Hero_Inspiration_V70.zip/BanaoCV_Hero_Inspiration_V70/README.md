# BanaoCV — A-to-Z Product & Engineering Guide

**Live domain:** `https://banaocv.in`  
**Frontend host:** Render Static Site  
**Backend API:** Render Express API  
**Database/Auth/Storage:** Supabase  
**Email:** Brevo Transactional API  
**Payments:** Razorpay  
**Support:** `supportbanaocv@gmail.com`

BanaoCV is a Hindi/English/Hinglish resume, career and application-tracking platform built for Indian job seekers. It is a cloud application: after deployment, it continues working even when the developer laptop is off.

---

## 1. Current verified product status

### Live and verified

| Module | Status | What it does |
|---|---|---|
| Email/password login | Live | Secure BanaoCV JWT session after Supabase validation |
| Signup + email OTP | Live | New user signup, OTP verification and profile creation |
| Password recovery | Live | Direct Brevo reset email, custom recovery token and password update |
| Google Sign-In | Live | Google → Supabase OAuth → BanaoCV Dashboard session handoff |
| Dashboard | Live | Authenticated identity, resume recovery, plan state and navigation |
| Resume editor | Live | Create, autosave, refresh persistence and resume ownership |
| Premium Studio | Live | Pro/Premium access, autosave, Premium PDF and Continue Editing |
| PDF resume export | Live | Direct browser PDF download with print fallback |
| Razorpay checkout | Live/Test | Server order creation and signature verification |
| Plans / entitlements | Live | Free, Premium, Pro guards and dashboard plan state |
| Settings profile | Live | Save/reload profile fields and preferences |
| Profile photo | Live after migration 004 | Private Storage upload, signed avatar URL, Settings/Dashboard display |
| Support tickets | Live | Logged-in user ticket creation/history; public Support page readable |
| Secure Admin Centre | Live after migration 003 | Server-side roles, real users/resumes/payments/support/templates/reports/audit |
| Job Application Tracker | Live after migration 005 | Manual company/role/status/follow-up/resume tracker and Admin operations |
| Dark/Light theme | Live | One persistent global control, Dark default, mobile/tablet/laptop QA |

### Implemented but requires the next browser verification

| Module | Current state |
|---|---|
| Server-generated Payment Receipt PDF | Backend PDFKit implementation ready; Settings/Admin browser download must be verified after deployment |

### Intentionally pending / do not advertise as working

| Module | Reason |
|---|---|
| NVIDIA AI resume drafting, score, JD Match, cover letter | NVIDIA-first direct HTTPS provider path is implemented; requires private NVIDIA key + real browser verification before it is advertised live |
| Automatic job applications | Not implemented by design; BanaoCV provides a safe manual Application Tracker only |
| Automatic job matching / recruiter marketplace | Not implemented; BanaoCV has a moderated employer self-service Job Board only. No scraping, fake listings or third-party auto-apply is performed |
| Real legal entity/final commercial legal review | Business owner/legal review still required before public paid-scale launch |

---

## 2. Frontend page map

All frontend pages are in `frontend/`. Public pages may load without a session; protected user pages redirect to Login when no BanaoCV session exists.

| File | URL | Who uses it | Current behavior |
|---|---|---|---|
| `index.html` | `/` | Everyone | Main landing page: product story, people-proof hero, templates, tracker entry, CTA, FAQ and footer |
| `login.html` | `/login.html` | Guests | Email login, signup, OTP, Google sign-in, forgot password; Enter submits Login |
| `reset-password.html` | `/reset-password.html` | Recovery user | Secure password reset form for a valid reset link/token |
| `dashboard.html` | `/dashboard.html` | Logged-in users | Resume recovery, recent drafts, plan state, application summary and sidebar avatar |
| `applications.html` | `/applications.html` | Logged-in users | Real manual job application tracker: company, role, status, URL, dates, notes and linked resume |
| `templates.html` | `/templates.html` | Everyone / logged-in users | Free/Premium template gallery with illustrative sample profile photos |
| `editor.html` | `/editor.html` | Logged-in users | Free resume editor; create/load/autosave/PDF |
| `premium-editor.html` | `/premium-editor.html` | Premium/Pro users | Premium Studio; Free users are redirected to Pricing |
| `pricing.html` | `/pricing.html` | Everyone | Free/Premium/Pro offer and real Razorpay checkout for logged-in users |
| `settings.html` | `/settings.html` | Logged-in users | Profile, private photo upload, billing history/receipt action, preferences and support links |
| `support.html` | `/support.html` | Everyone | Public support email/FAQ; signed-in ticket creation/history |
| `privacy.html` | `/privacy.html` | Everyone | Privacy policy content |
| `terms.html` | `/terms.html` | Everyone | Terms content |
| `refund.html` | `/refund.html` | Everyone | Refund/cancellation policy content |
| `404.html` | `/404.html` | Everyone | Branded missing-page fallback |
| `admin.html` | `/admin.html` | Authorized Admin only | Real secure command centre; normal users receive access denied |
| `employer.html` | `/employer.html` | Future companies | Employer landing and trust rules (Phase 4A) |
| `employer-onboarding.html` | `/employer-onboarding.html` | Authenticated future employer | Company profile submission for verification |
| `employer-dashboard.html` | `/employer-dashboard.html` | Verified/pending employer | Company status/profile workspace |
| `employer-jobs.html` | `/employer-jobs.html` | Approved employer | Job draft/create/submit for Admin review (Phase 4B) |
| `employer-applicants.html` | `/employer-applicants.html` | Approved employer | Candidate pipeline and status updates (Phase 4C) |
| `jobs.html` | `/jobs.html` | Everyone / signed-in candidate | Public approved jobs, consent-based resume apply and private Report entry |
| `report-safety.html` | `/report-safety.html?job=<job-id>` | Logged-in candidate | Private fraud/fee/fake-job/harassment/suspicious-link report for a selected approved job or company (Phase 4D) |
| `notifications.html` | `/notifications.html` | Logged-in user | Private in-app updates for employer applicants, candidate status and Super Admin safety reports (Phase 4E) |
| `job.html` | `/job.html?id=<published-job-id>` | Everyone / signed-in candidate | Shareable full detail for one approved job; candidate can manually apply, save or report (Phase 4F) |
| `saved-jobs.html` | `/saved-jobs.html` | Logged-in candidate | Private saved approved jobs shortlist; unavailable saved listings are safely redacted (Phase 4F) |
| `company.html` | `/company.html?id=<approved-company-id>` | Everyone | Public approved company profile with only current published non-expired company jobs (Phase 4H) |

### Shared browser scripts

| File | Responsibility |
|---|---|
| `frontend/js/api.js` | API base selection, BanaoCV JWT local session, protected requests, JSON/FormData support |
| `frontend/js/theme.js` | One global Dark/Light control, persistent choice and contrast safety layer |
| `frontend/js/brand.js` | Official BanaoCV logo standardization and favicon support |
| `frontend/js/session-nav.js` | Converts public Login CTA to Dashboard for an active session |
| `frontend/js/receipt.js` | Browser helper for verified receipt download / legacy renderer fallback |

---

## 3. Backend map

Backend source is in `backend/` and runs as an Express service.

| Folder/file | Responsibility |
|---|---|
| `server.js` | Express bootstrap, CORS allow-list, security headers, API routes and health route |
| `config/supabase.js` | Backend-only Supabase clients and safe Auth user-list fallback |
| `config/brevo.js` | Brevo HTTPS Transactional API email delivery |
| `controllers/authController.js` | Email auth, OTP, recovery, Google OAuth start/session handoff and current user |
| `controllers/resumeController.js` | User-owned resume CRUD/autosave |
| `controllers/paymentController.js` | Razorpay order/verification, payment history and owner PDF receipt |
| `controllers/profileController.js` | Profile save, private photo upload/remove and signed avatar URL |
| `controllers/supportController.js` | User ticket list/create |
| `controllers/applicationController.js` | Private manual/employer application tracker, timeline and candidate withdrawal controls |
| `controllers/adminController.js` | Server-side Admin real-data APIs, controls, exports and audit records |
| `controllers/safetyController.js` | Authenticated candidate safety reports, Admin queue and Super Admin enforcement/audit |
| `controllers/notificationController.js` | Current-user private notification list/read state APIs |
| `controllers/companyController.js` | Public approved company profile and public active company-job data only |
| `utils/notifications.js` | Fail-safe event notification dispatch for employers, candidates and Super Admins |
| `middleware/auth.js` | BanaoCV JWT verification |
| `middleware/admin.js` | Fresh server-side role lookup/guard for Admin routes |
| `middleware/plan.js` | Premium template entitlement and server-enforced disabled-template guard |
| `routes/*.js` | Route wiring by feature |
| `utils/receipt.js` | Safe verified receipt data model |
| `utils/receiptPdf.js` | Backend PDFKit receipt generation |

---

## 4. API map

All protected routes require:

```text
Authorization: Bearer <BanaoCV session token>
```

### Health

```text
GET /api/health
```

### Auth — `/api/auth`

| Method | Route | Purpose |
|---|---|---|
| POST | `/signup` | Create email/password account |
| POST | `/login` | Email/password login → BanaoCV JWT |
| POST | `/google/start` | Obtain secure Supabase Google authorization URL |
| POST | `/google/session` | Validate returned Google/Supabase session → BanaoCV JWT |
| POST | `/resend-otp` | Send new signup OTP |
| POST | `/verify-otp` | Verify signup OTP |
| POST | `/forgot-password` | Start secure recovery email flow |
| POST | `/reset-password` | Complete password reset with valid recovery token/session |
| GET | `/me` | Current BanaoCV user + plan profile |

### Resumes — `/api/resume`

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Current user's resume list |
| GET | `/:id` | Current user's one resume |
| POST | `/` | Create resume; checks template availability/entitlement |
| PUT | `/:id` | Autosave current user's resume |
| DELETE | `/:id` | Delete current user's resume |

### Profile — `/api/profile`

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Current profile + private signed avatar display URL |
| PUT | `/` | Save current profile fields/preferences |
| POST | `/photo` | Upload JPG/PNG/WebP profile photo, max 4 MB |
| DELETE | `/photo` | Remove current profile photo |
| GET | `/export` | Download private JSON export of current user data |
| GET | `/deletion-request` | Current user's latest deletion request status |
| POST | `/deletion-request` | Submit a deletion review request (never auto-deletes) |
| POST | `/deletion-request/cancel` | Cancel an active deletion request |

### Applications — `/api/applications`

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Current user's application list |
| GET | `/summary` | Counts, overdue/today follow-up reminders and recent applications |
| GET | `/:id/timeline` | Owned application activity/status timeline |
| POST | `/` | Add manual application |
| PUT | `/:id` | Update owned application |
| POST | `/:id/withdraw` | Candidate withdraws own employer-sourced application; employer resume access is revoked |
| DELETE | `/:id` | Delete owned manual tracker application; employer-sourced application must use withdrawal |

### Employer Foundation — `/api/employer`

| Method | Route | Purpose |
|---|---|---|
| GET | `/me` | Current authenticated employer organization/membership |
| GET | `/analytics` | Current employer organization job/applicant/verification/open-safety-report metrics |
| POST | `/onboard` | Submit company profile for verification |
| PUT | `/organization` | Owner updates company profile (unless suspended) |
| GET | `/jobs` | Employer organization job list |
| POST | `/jobs` | Create draft or submit job for review |
| PUT | `/jobs/:id` | Update employer-owned job / resubmit review |
| GET | `/jobs/:id/submissions` | Employer applicant list for own job |
| PATCH | `/submissions/:id` | Employer candidate status/note update |
| GET | `/submissions/:id/resume` | Employer views consented selected candidate resume; access denied after candidate withdrawal |

### Public Companies — `/api/companies`

| Method | Route | Purpose |
|---|---|---|
| GET | `/:id` | Public approved company profile and current published non-expired jobs only |

### Public Jobs — `/api/jobs`

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Browse approved company published jobs |
| GET | `/saved` | Current user private saved-job list; unavailable public listings are redacted |
| GET | `/:id` | Public approved job detail |
| POST | `/:id/save` | Save a currently public approved job for the current user |
| DELETE | `/:id/save` | Remove the current user saved job |
| POST | `/:id/apply` | Authenticated candidate applies with owned resume/consent |

### Notifications — `/api/notifications`

| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Current user's latest private in-app notifications and unread count |
| PATCH | `/:id/read` | Mark one owned notification read |
| PATCH | `/read-all` | Mark all current-user notifications read |

Private events include employer new applicant, candidate status update, candidate withdrawal and Super Admin safety-report review alerts.

### Trust & Safety — `/api/safety`

| Method | Route | Purpose |
|---|---|---|
| POST | `/reports` | Signed-in candidate privately reports an approved BanaoCV job/company concern; password/OTP/bank/card data must never be submitted |

### Payments — `/api/payment`

| Method | Route | Purpose |
|---|---|---|
| POST | `/create-order` | Create Razorpay order for valid plan |
| POST | `/verify` | Verify Razorpay signature and activate plan |
| GET | `/history` | Current user's stored payment history |
| GET | `/billing-change-request` | Current user's latest plan cancellation/downgrade request |
| POST | `/billing-change-request` | Submit manual billing review request; never auto-refunds |
| POST | `/billing-change-request/cancel` | Cancel active billing review request |
| GET | `/:id/receipt` | Verified receipt JSON for current payment owner |
| GET | `/:id/receipt.pdf` | Backend-generated verified PDF receipt for current payment owner |

### Support — `/api/support`

| Method | Route | Purpose |
|---|---|---|
| GET | `/tickets` | Current user's ticket history |
| POST | `/tickets` | Create support ticket |

### Admin — `/api/admin`

These routes require a verified server-side Admin role.

| Method | Route | Minimum role | Purpose |
|---|---|---|---|
| GET | `/me` | Support/Admin/Super | Current Admin context |
| GET | `/overview` | Admin/Super | Real metrics, comparison chart, funnel, activity, template usage |
| GET | `/users` | Admin/Super | Real user list/filter |
| PATCH | `/users/:id/role` | Super | Role assignment |
| PATCH | `/users/:id/plan` | Super | Access-plan change without charging/refunding |
| GET | `/resumes` | Admin/Super | Real resume operations |
| GET | `/applications` | Admin/Super | Real application tracker operations |
| GET | `/payments` | Admin/Super | Real payment ledger |
| GET | `/payments/:id/receipt` | Admin/Super | Receipt JSON |
| GET | `/payments/:id/receipt.pdf` | Admin/Super | Backend-generated verified PDF receipt |
| GET/PATCH | `/support`, `/support/:id` | Support/Admin/Super | Support queue and update |
| GET/PATCH | `/deletion-requests`, `/deletion-requests/:id` | Admin/Super read; Super update | Account deletion review queue (never automatic delete) |
| GET/PATCH | `/billing-change-requests`, `/billing-change-requests/:id` | Admin/Super read; Super update | Plan cancellation/downgrade review queue (never automatic refund) |
| GET/PATCH | `/employers`, `/employers/:id` | Admin/Super read; Super update | Company verification, rejection or suspension queue |
| GET/PATCH | `/employer-jobs`, `/employer-jobs/:id` | Admin/Super read; Super update | Job moderation: publish/pause/reject/expire |
| GET/PATCH | `/safety-reports`, `/safety-reports/:id` | Admin/Super read; Super update | Private Trust & Safety queue; Super Admin can pause/reject a reported job or suspend a reported company |
| GET/PATCH | `/templates`, `/templates/:slug` | Admin/Super | Template availability controls |
| GET | `/system` | Admin/Super | Safe system configuration state |
| GET | `/audit-logs` | Admin/Super | Admin audit history |
| GET | `/export/:type` | Admin/Super | CSV: users, resumes, applications, payments, support |

### AI — `/api/ai`

Routes exist but provider is intentionally paused. Do not present them as live until a production provider is configured and verified.

---

## 5. Database and migration order

Run migrations in Supabase SQL Editor in this order for an existing project.

| Migration | Purpose |
|---|---|
| `backend/schema.sql` | Fresh-project complete schema; run once only for a completely new project |
| `migrations/001_user_features_and_support.sql` | Existing profiles/support fields and role support |
| `migrations/002_direct_password_recovery.sql` | Secure single-use recovery tokens |
| `migrations/003_admin_command_centre.sql` | Admin audit, template controls, role/status support |
| `migrations/004_private_profile_photos.sql` | Private Storage bucket + avatar path |
| `migrations/005_job_application_tracker.sql` | Manual application tracker table/RLS/triggers |
| `migrations/006_privacy_data_export_and_deletion.sql` | Account deletion request workflow/RLS/triggers |
| `migrations/007_application_timeline_and_followups.sql` | Application status history and follow-up activity timeline |
| `migrations/008_billing_change_requests.sql` | Plan cancellation/downgrade review request workflow |
| `migrations/009_employer_portal_foundation.sql` | Employer organizations, members and company verification foundation |
| `migrations/010_employer_jobs_and_applicant_pipeline.sql` | Moderated jobs, candidate submissions and tracker synchronization |
| `migrations/011_employer_trust_and_safety.sql` | Private job/company reports, Trust & Safety queue and controlled enforcement actions |
| `migrations/012_in_app_notifications.sql` | Private in-app employer/candidate/Super Admin event notifications |
| `migrations/013_candidate_saved_jobs.sql` | Private candidate saved approved-job shortlist |
| `migrations/014_candidate_application_withdrawal.sql` | Candidate withdrawal tracker status, consent revocation and employer withdrawal notification type |

### Core tables

| Table | Purpose |
|---|---|
| `profiles` | User profile, plan, role, avatar path and settings |
| `resumes` | User-owned resume content/design/autosave |
| `payments` | Server-verified Razorpay payment records |
| `support_tickets` | User support requests/admin reply/status |
| `ai_usage` | Future AI usage records |
| `template_usage` | Template usage records |
| `password_reset_tokens` | Secure hashed, single-use recovery tokens |
| `admin_audit_logs` | Immutable Admin action log |
| `template_admin_settings` | Server-enforced template availability |
| `job_applications` | Private manual job applications/follow-ups |
| `application_activity_logs` | Private status history, updates and follow-up timeline events |
| `account_deletion_requests` | User deletion request, Admin review status and audit-safe notes |
| `billing_change_requests` | User plan cancellation/downgrade request, Super Admin review status/notes |
| `employer_organizations` | Future company legal/display profile, verification status and notes |
| `employer_members` | Future company user membership and employer role |
| `employer_jobs` | Moderated company job draft/review/published listing |
| `employer_job_submissions` | Candidate consent-based job submission and employer status |
| `employer_safety_reports` | Private candidate job/company safety reports, review state and enforcement history |
| `user_notifications` | Private in-app event updates and per-user read state |
| `candidate_saved_jobs` | Private user-to-approved-job saved shortlist mappings |

---

## 6. Admin role model

| Role | Scope |
|---|---|
| `user` | Normal product access; no Admin API access |
| `support_agent` | Support ticket queue/update only |
| `admin` | Operational data, templates, reports, safe system state |
| `super_admin` | Full control: roles, plan access, templates, reports, audit logs |

Every Admin uses their own BanaoCV account. Never share passwords or use client-side-only protection.

---

## 7. Local development

### Backend

```bash
cd backend
npm install
npm run check
npm run dev
```

Backend health:

```text
http://localhost:5000/api/health
```

### Frontend

Use the supplied Windows starter or serve `frontend/` on port `5500`:

```text
http://localhost:5500/login.html
```

### Local environment

Copy `backend/.env.example` to private `backend/.env`. Never commit/upload/share this file.

---

## 8. Production deployment

```text
GitHub main
   ├─ Render Static Site → frontend → banaocv.in
   └─ Render Web Service → backend → banaocv-api.onrender.com

Supabase → Auth / Postgres / private Storage
Brevo → transactional recovery email
Razorpay → payment checkout/verification
```

### Normal code update

```text
Edit/copy latest project files
→ GitHub Desktop commit
→ Push origin/main
→ Render auto-deploy
→ Browser QA
```

### Not automatic

- Supabase migrations
- Render environment changes
- Storage bucket migrations
- Google provider configuration
- DNS changes

Those require explicit safe owner actions.

---

## 9. Mandatory security rules

Never put these in GitHub/frontend/chat/screenshots:

```text
SUPABASE_SERVICE_KEY
SUPABASE_ANON_KEY / publishable key
JWT_SECRET
BREVO_API_KEY
Razorpay Key Secret
Razorpay webhook secret
Google Client Secret
backend/.env
```

Also never share:

```text
Passwords
OTP codes
Google OAuth callback tokens
Password-reset URLs/tokens
Payment card information
```

---

## 10. Current next engineering order

1. Final combined release: run migration `014_candidate_application_withdrawal.sql` once, deploy the combined Phase 4G/4H package, then browser-test withdrawal consent revocation plus public approved Company Profile and employer analytics with dummy accounts.
2. Re-check the full Employer onboarding → Admin approval → public company/job → candidate save/apply/withdraw/report → employer pipeline → tracker sync → notification flow after the combined release.
3. Verify backend-generated Receipt PDF on real phone and laptop after the final release sequence.
4. Keep NVIDIA unchanged until the owner explicitly reopens its reliability work; do not add OpenAI or change the frozen model/timeout/token settings.
5. Decide external email/WhatsApp notifications only after an owner-approved consent, opt-out and delivery-frequency policy. No automatic external notifications are enabled today.
6. Final legal/business-owner review: entity details, employer terms, policy wording, jurisdiction and receipt/tax requirements.

---

## 11. Project documentation

Useful detailed docs are in `docs/` after packaging:

- `PROJECT_NOTES.md` — living chronological project record
- `ADMIN_COMMAND_CENTRE_SETUP.md` — Admin roles/migration/setup
- `GOOGLE_OAUTH_BROWSER_LOGIN.md` — Google browser callback setup/test
- `PAYMENT_RECEIPTS_AND_INVOICES.md` — verified receipt architecture/test
- `PROFILE_PHOTO_UPLOAD_SETUP.md` — private photo storage/setup
- `JOB_APPLICATION_TRACKER_SETUP.md` — tracker fields/security/setup
- `DARK_LIGHT_CONTRAST_AND_LOGIN_UI.md` — theme/login visual system
- `RENDERED_VIEWPORT_QA_2026-07-24.md` — actual browser viewport QA record

---

## 12. Support contact

For product, account, payment or privacy support:

```text
supportbanaocv@gmail.com
```
