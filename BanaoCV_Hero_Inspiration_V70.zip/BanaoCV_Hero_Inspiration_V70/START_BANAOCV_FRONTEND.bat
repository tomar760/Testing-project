@echo off
setlocal
cd /d "%~dp0"
echo.
echo ==============================================
echo   Starting BanaoCV Frontend on port 5500
Echo ==============================================
echo.
npx --yes serve frontend -l 5500
pause
