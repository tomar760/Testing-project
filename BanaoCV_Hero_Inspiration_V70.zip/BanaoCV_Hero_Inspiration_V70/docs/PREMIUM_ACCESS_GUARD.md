# Premium Studio Access Guard

## Public UI routes

```text
editor.html          → Free / normal Resume Studio
premium-editor.html  → Premium / Pro Resume Studio
```

## Current static-preview behavior

The routes are separated for UI clarity. During static preview, a person can still type a public file URL manually; static HTML alone cannot securely enforce a paid entitlement.

## Required live backend rule

1. `premium-editor.html` calls `GET /api/auth/me`.
2. Frontend checks the signed-in plan returned by the backend.
3. If plan is `premium`, `pro_monthly` or `pro_annual`, allow the Premium Studio route.
4. If plan is `free` or the user is logged out, redirect to `pricing.html` with an unlock explanation.
5. Backend independently enforces template entitlement on create/update/export endpoints. Never rely only on a frontend redirect.

## Protected premium actions

- Premium template create/save
- Premium Studio editor access
- Premium PDF exports
- Premium design variants
- Pro-only AI monthly allowance

The separate route improves the product experience; the authenticated backend plan check makes the business lock real.
