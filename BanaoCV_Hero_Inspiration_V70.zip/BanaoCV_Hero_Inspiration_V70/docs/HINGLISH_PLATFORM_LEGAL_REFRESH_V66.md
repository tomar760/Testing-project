# BanaoCV Hinglish Platform & Legal Refresh — V66

**Release date:** 8 August 2026  
**Base:** Accepted V65 universal responsive system  
**Scope:** Content/copy and policy refresh only. No database migration, API key, AI-provider, Auth, payment-flow, route, or responsive-system change.

## What changed

### 1. Legal centre rebuilt in professional Hinglish
The following pages have been rewritten for clarity on mobile and desktop while preserving the V65/V61 responsive legal layout, sticky mobile section navigation, Dark/Light readability and all working links:

- `terms.html` — **Terms of Service / इस्तेमाल की शर्तें**
- `privacy.html` — **Privacy Policy / निजता नीति**
- `refund.html` — **Refund & Cancellation / रिफंड और कैंसलेशन**

Each policy has:

- easy Hinglish summaries;
- clear section navigation;
- key contractual clauses retained in English where legal precision matters;
- the confirmed support contact: `supportbanaocv@gmail.com`;
- an honest closed-beta/legal-review notice;
- no invented legal entity, address, GST/tax, jurisdiction, refund-period or statutory-right claim.

### 2. Confirmed BanaoCV safety and privacy position reflected
The refreshed policy/content now makes these agreed product facts clear:

- BanaoCV helps users prepare resumes and manage applications; it does **not** guarantee a job, interview, ATS outcome, employer response or factual correctness of AI output.
- A user must review AI output and use only facts supported by their experience.
- BanaoCV does not auto-apply on a candidate’s behalf.
- Resume/profile data is private by default. A relevant selected resume is shared with an employer only when the candidate intentionally applies.
- Profile photos are optional and user-controlled.
- Candidate job/interview/registration/training/placement fees are prohibited on BanaoCV.
- Fraud, fake job, fee demand, harassment and suspicious links can be reported for authorised review.
- BanaoCV does not sell resume data.
- Passwords, OTPs, reset links/tokens, API keys and bank/card details must never be submitted in support, AI or safety-report text.
- No public blanket **7-day refund guarantee** is claimed. Payment/refund requests are reviewed through the verified support route and are not automatically approved.

### 3. Hinglish-first visible copy pass across the platform
Necessary user-facing wording has been refreshed across candidate, employer, support, guide, admin and account pages. Common Indian product terms such as **Dashboard, Resume, Template, AI, Job, Plan, Settings** are intentionally retained where they make the UI clearer; explanations and actions are now Hinglish-first.

Pages covered include:

- Home, Login, Reset Password, 404
- Dashboard, Settings, Resume Editor, Premium Studio, Templates
- Jobs, Job Detail, Saved Jobs, Applications, Notifications, Company
- AI Guide, Support, Safety Reporting
- Employer landing, onboarding, dashboard, jobs and applicants
- Admin Command Centre
- Terms, Privacy and Refund pages

### 4. Honest-content cleanup
To follow the project rule against fabricated metrics, profile data, testimonials and quality claims:

- static Settings fallback no longer shows a fake person, email, phone, city or membership date;
- Login no longer displays made-up candidate success/ratings/platform totals;
- Home no longer displays made-up ratings, numerical ATS score badge, promised interview outcome, fictional resume data, fictional testimonial/job outcomes or static ATS percentages;
- Home/Template preview content is explicitly sample layout content;
- template gallery no longer displays invented ATS percentage labels;
- stale Support copy was corrected: signed-in drafts save through the working account flow and Google secure sign-in is available;
- outdated employer “future phase” wording was updated to the implemented verified-company/job/applicant workflow.

No image, PNG, screenshot or visual asset was generated for this release.

## Important policy limitation before broad public launch

This is a product-ready, clear closed-beta policy draft—**not legal advice**. Before a broad public launch, the BanaoCV owner and a qualified lawyer/CA must finalise and publish:

1. registered legal entity name and registered business address;
2. governing law, jurisdiction and dispute-resolution process;
3. GST/tax treatment;
4. final payment, cancellation, refund and statutory-right wording;
5. employer-specific contractual terms and any marketing/email consent wording.

Do not add invented business facts merely to make a policy look complete.

## Explicitly unchanged

- V65 responsive behaviour and user-controlled browser zoom
- existing Auth core: email/password, signup OTP, password reset and Google sign-in
- Razorpay/plan/payment behaviour and actual prices
- Groq provider configuration and secrets
- backend routes, database migrations and Supabase configuration
- AI rate limits and existing safe AI/Guide behaviour
- employer/candidate permissions and moderation controls

## Validation completed

- All **28** HTML pages were checked for UTF-8/source structure.
- All inline JavaScript blocks passed `node --check` syntax validation.
- Local `.html` links and same-page legal navigation anchors passed validation.
- Terms, Privacy and Refund pages were checked for their core safety/contact commitments.
- No migration, environment-variable or secret file is required for this release.

## Deployment

Deploy **only the V66 ZIP package**. It includes the full current project, V65 responsive baseline and this document.

No SQL migration, Render environment-variable edit, payment-key action or Supabase change is required.
