# BanaoCV — Employer Portal Phase 4A

## Goal

Create a separate premium Employer/Company Portal so companies can self-onboard. The owner does not manually add jobs. Phase 4A builds the company identity and verification foundation before public job posting.

## Pages

| Page | Purpose | Background system |
|---|---|---|
| `employer.html` | Employer landing / trust explanation | Hiring Constellation |
| `employer-onboarding.html` | Authenticated company onboarding form | Verification Wave |
| `employer-dashboard.html` | Employer company profile/status workspace | Talent Orbit |
| `admin.html` → Employers | Super Admin verification queue | Command Centre Data Signal |

## Data model

### employer_organizations

```text
legal_name
display_name
slug
website
linkedin_url
location
industry
company_size
about
status
verification_note
```

### employer_members

```text
organization_id
user_id
member_role: owner / recruiter / hiring_manager
status: active / inactive
```

A current user may have one active employer organization membership in Phase 4A.

## Company status flow

```text
pending_verification
→ approved
→ rejected
→ suspended
```

- `pending_verification`: onboarding submitted; no job posting yet.
- `approved`: future Job Posting Phase 4B unlocks.
- `rejected`: company needs correction/review.
- `suspended`: employer portal actions blocked.

## Safety rules

- Company details must be genuine.
- No candidate job/interview/registration fee.
- First company profile is Super Admin reviewed.
- No job is public in Phase 4A.
- No candidate data is exposed in Phase 4A.
- Every Super Admin verification update writes Admin audit log.

## One-time migration

```text
backend/migrations/009_employer_portal_foundation.sql
```

Expected:

```text
Success. No rows returned
```

## Future phases

| Phase | Feature |
|---|---|
| 4B | Company job draft/posting, moderation, publish/pause/expiry |
| 4C | Candidate selects BanaoCV resume, applies, employer applicant pipeline |
| 4D | Fraud/fee/fake job/harassment report and Trust & Safety queue |

## Browser test

1. Open `employer.html`.
2. Click Employer onboarding.
3. Login with existing BanaoCV account.
4. Submit genuine test company profile.
5. Open employer dashboard: status must show `pending_verification`.
6. Super Admin → Employers: verify profile appears.
7. Add review note, set Approved/Rejected in a safe test profile.
8. Confirm employer dashboard reflects status after refresh.
