# BanaoCV — First-Time Founder Roadmap (India)

> **Purpose:** A beginner-friendly order of operations for the BanaoCV founder. This is product/operational guidance, not legal or tax advice. Before accepting public payments, signing employer contracts or publishing final legal terms, confirm the relevant steps with an India-based Chartered Accountant (CA) and lawyer.

---

## Your safe current stage: Founder Build / Private Beta

You are building BanaoCV alone, validating the product and using internal dummy accounts. At this stage, you **do not need to invent legal business details**, publish a home address, share identity documents, register GST just to keep coding, or add public vacancies.

### Current defaults we should keep

| Area | Safe current default | Why |
|---|---|---|
| Business stage | Individual founder / private beta | Lets you build and test before making compliance commitments |
| Public jobs | Only real, Admin-approved jobs later | No fake jobs or misleading vacancies |
| Test jobs | Clearly labelled `TEST ONLY`, paused after testing | Keeps internal tests off the public Job Board |
| Public address | Do not publish personal home address | Privacy first; decide a business/legal address later |
| GST wording | Do not claim GST registration | Avoids a false tax claim before CA review |
| Notifications | In-app only | No unexpected marketing/email or WhatsApp messages |
| AI | NVIDIA remains frozen | Follow current product decision until intentionally reopened |
| Support | `supportbanaocv@gmail.com` | Existing public support route |

---

## The simple business path

### Stage A — Build and private test (now)

**What you do**

- Keep improving product with dummy Candidate, Employer and Super Admin accounts.
- Keep all internal job listings paused after tests.
- Keep the support email active.
- Do not collect unnecessary personal data.
- Do not launch employer marketing, paid ads or public jobs until you can verify every company.

**What you do NOT need to give us**

- Aadhaar, PAN, GSTIN, bank details, payment passwords, API keys, OTPs, reset links/tokens, business-registration documents or home address.

**What happens**

- Product remains technically ready and safe for internal/private beta use.
- You can demo it to trusted people without making legal/tax claims.

---

### Stage B — First real employer / first public vacancy

Before an actual company posts a real vacancy, prepare these decisions with a CA/lawyer:

1. **Who is operating the business?**
   - You as an individual founder initially, or
   - a registered sole proprietorship / LLP / company.

2. **What public business contact will be shown?**
   - A business correspondence address or registered office later.
   - Do not use a personal residence publicly unless you are comfortable and professionally advised.

3. **Employer rules**
   - No candidate fee, training fee, registration fee or interview fee.
   - No fake jobs, phishing links, harassment or misleading salary/role details.
   - BanaoCV can pause/reject a job or suspend a company after review.
   - Company must provide accurate legal/display identity and contact information.

4. **Data/consent rules**
   - Candidate applies manually by choosing their own resume.
   - Employer sees an application only after candidate consent.
   - Candidate can withdraw; employer resume access is revoked.

**What you provide later (plain non-secret answers only)**

- Final business/legal name (after deciding it)
- Business model chosen (individual, proprietorship, LLP or private limited)
- Whether you have a suitable business correspondence address
- Whether a CA/lawyer has reviewed the public policy wording

---

### Stage C — First paid customer / public plans

Before accepting real public payments at scale:

1. Ask a CA which entity/tax setup fits your actual turnover, state and service model.
2. Decide whether/when GST registration applies to your business. Do not guess and do not display GST wording until advised.
3. Use a business-appropriate bank/payment setup under your own secure control.
4. Finalize invoice/receipt fields with your CA.
5. Finalize cancellation/refund wording with a lawyer/CA; do not promise a refund window you cannot legally or operationally honour.

**Never send in chat**

```text
Bank account numbers
UPI PINs
PAN/Aadhaar scans
GSTIN or registration scans
Payment dashboard passwords
Razorpay/Brevo/Supabase/OpenAI/NVIDIA keys
OTP/reset links/tokens
backend/.env
```

---

### Stage D — Public launch and growth

Before public promotion:

- Finalize Employer Terms, Privacy Policy, Terms of Service and cancellation/refund wording.
- Put the verified public business contact in the approved legal pages.
- Decide whether external email/WhatsApp notifications are needed.
- If external notifications are enabled later, implement:
  - clear user purpose (job update vs marketing),
  - explicit consent for marketing,
  - unsubscribe/opt-out method,
  - frequency limits,
  - safe support escalation.
- Keep in-app notifications as the default safe channel until then.

---

## Entity choices — plain-language guide

| Option | Plain meaning | Usually fits when | Reminder |
|---|---|---|---|
| Individual founder | You build/run it personally | Building, demo and early private beta | Ask CA before taking significant public payments/contracts |
| Sole proprietorship | A simple business operated by one person under a trade name | Early solo business activity | CA can explain registrations, tax and banking setup relevant to you |
| LLP | A formal business with partners | You have co-founders/partners and want structured ownership | More formal compliance than solo stage |
| Private Limited Company | Separate company entity | Investors, larger team, formal contracts/scale plans | Highest setup/compliance effort; use professional advice |

There is no need to rush into an entity solely because you are building the website. Pick the route based on real activity, partners, revenue and professional advice.

---

## Your next action right now

1. **Do not register anything today just because the site is ready.**
2. Keep BanaoCV in private beta with test data until you are ready for real users/employers.
3. When you have your first genuine employer or first real payment plan, book one short consultation with a local CA in Surat/Gujarat and use the Stage B/C checklist above.
4. Return here with only non-secret answers, for example:

```text
I am ready for first real employer.
Business stage: individual founder / proprietorship / company.
Public business address: ready later / not ready.
GST: CA consultation pending / registered.
External notifications: in-app only / essential email later.
```

Then BanaoCV legal/operational content can be prepared for professional review without inventing facts.
