# BanaoCV — Billing Lifecycle Controls (Phase 3)

## What Phase 3 does

For paid plans, Settings now provides a safe plan cancellation/downgrade review request.

```text
User submits cancellation request
→ billing_change_requests record
→ Admin → Billing Requests
→ Super Admin review/status/note
→ separate verified manual decision
```

## What it does NOT do

- Does not automatically cancel a Razorpay subscription.
- Does not automatically issue a refund.
- Does not automatically downgrade a plan.
- Does not delete payment records.

These actions require real provider/business policy review. Existing Super Admin plan controls remain separate and are audited.

## User controls

Settings → Plan & Billing:

- Current paid plan shown
- Request review
- Active request status
- Cancel an active Requested/In Review request
- Verified Payment Receipt PDF

## Admin controls

Admin → Billing Requests:

- User/payment plan/request date/reason
- Requested/In Review/Approved/Rejected/Completed/Cancelled state
- Private Super Admin note
- Audit log entry after review update

## Migration

Run after migration 007:

```text
backend/migrations/008_billing_change_requests.sql
```

Expected:

```text
Success. No rows returned
```

## Safe test

1. Use a paid account.
2. Settings → Plan & Billing → Request review.
3. Confirm status is shown.
4. Admin → Billing Requests → open review queue.
5. Do not mark owner request Approved/Completed in a test.
6. Return to Settings → Cancel request.
