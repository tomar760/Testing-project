# BanaoCV Groq AI Beta Setup

## Scope

Groq is prepared as the optional primary AI provider for BanaoCV beta. The API key stays private in Render. Never place it in frontend code, GitHub, screenshots, chat, `.env` uploads or browser storage.

## Code defaults

When `AI_PROVIDER=groq`, BanaoCV uses:

```text
Base URL: https://api.groq.com/openai/v1
Model:    llama-3.3-70b-versatile
Timeout:  45000 ms
Max tokens: 1400
```

Because these are code defaults, Render needs only these two values:

```text
AI_PROVIDER = groq
GROQ_API_KEY = <private key created in Groq Console>
```

The old NVIDIA variables may remain in Render; they are ignored while `AI_PROVIDER=groq`.

## Request safety

```text
Authenticated user
→ existing 30 AI requests/hour limiter
→ BanaoCV backend
→ Groq OpenAI-compatible /chat/completions endpoint
→ strict JSON parsing
→ editor result
```

Provider errors stay user-friendly:

- Missing key
- Invalid model
- 429 free usage limit
- Timeout
- Service unavailable

No raw provider diagnostic/key is shown to users.

## Browser test order

1. Test one short Hindi/Hinglish “AI Resume Banao” prompt.
2. Test AI Score once.
3. Test JD Match once.
4. Test Cover Letter once.
5. Stop if a limit/error appears; do not repeatedly click/retry.

## Reality of free tiers

Groq free limits are suitable for small controlled beta testing, not unlimited public marketing traffic. Keep existing backend rate limits and test user-facing error/retry UX before describing AI as widely available.
