# Dashboard Resume Management Micro-Fix — V49

## Requested behavior implemented

### Most recently edited resume

The first/currently most recently updated resume is now always shown as the featured row with a prominent:

```text
Continue Editing →
```

button, whether it is a draft or already complete.

### All other resumes

Every additional resume has visible normal actions:

```text
Edit
Delete
```

The user is no longer limited to a tiny unlabeled edit icon for older resumes.

### Safe delete

- Delete action asks for confirmation first.
- User sees the resume title in the confirmation.
- Existing authenticated `DELETE /api/resume/:id` route enforces ownership server-side.
- After deletion, Dashboard refreshes the resume list, count, best completion and progress without page reload.
- A small Dashboard toast confirms success or shows a safe error message.

## Unchanged

- Resume editor behavior and saving
- Auth/Google/payment/jobs/employer/safety/notifications/AI configuration
- Database schema and migrations
- No new SQL or environment change required
