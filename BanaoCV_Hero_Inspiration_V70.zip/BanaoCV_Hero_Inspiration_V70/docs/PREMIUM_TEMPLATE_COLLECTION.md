# BanaoCV — Premium Signature Collection

Premium templates are a real paid-value product, not ordinary templates with a lock badge.

## Designs

1. **Obsidian Executive** — leadership / management / senior operations
2. **Ivory Signature** — consulting / finance / corporate professionals
3. **Signal Tech** — software, data and product professionals
4. **Editorial Creative** — marketing, brand and creative leaders
5. **Sapphire Corporate** — HR, operations, MNC and business analyst roles
6. **Clinical Precision** — medical and healthcare careers
7. **Sales Momentum** — sales, B2B, revenue and customer growth roles
8. **Creator Portfolio** — designers, creators and visual professionals

## Product rules

- Every design is pre-filled with a realistic sample profile.
- Every premium template remains editable in Resume Studio.
- Every design must remain readable in print/PDF and retain a clean text order for ATS parsing.
- Premium unlock grants lifetime access to template/design presentation.
- AI remains credit/fair-use controlled; it is not bundled as uncapped lifetime usage.
- Backend plan verification will enforce access once Razorpay/auth are live.
