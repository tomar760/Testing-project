# BanaoCV Employer Portal — Phase 4D: Trust & Safety

## Purpose

Phase 4D adds a private, human-reviewed safety path for candidates who see a BanaoCV job or company concern. It is designed to protect job seekers without scraping jobs, publishing unverified employers, automating applications, or taking candidate fees.

## Safe workflow

```text
Candidate opens a currently published BanaoCV job
→ Clicks Report
→ Logs in and chooses Job or Company
→ Selects safety category + writes factual details
→ Private report is created for Trust & Safety Queue
→ Admin/Super Admin can read queue
→ Super Admin can review, dismiss, resolve, pause/reject job, or suspend company
→ Admin audit trail records review and enforcement
```

## Candidate reporting page

Public entry point is the approved Job Board:

```text
jobs.html → Report → report-safety.html?job=<approved-job-id>
```

The report page has its own **Signal Shield** animated background and supports:

- Fraud / scam concern
- Candidate fee or registration charge demand
- Fake job
- Harassment or inappropriate behaviour
- Suspicious link or contact request
- Misleading company or job information
- Other safety concern

A signed-in user must choose the exact job/company context. The backend validates that the target is a currently published job from an approved company. Duplicate active reports by the same user for the same category/target are blocked.

## Data protections

- Reports are private — never shown to the reported employer or public Job Board.
- Browser clients have no direct Supabase policy for safety reports; all writes use an authenticated backend route.
- Sensitive data warning is shown prominently: do not submit passwords, OTPs, reset links/tokens, bank PINs, card details, or API keys.
- Reporter identity is visible only to authorized Admin/Super Admin users in the safety queue.
- Reports preserve target name snapshots for review history.
- If a reporter deletes their account later, their foreign key is set to null rather than blocking account deletion.

## APIs

### Candidate

```text
POST /api/safety/reports
Authorization: Bearer <BanaoCV session token>
```

Body:

```json
{
  "target_type": "job",
  "target_id": "approved-job-uuid",
  "category": "fee_demand",
  "details": "The job asked for a registration payment before scheduling an interview."
}
```

### Admin Trust & Safety Queue

```text
GET   /api/admin/safety-reports
PATCH /api/admin/safety-reports/:id
```

- **Admin / Super Admin** can read the queue.
- **Super Admin only** can update a review or apply a live enforcement action.

PATCH body:

```json
{
  "status": "in_review",
  "admin_note": "Checked company website and job text.",
  "action": "none"
}
```

Allowed statuses:

```text
open | in_review | resolved | dismissed
```

Allowed enforcement actions:

```text
none
pause_job       → removes the published job from the public Job Board
reject_job      → rejects the target job
suspend_company → suspends the organization; all its public jobs disappear because public jobs require an approved company
```

Any enforcement action automatically resolves the report and requires a confirmation dialog in the Admin UI. Existing Admin audit logs record both the case update and the enforcement action.

## Database migration

Run after migration `010_employer_jobs_and_applicant_pipeline.sql`:

```text
backend/migrations/011_employer_trust_and_safety.sql
```

Expected Supabase SQL Editor result:

```text
Success. No rows returned
```

## Explicitly not included

- No automatic job scraping
- No fake job data
- No automatic candidate applications
- No candidate job/interview/registration fee workflow
- No automatic employer suspension without Super Admin human review
- No email/WhatsApp notification automation yet
