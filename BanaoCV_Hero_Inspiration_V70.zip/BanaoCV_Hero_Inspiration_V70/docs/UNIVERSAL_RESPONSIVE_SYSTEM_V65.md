# BanaoCV Universal Responsive System — V65

## Goal

BanaoCV should have a stable default layout across standard small phones, phones, large phones, tablets, laptops and desktops without preventing user browser zoom.

## Global guard rails

Shared `js/theme.js` now applies:

- `max-width: 100vw` and horizontal overflow protection
- `min-width: 0` on narrow viewports
- image/video/canvas max-width containment
- no browser text auto-inflation
- stable `svh` minimum height where supported
- safe mobile placement for global theme/Guide controls
- narrow-device Guide panel bounds

## Page-specific responsive layers

- Homepage: fixed first-screen mobile Hero composition
- Dashboard: stable Chrome viewport handling, mobile shell, profile card and resume controls
- Templates: mobile filter grid, dark contrast and safe floating controls
- Legal pages: sticky mobile section navigation
- Settings: mobile profile/crop modal layout
- Editor: mobile tabs, photo control, preview and action rail
- Jobs/Employer/Applications: existing responsive page systems retained

## Zoom policy

Browser zoom is intentionally not locked. Users retain accessibility zoom. V65 improves the default responsive fit rather than forcing a device zoom level.

## QA bands

320, 360, 375, 390, 412, 430, 480, 600, 768, 820, 1024, 1280, 1366 and 1440 CSS widths, Light/Dark, with real browser/device testing still recommended after each major visual batch.
