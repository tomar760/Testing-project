# Homepage Hero Inspiration Refresh — V70

**Date:** 9 August 2026  
**Status:** Owner-authorised source change.

## Change made

The large Homepage Hero portrait is now a newly generated premium career-inspiration image:

```text
assets/home/hero-career-inspiration-v70.jpg
```

It shows an aspirational Indian professional woman in a refined workspace. It is intentionally not presented as a user profile or named candidate.

## Owner-profile treatment preserved

The smaller owner-approved Hero mini resume remains unchanged:

- Aditya Tomar name
- existing Aditya profile photo
- small resume identity treatment

The large Hero photo now has no profile caption, so it cannot be confused with Aditya’s identity.

## Visual decision

The oversized large-photo `AI / GUIDANCE` badge had already been removed in V69. V70 keeps it removed. The new photo gives the Hero a more premium, aspirational visual balance without adding a second profile label.

## Boundaries

- The prior large Hero image remains preserved in assets; it was not deleted.
- No existing owner photo, source asset, release package or project file was deleted.
- No Auth, backend, database, payment, AI-provider, responsive-system or deployment configuration was changed.

## Validation required before package

- New Hero asset exists and is referenced by `index.html`.
- No large Hero caption remains.
- Existing Aditya mini resume/photo remains in source.
- HTML/style/JavaScript/link checks pass.
