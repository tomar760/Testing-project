# BanaoCV — Auth & Dashboard Integration v3

## Included in v3

- `frontend/js/api.js`: shared browser client for the local backend API, JWT session storage and protected-route redirects.
- `login.html`: real email/password login, signup, OTP verification, resend OTP and password-reset request calls.
- `reset-password.html`: secure recovery-link new-password screen backed by `/api/auth/reset-password`.
- `dashboard.html`: authenticated `/api/auth/me` identity load and real `/api/resume` list rendering, including saved-draft/Continue Editing state.
- `backend/routes/auth.js` and `backend/controllers/authController.js`: resend signup OTP endpoint.

## Local testing

1. Keep backend running at `http://localhost:5000`.
2. Serve the `frontend/` directory on port 5500.
3. Open `http://localhost:5500/login.html`.
4. Sign up/login using the real UI.
5. Dashboard reads your real saved draft via `/api/resume`.

## Security note

JWT storage is local browser storage for this static-development phase. For production, move to a secure cookie/session strategy or add stronger CSP/XSS controls. Service keys remain backend-only.

## Next integration

- Editor create/load/autosave by resume ID
- Settings profile updates
- Google OAuth callback
- Razorpay checkout/promo enforcement
- Admin/support live APIs
