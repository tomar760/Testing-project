# BanaoCV — Premium / Pro Entitlement Integration v11

## Enforced behavior

```text
Premium template POST /api/resume → server checks profile.plan
Free plan + premium slug → HTTP 403
premium-editor.html → browser calls /api/auth/me
Free plan → pricing redirect
Premium / Pro plan → Premium Studio allowed
Dashboard → live plan label/upgrade state from profile
```

## Payment handoff

Razorpay `/api/payment/verify` updates `profiles.plan`, so the next dashboard/editor request receives the actual plan state.

## Pending additions

- Server-side Premium PDF/export guard
- AI credit decrement/plan quotas
- Promo code server validation
