# BanaoCV — Approved Pricing & Promotion Strategy

## Launch pricing

| Plan | Price | Billing | Core promise |
|---|---:|---|---|
| Free | ₹0 | Forever | 1 resume, 6 templates, basic score, 5 AI actions/day, clean PDF |
| Premium Launch | ₹79 | One-time | Lifetime template/design unlock, 5 resumes, no watermark, 30 AI credits |
| Premium Regular | ₹99 | One-time | Same Premium entitlement after the launch offer ends |
| Pro Monthly | ₹249 | Monthly | Premium + 20 resumes + 150 AI actions/month + priority access |
| Pro Annual | ₹1,799 | Annual | Same Pro entitlement; equivalent to about ₹150/month |

## Non-negotiable entitlement rule

- Premium can offer **lifetime design/template access**.
- Premium must **not** offer lifetime unlimited AI.
- Pro provides a recurring monthly AI/fair-use allowance because it funds ongoing provider costs.
- PDF downloads and template edits may be unlimited because they have low marginal cost.

## Launch promotion language

Use positive wording only:

```text
A special offer for you
Launch price · ₹79 one-time
₹99 regular price later
No hidden renewal
```

Do **not** publicly mention a low user count, “first X users”, or any threshold that can create negative social proof.

## Promo-code policy

- Launch offer code: `WELCOME79` where needed.
- Creator campaign examples: `INSTA20`, `RIYA20`, `SURAT30`.
- Each code needs: start/end date, maximum uses, plan restriction, creator/source tag and server-side validation.
- Codes never stack.
- During the ₹79 launch offer, regular creator codes should not stack unless the business deliberately approves the rule.

## Instagram approach

Use content before discount-heavy posting:

- Hindi/Hinglish resume mistakes
- before/after resume transformations
- ATS/JD Match examples
- fresher, tech, commerce and government resume tips
- five-minute BanaoCV product demos

A unique creator code and UTM link should be generated for each creator. Admin should track redemptions, revenue and refunds per code.

## Backend work still required

The pricing UI is ready. During Razorpay integration, add a `promo_codes` table, redemption/audit table and server-side quote validation before `create-order`. Never trust a price or promo code sent from the browser.
