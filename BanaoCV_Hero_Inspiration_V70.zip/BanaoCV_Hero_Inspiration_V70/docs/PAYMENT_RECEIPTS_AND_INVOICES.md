# BanaoCV — Real Payment Receipts

## What is now real

- `GET /api/payment/history` returns only the signed-in user's stored payment records.
- `GET /api/payment/:id/receipt` verifies payment ownership and returns receipt JSON only for a successful payment.
- `GET /api/payment/:id/receipt.pdf` generates and downloads verified PDF bytes on the backend.
- Settings loads real payment history and downloads the server-generated PDF; it no longer relies on client HTML/canvas rendering.
- Admin may download the same verified backend PDF for a successful payment through the protected Admin payment ledger.

## Receipt data

Every receipt is generated from BanaoCV's `payments` table and contains:

- BanaoCV receipt number
- Customer name/email
- Plan and amount
- Payment status
- Razorpay payment/order references
- Payment date
- Support email

A receipt download does not call Razorpay from the browser and does not expose Razorpay secrets/card data.

## Security

- A normal user cannot request another user's receipt: payment record is filtered by both payment ID and authenticated `user_id`.
- Admin receipt access requires server-side Admin role guard.
- Failed/created/refunded records do not present as successful receipts.
- Admin plan changes explicitly do not create charges, refunds or fake payment records.

## PDF behavior

The backend uses PDFKit to generate a real PDF response from the verified receipt data. The browser downloads the returned PDF blob directly, avoiding client HTML/canvas blank-page issues on phone browsers. The old client HTML renderer remains only as a non-primary fallback utility and is not used by Settings/Admin receipt actions.

## Production test

1. Sign in with an account that has a successful test/live payment.
2. Open Settings → Plan & Billing.
3. Confirm real plan and payment record are visible.
4. Click **Receipt PDF**.
5. Confirm readable PDF/print receipt download on phone or laptop.
6. As Super Admin, open Admin → Payments and test the PDF action for the same successful payment.
