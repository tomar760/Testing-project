# BanaoCV — Real Job Application Tracker

## What is real

This module is a private, user-controlled tracker. It does **not** submit applications automatically.

Users can save:

- Company
- Job title
- Location
- Job URL
- Application status: Saved, Applied, Interview, Offer, Rejected
- Applied date
- Follow-up date
- Private notes
- Optional BanaoCV resume used for that application

## User experience

- Dedicated `applications.html` tracker page.
- Responsive status board with follow-up reminders.
- Dashboard application summary and application count.
- Homepage Smart Apply Tracker entry point.

## Admin experience

Super Admin/Admin can view real application operations:

- User, company, role, status, applied/follow-up dates and location
- Status summary
- CSV export

Admin cannot submit job applications on behalf of users through this module.

## One-time migration

Run once in Supabase SQL Editor:

```text
backend/migrations/005_job_application_tracker.sql
```

Expected result:

```text
Success. No rows returned
```

## Security

- Every public tracker API filters by authenticated `user_id`.
- User can link only a resume that belongs to their own account.
- RLS policy limits direct database access to a user's own applications.
- Admin application view is protected by existing server-side Admin roles.

## Production test

1. Login normally.
2. Open `applications.html` or Dashboard → Applications.
3. Add a sample job application.
4. Change it to Applied/Interview, add follow-up date and note.
5. Refresh: record remains.
6. Check Dashboard application count.
7. As Super Admin, open Admin → Applications and verify real row/CSV export.
