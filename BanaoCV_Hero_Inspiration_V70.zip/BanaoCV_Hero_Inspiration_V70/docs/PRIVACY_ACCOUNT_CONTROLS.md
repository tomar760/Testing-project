# BanaoCV — Privacy, Data Export & Account Deletion Controls

## Real user controls

### Download My Data

Settings → Privacy & your data → **Download JSON** creates an authenticated JSON export containing:

- Profile data and preferences
- Resumes/content/design
- Manual application tracker records
- Support ticket history/replies
- Payment references/statuses (never card/bank data)
- Account deletion request history

The private profile photo binary is not embedded in JSON; only profile metadata is included.

### Account Deletion Request

Settings → **Request deletion** does not delete an account immediately.

```text
User submits request
→ account_deletion_requests record created
→ Super Admin reviews in Admin → Privacy Requests
→ status can move: requested / in_review / approved / rejected / completed
```

The user can cancel an active requested/in-review request. A completed deletion must be performed through a deliberate, separately reviewed process—never by an automatic browser button.

## One-time migration

Run:

```text
backend/migrations/006_privacy_data_export_and_deletion.sql
```

Expected:

```text
Success. No rows returned
```

## Security

- User export routes filter all data by authenticated `user_id`.
- Deletion request review is Admin-protected; status update is Super Admin-only.
- No password, Google token, reset token, secret, card number or bank detail is included in export.
- Admin action writes an audit record.
