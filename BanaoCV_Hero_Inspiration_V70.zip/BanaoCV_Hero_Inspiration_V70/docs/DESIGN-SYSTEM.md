# BanaoCV — Design System Reference (Page by Page)

Every page shares the same core brand system, but each has its own background
animation "theme" so no two pages feel identical. This file documents exactly
what's used where — verified against the actual code, not guessed.

---

## Core Brand System (same on every page)

| Element | Value |
|---|---|
| **Fonts** | Headings/Logo/Buttons: **Sora** (600/700/800 weight) — Body/UI text: **Hind** (400/500/600/700 weight) |
| **Primary — Emerald** | `#0E6B4F` (buttons, links, headings) |
| **Emerald Dark** | `#0A5240` (hover states) |
| **Emerald Deep** | `#0B2E22` (dark chrome — sidebars, dark sections) |
| **Accent — Amber** | `#E8A33D` (CTAs, badges, highlights) |
| **Amber Dark** | `#C9862A` (hover states) |
| **Secondary accent — Cobalt** | `#274DE0` (AI-related UI only — coach widgets, AI bar) |
| **Success — Mint** | `#2FBF71` |
| **Danger** | `#C0392B` |
| **Background (light)** | Ivory `#FBF8F0` |
| **Background (dark mode)** | `#0F1512` |
| **Logo** | "B" monogram doubling as a folded resume (Emerald + Amber), reused as a seal/stamp icon for score badges site-wide |
| **Buttons** | `.btn-primary` = Amber fill, Emerald-deep text · `.btn-ghost` = outline · `.btn-dark` = Emerald-deep fill · all pill/rounded (9-10px radius), min 44px tall |
| **Motion rule** | Every animation uses only `transform`/`opacity` (GPU-cheap) and respects `prefers-reduced-motion` |

---

## Page-by-Page

### 1. index.html — "Drifting Grid"
- **Background theme:** Animated dot-grid drifting diagonally (`driftGrid` keyframe) — subtle graph-paper feel
- **Signature elements:** Word-cycling headline (`swapIn`/`swapOut`), floating resume mockup with pulsing score badge (`float`, `pulse`), avatar-stack social proof row
- **Colors:** Full core palette; Cobalt used only in the AI coach bar
- **Fonts:** Sora (headline/logo), Hind (body)

### 2. dashboard.html — "Aurora"
- **Background theme:** Two large soft-blurred gradient blobs slowly drifting (`blobA` Emerald, `blobB` Amber)
- **Signature elements:** Dark Emerald-deep sidebar, animated score ring, sticky-note-style AI tips, date badge in greeting
- **Colors:** Emerald-deep sidebar, Amber accents, Cobalt on the AI Coach widget only
- **Fonts:** Sora (stat numbers/headings), Hind (body)

### 3. templates.html — "Floating Pages"
- **Background theme:** Faint bordered rectangles (resume-page outlines) floating upward (`floatUp`)
- **Signature elements:** Category-specific realistic sample content (6 different profiles), illustrated head+shoulders avatar on sidebar-layout templates, filter pills, preview modal
- **Colors:** Each template card has its *own* accent color (14 distinct hexes across 16 templates) layered on the core palette
- **Fonts:** Sora (card titles), Hind (mini-resume preview text)

### 4. editor.html — "Desk"
- **Background theme:** Diagonally-drifting dot-grid, distinct trajectory from the homepage (`deskDrift`)
- **Signature elements:** Floating stamp/seal score badge that "settles" on load (`stampSettle`), folder-style colored tabs (Content=Emerald, Design=Amber, Sections=Cobalt), paper-stack shadow behind the live A4 preview, Hindi-input card with example chips
- **Colors:** Full palette + 6 selectable resume accent colors (Emerald/Cobalt/Purple/Navy/Gold/Black) in the Design tab
- **Fonts:** Sora (resume name/section titles in the live preview), Hind (resume body text + all UI)

### 5. login.html — "Seal Drift"
- **Background theme:** Small seal/checkmark icons (the same seal motif as the score badge) floating upward across the whole page (`sealFloat`)
- **Signature elements:** Dark decorative left panel with testimonial card + stats, password strength meter, 6-box auto-focus OTP, stamp animation on success (`stampIn`), view-switching (`fadeSlide`)
- **Colors:** Emerald-deep left panel, Amber accents throughout
- **Fonts:** Sora (headline/logo), Hind (form labels/body)

### 6. pricing.html — "Falling Rupees"
- **Background theme:** ₹ symbols gently floating upward (`rupeeFloat`)
- **Signature elements:** Monthly/Annual billing toggle, ₹79 launch-offer badge (₹99 struck through), real Razorpay Checkout modal, comparison table
- **Colors:** Amber "Sabse Popular" badge on Premium, Emerald-deep "Pro Team" button
- **Fonts:** Sora (prices/plan names), Hind (feature lists)

### 7. admin.html — "Data Grid"
- **Background theme:** Slowly panning graph-paper grid lines (`gridPan`) — deliberately data/analytics-coded
- **Signature elements:** SVG line charts, conic-gradient donut chart, CSS funnel bars, Demo/Real data toggle, user detail drawer (view/edit/impersonate), CSV export, feature-flag switches
- **Colors:** Full palette + Purple `#7C3AED` for the geo-distribution bars
- **Fonts:** Sora (stat numbers/panel headers), Hind (tables/body)

### 8. terms.html — "Ruled Paper"
- **Background theme:** Faint horizontal lines slowly shifting downward (`linesShift`) — like ruled notebook paper, fitting a legal document
- **Signature elements:** Icon badge above the heading, numbered sections
- **Colors:** Minimal — Emerald headings/links only, rest is plain text on Ivory
- **Fonts:** Sora (h1/h2), Hind (body)

### 9. privacy.html — "Radar Pulse"
- **Background theme:** Concentric rings expanding and fading from center, staggered (`ringPulse`) — a security/"scanning" motif
- **Signature elements:** Shield icon badge above heading
- **Colors:** Same minimal legal-page treatment as terms.html
- **Fonts:** Sora (h1/h2), Hind (body)

### 10. refund.html — "Return Arrows"
- **Background theme:** Circular return-arrow icons pulsing in place, staggered (`arrowPulse`) — money-back motif
- **Signature elements:** Green "7-Din Full Refund Guarantee" highlight box at the top
- **Colors:** Mint-tinted highlight box, otherwise matches terms/privacy treatment
- **Fonts:** Sora (h1/h2), Hind (body)

### 11. support.html — "Chat Drift"
- **Background theme:** Chat-bubble outlines (with tail) drifting sideways, left to right (`chatDrift`) — the only *horizontal*-motion background in the whole site
- **Signature elements:** 3 quick-action cards, contact form, FAQ accordion, direct-email card
- **Colors:** Cobalt-tinted bubble outlines (ties to "conversation"), Amber submit button
- **Fonts:** Sora (headings), Hind (form + FAQ)

### 12. settings.html — "Rotating Hexagons"
- **Background theme:** Large hexagon outlines slowly rotating in place, alternating direction (`hexSpin`)
- **Signature elements:** Tabbed layout (Account/Preferences/Data & Privacy/Billing), toggle switches, plan chip, danger-zone delete button
- **Colors:** Standard palette; Danger red used in the delete-account button only
- **Fonts:** Sora (card titles), Hind (labels/inputs)

### 13. reset-password.html — "Security Scan"
- **Background theme:** A single vertical light beam sweeping left to right across the whole screen on a loop (`scanSweep`) — a security/verification feel
- **Signature elements:** Password strength meter (shared logic with login.html), stamp-style success icon
- **Colors:** Minimal centered card, standard palette
- **Fonts:** Sora (heading/logo), Hind (labels)

### 14. 404.html — "Wandering"
- **Background theme:** Large "?" characters gently wandering along a multi-point path, not a straight line (`wander`) — the only *non-linear* motion background, fitting the "lost" theme
- **Signature elements:** Big Sora-weight "404" numeral, playful Hinglish copy
- **Colors:** Minimal, Emerald numeral + Amber button only
- **Fonts:** Sora (404 numeral/heading), Hind (body)

---

## Quick Lookup Table

| Page | Background Name | Keyframe(s) |
|---|---|---|
| index.html | Drifting Grid | `driftGrid` |
| dashboard.html | Aurora | `blobA`, `blobB` |
| templates.html | Floating Pages | `floatUp` |
| editor.html | Desk | `deskDrift` |
| login.html | Seal Drift | `sealFloat` |
| pricing.html | Falling Rupees | `rupeeFloat` |
| admin.html | Data Grid | `gridPan` |
| terms.html | Ruled Paper | `linesShift` |
| privacy.html | Radar Pulse | `ringPulse` |
| refund.html | Return Arrows | `arrowPulse` |
| support.html | Chat Drift | `chatDrift` |
| settings.html | Rotating Hexagons | `hexSpin` |
| reset-password.html | Security Scan | `scanSweep` |
| 404.html | Wandering | `wander` |
