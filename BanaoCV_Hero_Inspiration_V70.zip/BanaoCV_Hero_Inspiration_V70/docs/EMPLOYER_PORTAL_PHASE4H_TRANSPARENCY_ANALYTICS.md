# BanaoCV Employer Portal — Phase 4H: Verified Company Transparency & Employer Analytics

## Purpose

Phase 4H uses existing approved company, moderated job and consent-based submission data to improve transparency for candidates and give employers real operational counts. It adds no scraped jobs, fake reviews, candidate fee mechanism, external key or automatic application.

## Public verified company profile

New route:

```text
company.html?id=<approved-company-id>
```

The **Verification Prism** page displays only:

- Admin-approved company display name
- Public company description, industry, location, size and optional website
- Only current published, non-expired jobs from that approved company

A paused, rejected, expired or suspended company is not returned. No applicant, employer member, verification-note, legal-name or admin-only data is exposed publicly.

Job Board cards and Job Detail pages now link to the relevant public company profile.

## Employer analytics

The existing Employer Dashboard now shows real, organization-scoped metrics:

- Total job posts
- Total applicant submissions
- Verification status
- Open Trust & Safety reports relating to the organization

Endpoint:

```text
GET /api/employer/analytics
```

It requires an active member of the employer organization and never reveals other organizations’ data. A verified employer also gets a Public Profile link from their dashboard.

## API

```text
GET /api/companies/:id          Public approved company + public active jobs
GET /api/employer/analytics     Authenticated current employer organization only
```

## Database/deployment

Phase 4H uses the already-existing tables from migrations 009–014. It needs **no new SQL migration**.

For the final combined deployment, migration order still begins with:

```text
014_candidate_application_withdrawal.sql
```

and no earlier migration should be re-run.

## Safety boundary

- Company visibility requires Admin approval.
- Public jobs still require Admin publication.
- Candidate application, saved-job, report and withdrawal consent rules remain unchanged.
- No legal business claims are invented; the employer controls only the public profile fields already reviewed by Admin.
