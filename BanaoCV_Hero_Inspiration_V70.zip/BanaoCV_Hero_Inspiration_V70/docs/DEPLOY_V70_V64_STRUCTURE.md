# Deploy V70 — Homepage Hero Inspiration Refresh

V70 preserves the accepted V64 package structure:

```text
BanaoCV_Hero_Inspiration_V70/
├── frontend/
├── backend/
├── docs/
├── README.md
├── .gitignore
└── FILE_MANIFEST.sha256
```

## V70 change

- Replaces only the large Homepage Hero profile-style portrait with the new premium career-inspiration image.
- Removes its large profile caption.
- Keeps the smaller Aditya Tomar mini resume/profile treatment intact.
- Keeps V68 Dashboard fix, V69 Premium rollback and current final feature-logo implementation.

## Safe deploy

1. Extract ZIP and open the outer V70 folder.
2. GitHub Desktop → **Repository → Show in Explorer**.
3. Copy the **contents inside `frontend/`** into existing repository root.
4. Copy/merge `backend/` into existing `backend/`.
5. Never paste the outer V70 folder as nested folder. Never replace `.git` or copy `.env`.
6. Commit, Push and wait for Render Live.
7. Hard-refresh once with `Ctrl + Shift + R`.

No SQL migration, key, environment, Supabase/Auth, payment or AI-provider change is required.
