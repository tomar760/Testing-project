# Homepage Identity & Premium Mark Rollback — V69

**Date:** 9 August 2026  
**Status:** Owner-authorised source correction.

## Homepage Hero identity restored

The Homepage Hero now uses the owner-approved identity treatment:

- `Aditya Tomar` is shown in the large Hero portrait caption and mini resume card.
- Existing `assets/profiles/aditya-tomar-profile.jpg` is shown in both places.
- The prior generic `Sample profile` / `Sample Resume` replacement text was removed from the owner-profile Hero area.
- The oversized circular `AI / GUIDANCE` badge above the Hero portrait was removed completely.

No new image was generated. The existing owner-approved asset was reused.

## Premium visual rollback

The owner withdrew active use of the uploaded Premium PNG for now.

- Removed the custom Premium PNG from Dashboard, Pricing, Templates, Editor and Premium Studio presentation surfaces.
- Restored original/neutral BanaoCV Premium UI treatment (plain Premium text and existing generic upgrade emblem).
- Removed the Premium PNG from the active feature-logo asset library.
- The shared `js/feature-logos.js` registry now contains only the four still-approved feature marks:
  - Pulse Trail
  - Progress Arc
  - Focus Board
  - Clarity Prism

The regular BanaoCV brand logo and the four retained feature marks remain unchanged.

## No core-platform change

V69 does not change the Dashboard V68 recovery fix, V65 responsive system, Auth, backend, database, payments, AI provider, environment variables or routes.

## Validation

- Homepage owner identity/photo and removal of the AI badge checked in source.
- No Premium PNG or `data-feature-mark="premium"` reference remains in active HTML/JS.
- Final four SVG feature assets remain present.
- Style-pair, HTML parse, JavaScript syntax and local link checks are required before packaging V69.
