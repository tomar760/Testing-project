# BanaoCV Guide & AI Composers — V57

## BanaoCV Guide

### Dedicated page

```text
ai-guide.html
```

Authenticated users can ask BanaoCV product/career-support questions in Hindi, English or Hinglish.

### Floating contextual launcher

The shared theme script shows a compact **Ask BanaoCV Guide** launcher for authenticated users on app pages (not Login/Reset/Guide page). It provides page help, profile guidance and support guidance, then routes to the full Guide when needed.

### Safe account awareness

Guide backend receives only sanitized current-user context:

- First name
- Plan
- Career title/location
- Resume count and best completion
- Application status counts
- Saved-job count
- Current page and limited recent chat messages

Guide never receives/exposes passwords, OTPs, reset tokens, API keys, bank/card data, raw payment IDs, full photo data, other users' data, cross-employer applicant data or Admin-sensitive data.

### Actions

Guide may suggest safe navigation links. Support tickets are drafts only and require user confirmation before existing Support API submits them. Guide cannot automatically pay/refund, delete account/resume, apply for jobs, publish/pause jobs, change roles or make security changes.

## Career Interview

Editor/Premium Editor has a new **Guided Summary** tool:

1. Calls Groq to ask 1–3 relevant missing-detail questions.
2. Shows varied selectable options plus user free text.
3. User chooses output target: Short Summary, ATS Summary, Headline, Skills or Experience Bullets.
4. Groq returns 3 alternatives grounded only in supplied data/answers.
5. User explicitly chooses and applies one option to the relevant resume field.

No AI auto-overwrite and no invented facts.

## Cover Letter Composer

Cover Letter is now a dedicated composer rather than confusing inline fields:

- Current resume connected automatically
- Company name and role clearly required
- Optional job description
- Tone choice
- Generate dedicated preview
- Copy or download text

It remains separate from the resume document.

## Visual tool identities

Editor AI tools now use distinct inline SVG/CSS identities for Resume creation, Score, Guided Summary, JD Match and Cover Letter. No generated image asset.

## Backend routes

```text
POST /api/guide/chat
POST /api/ai/guided-interview/questions
POST /api/ai/guided-interview/generate
```

Guide has a separate 40/hour limiter; existing AI generation limiter remains.

## No migration

No database migration, secret, environment, payment/Auth core, employer marketplace, safety or NVIDIA/Groq provider configuration change is needed beyond the already deployed Groq provider setup.
