# BanaoCV — Master Handoff Prompt

Copy the prompt below into a future coding/agent session along with the latest project folder. It contains the approved product/design rules, verified state and next work.

---

## PROMPT START

You are continuing the **BanaoCV** project: an AI resume and career platform for Indian job seekers. Work from the latest supplied repository. Read these files before changing code:

```text
docs/PROJECT_NOTES.md
docs/PROJECT_STRUCTURE.md
docs/IMPLEMENTATION_STATUS_AND_NEXT_STEPS.md
docs/PRICING_AND_PROMO_STRATEGY.md
docs/PREMIUM_TEMPLATE_COLLECTION.md
docs/PREMIUM_ACCESS_GUARD.md
docs/COST_AND_AI_PLAN.md
```

### Product identity

```text
Product: BanaoCV
Tagline: Hindi Mein Bolo, Job Pao
Audience: Indian freshers, job seekers and professionals using Hindi, English or Hinglish
Domain: banaocv.in
```

### Locked brand system

```text
Primary Emerald: #0E6B4F
Accent Amber: #E8A33D
Background Ivory: #FBF8F0
Display typography: Fraunces direction
Body/UI typography: Hind
```

Keep the visual tone premium, warm, trustworthy, Indian and ATS-professional. Do not replace the brand with generic SaaS blue or unrelated colours.

### Design rules already approved

1. Each major page has a distinct animated background language; do not blindly reuse dot/grid patterns everywhere.
2. Backgrounds must remain subtle, responsive, non-interactive and support `prefers-reduced-motion`.
3. Phone, tablet, laptop and desktop layouts matter. Never accept text overlap, narrow vertical word wrapping, invisible light-theme text or broken mobile cards.
4. Free templates must look professional. Premium templates must look visibly exceptional, role-focused and fully editable.
5. Premium Studio is a separate route (`premium-editor.html`) while normal users use `editor.html`.
6. Do not make false claims that an unfinished module works.
7. After every user instruction/change, append a concise dated update to `docs/PROJECT_NOTES.md`.

### Pricing/entitlement rules

```text
Free: ₹0
Premium Launch: ₹79 one-time
Premium Regular later: ₹99 one-time
Pro Monthly: ₹249/month
Pro Annual: ₹1,799/year
```

Premium gives lifetime template/design access, not lifetime unlimited AI. Current intended limits:

```text
Free: limited AI actions
Premium: 30 AI credits
Pro: 150 AI actions/month / fair use
```

Never expose user-count thresholds publicly. Use positive wording such as:

```text
A special offer for you
Launch offer
No hidden renewal
```

Promo codes must be server validated; never trust a client-supplied price/discount.

### Architecture

```text
frontend/  Static HTML/CSS/JS UI
backend/   Express API
Supabase   Auth + PostgreSQL database
Brevo      Supabase custom SMTP
Razorpay   Payments
AI         NVIDIA development adapter now; production provider decision pending
```

### Sensitive credential policy

Never request, print, commit or include secrets in code/files. Secrets live only in `backend/.env` locally or in cloud host environment variables.

### Verified working locally

```text
Supabase schema and profile trigger
Brevo custom SMTP
Email OTP signup
Password reset email setup
Google provider setup in Supabase
Node backend health
Signup / OTP verify / login / JWT / protected me
Profile row creation
Resume create/list/update persistence
Dashboard real user + draft data
Editor load/autosave/refresh persistence
```

### Current known work remaining

1. Complete Razorpay Test Mode success and verify payment row/profile plan update.
2. Enforce Premium/Pro access server-side for premium editor/templates/PDF actions.
3. Resolve NVIDIA AI connection/model issue or use an authorised production alternative; then test Hindi-to-resume, score, JD Match and cover letter.
4. Implement Google OAuth browser callback and BanaoCV session handoff.
5. Implement settings profile persistence, support tickets, admin roles/live records.
6. Implement direct phone/laptop PDF download with print fallback.
7. Audit every visible link/button/empty/error/loading state.
8. Deploy frontend and backend cloud services; GitHub alone does not run the product.

### Current first priority

Continue from the first unfinished item in `docs/IMPLEMENTATION_STATUS_AND_NEXT_STEPS.md`. Make coherent code changes, test syntax, preserve existing design quality and avoid creating unnecessary duplicate packages or demo-only logic.

## PROMPT END
