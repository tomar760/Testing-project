# BanaoCV — Master SOP & Mega Project Tree

**Version:** 1.0  
**Prepared for:** BanaoCV Owner / Super Admin  
**Date:** 29 July 2026  
**Main domain:** `https://banaocv.in`  
**Support email:** `supportbanaocv@gmail.com`

---

# 1. Is SOP ka simple meaning

## SOP kya hai?

**SOP = Standard Operating Procedure**

Simple words me:

> “BanaoCV me kaun kya karega, user kya dekhega, company kya karegi, report kahan jayegi, Admin kya karega aur system kaise safe rahega”—iska complete rulebook.

Is document ko aap future me:

- khud reference ke liye,
- team member ko samjhane ke liye,
- developer ko handoff dene ke liye,
- business/legal review ke liye,
- Admin operations ke liye,

use kar sakte ho.

---

# 2. Status legend

| Symbol | Meaning |
|---|---|
| ✅ LIVE / VERIFIED | Production me test ho chuka hai |
| 🟡 READY / NEXT TEST | Source ready hai ya controlled next verification chahiye |
| 🔵 PLANNED | Approved future module; abhi public feature nahi |
| ⛔ NOT ALLOWED | Platform policy/safety ke against |

---

# 3. BanaoCV Full Mega Tree

```text
BANAOCV PLATFORM
│
├── A. PUBLIC WEBSITE (Everyone dekh sakta hai)
│   │
│   ├── Homepage
│   │   ├── Hero: Resume + human career proof
│   │   ├── Templates preview
│   │   ├── Smart Apply Tracker entry
│   │   ├── Career Vault
│   │   ├── Pricing
│   │   ├── FAQ
│   │   └── Footer: Legal + Support
│   │
│   ├── Templates
│   │   ├── Free templates
│   │   ├── Premium templates
│   │   ├── Sample profile faces
│   │   └── Editor entry
│   │
│   ├── Pricing
│   │   ├── Free
│   │   ├── Premium
│   │   ├── Pro Monthly
│   │   └── Pro Annual
│   │
│   ├── Public Support
│   │   ├── FAQ
│   │   ├── Support email
│   │   └── Logged-in ticket entry
│   │
│   ├── Legal pages
│   │   ├── Privacy
│   │   ├── Terms
│   │   └── Refund / Cancellation
│   │
│   └── 404 Route Recovery
│       ├── Dashboard button
│       ├── Application Tracker button
│       └── Templates button
│
├── B. JOB SEEKER / USER SIDE
│   │
│   ├── Authentication ✅
│   │   ├── Email + Password Login
│   │   ├── Signup
│   │   ├── Email OTP verification
│   │   ├── Password reset email
│   │   ├── New password update
│   │   └── Google Sign-In
│   │
│   ├── Dashboard ✅
│   │   ├── User name + plan
│   │   ├── Profile photo
│   │   ├── Saved resume drafts
│   │   ├── Continue Editing
│   │   ├── Resume completion
│   │   └── Application summary
│   │
│   ├── Resume System ✅
│   │   ├── Choose template
│   │   ├── Create resume
│   │   ├── Autosave
│   │   ├── Refresh persistence
│   │   ├── Premium Studio guard
│   │   └── PDF download
│   │
│   ├── Plan & Payment ✅
│   │   ├── Razorpay order
│   │   ├── Razorpay signature verification
│   │   ├── Premium / Pro access
│   │   ├── Payment history
│   │   ├── Receipt PDF
│   │   └── Billing review request
│   │
│   ├── Profile & Settings ✅
│   │   ├── Name / career title / location
│   │   ├── Notification preferences
│   │   ├── Private profile photo upload
│   │   ├── Remove profile photo
│   │   ├── Download My Data JSON
│   │   ├── Account deletion request
│   │   └── Cancel active deletion request
│   │
│   ├── Support ✅
│   │   ├── Create ticket
│   │   ├── See ticket history
│   │   └── See admin response/status
│   │
│   └── Job Application Tracker ✅
│       ├── Add company / role / job URL
│       ├── Link selected BanaoCV resume
│       ├── Add location / notes
│       ├── Set follow-up date
│       ├── Status: Saved
│       ├── Status: Applied
│       ├── Status: Interview
│       ├── Status: Offer
│       ├── Status: Rejected
│       ├── Application Timeline
│       ├── Follow-up reminders
│       └── Dashboard momentum summary
│
├── C. ADMIN / SUPER ADMIN ✅
│   │
│   ├── Secure role check
│   │   ├── user = no Admin access
│   │   ├── support_agent = support-only
│   │   ├── admin = operations access
│   │   └── super_admin = full control
│   │
│   ├── Command Overview
│   │   ├── Users comparison
│   │   ├── Resume comparison
│   │   ├── Revenue comparison
│   │   ├── Funnel: Signup → Draft → Completed → Paid
│   │   ├── Activity feed
│   │   └── Template usage
│   │
│   ├── User Intelligence
│   │   ├── Real user list
│   │   ├── Plan
│   │   ├── Resume count
│   │   ├── Completion
│   │   ├── Location
│   │   ├── Last sign-in
│   │   ├── Role update (Super Admin)
│   │   └── Plan access update (Super Admin)
│   │
│   ├── Resume Operations
│   │   ├── Resume title
│   │   ├── Owner
│   │   ├── Template
│   │   ├── Completion
│   │   └── Draft / Complete / Stale state
│   │
│   ├── Applications Operations
│   │   ├── Candidate
│   │   ├── Company
│   │   ├── Job title
│   │   ├── Status
│   │   ├── Follow-up date
│   │   ├── Overdue follow-up count
│   │   ├── Today follow-up count
│   │   └── CSV export
│   │
│   ├── Payment Operations
│   │   ├── Verified payments
│   │   ├── Plan / amount / status
│   │   ├── Order ID / Payment ID
│   │   ├── Receipt PDF
│   │   └── CSV export
│   │
│   ├── Template Control
│   │   ├── Usage count
│   │   ├── Free / Premium type
│   │   ├── Enable template
│   │   └── Disable template
│   │
│   ├── Support Desk
│   │   ├── Open tickets
│   │   ├── Priority
│   │   ├── Status
│   │   ├── Admin reply
│   │   └── Ticket audit
│   │
│   ├── Privacy Requests
│   │   ├── Data deletion request
│   │   ├── Review status
│   │   ├── Private Admin note
│   │   └── Super Admin decision
│   │
│   ├── Billing Requests
│   │   ├── Cancellation request
│   │   ├── Downgrade review
│   │   ├── Private Admin note
│   │   └── No automatic refund
│   │
│   ├── Reports
│   │   ├── Users CSV
│   │   ├── Resumes CSV
│   │   ├── Applications CSV
│   │   ├── Payments CSV
│   │   └── Support CSV
│   │
│   ├── System Health
│   │   ├── API
│   │   ├── Supabase
│   │   ├── Email
│   │   ├── Razorpay
│   │   └── NVIDIA testing status
│   │
│   └── Audit Logs
│       ├── Role changes
│       ├── Plan changes
│       ├── Template changes
│       ├── Support changes
│       ├── Privacy changes
│       ├── Billing changes
│       └── Admin receipt downloads
│
├── D. FUTURE EMPLOYER / COMPANY PORTAL 🔵
│   │
│   ├── Employer Portal (separate design)
│   │   ├── Employer signup
│   │   ├── Company profile
│   │   ├── Company verification
│   │   ├── Employer dashboard
│   │   └── Company trust status
│   │
│   ├── Company Job Posting
│   │   ├── Draft job
│   │   ├── Submit for review
│   │   ├── Admin approve/reject
│   │   ├── Publish job
│   │   ├── Pause job
│   │   └── Expire job
│   │
│   ├── Candidate Apply Flow
│   │   ├── Candidate selects BanaoCV resume
│   │   ├── Candidate consents to apply
│   │   ├── Employer receives applicant
│   │   └── User tracker creates/updates application
│   │
│   ├── Employer Applicant Pipeline
│   │   ├── Received
│   │   ├── Shortlisted
│   │   ├── Interview
│   │   ├── Offer
│   │   └── Rejected
│   │
│   └── Trust & Safety
│       ├── Candidate reports company/job
│       ├── Fraud report
│       ├── Fee/payment demand report
│       ├── Fake job report
│       ├── Harassment report
│       ├── Admin review queue
│       ├── Unpublish job
│       ├── Suspend company
│       └── Audit history
│
├── E. DATA / CLOUD SERVICES
│   │
│   ├── Supabase
│   │   ├── Auth
│   │   ├── Postgres database
│   │   ├── Private profile photo Storage
│   │   └── Row Level Security
│   │
│   ├── Render
│   │   ├── Frontend Static Site
│   │   └── Express Backend API
│   │
│   ├── Brevo
│   │   └── Transactional password recovery email
│   │
│   ├── Razorpay
│   │   ├── Payment checkout
│   │   ├── Signature verification
│   │   └── Payment records
│   │
│   └── NVIDIA 🔵
│       ├── Current testing provider
│       ├── Key/model verified
│       └── Free endpoint queue unreliable
│
└── F. RULES / SAFETY
    │
    ├── No password visible to Admin
    ├── No reset token visible to Admin
    ├── No API secret in browser/GitHub/chat
    ├── No fake job listings
    ├── No job scraping
    ├── No automatic job application
    ├── No candidate job/interview fee allowed
    ├── No automatic refund
    ├── No automatic account deletion
    ├── Every sensitive Admin action audited
    └── Every new UI must pass phone/tablet/laptop Dark/Light QA
```

---

# 4. Role table — who can do what?

| Person type | What they can do | What they cannot do |
|---|---|---|
| Guest | View public pages, templates, pricing, legal pages, support FAQ | Resume save, payment, tracker, Admin |
| Job Seeker / User | Create resume, PDF, pay, track applications, photo, support ticket, export data | See other user data, Admin data, company controls |
| Support Agent | Update support tickets | Change plans/roles, see full financial controls, delete users |
| Admin | Real operations data, templates, reports, support | Grant Admin roles, final deletion/billing decision |
| Super Admin | Full platform control | Cannot view user passwords, tokens, card/bank details, API secrets |
| Future Employer | Company profile, job draft/post, applicants | See candidates before consent/application, bypass moderation |
| Future Candidate | Apply with chosen resume, track application | Auto-submit jobs, access company private notes |

---

# 5. Current user journey — step by step

## 5.1 User arrives on BanaoCV

```text
Homepage
→ View templates/pricing/features
→ Click Free Start / Login / Google
```

### User sees

- Hero
- Human career proof
- Templates
- Smart Apply Tracker entry
- Pricing
- Support/legal footer

---

## 5.2 User creates account

```text
Signup
→ Email OTP
→ Verify OTP
→ BanaoCV session
→ Dashboard
```

### User can also use

```text
Google Sign-In
→ Google consent
→ Supabase OAuth
→ BanaoCV session
→ Dashboard
```

---

## 5.3 User forgets password

```text
Forgot Password
→ BanaoCV verified recovery email
→ Reset page
→ New password
→ Login
```

### Rules

- Reset link is single-use/short-lived.
- User/Admin cannot see old password.
- Admin cannot see reset token.

---

## 5.4 User creates resume

```text
Dashboard
→ Templates
→ Choose Free/Premium template
→ Editor
→ Autosave
→ Refresh safe
→ PDF download
```

### Premium rule

```text
Free user opens Premium template
→ Pricing redirect

Premium/Pro user
→ Premium Studio opens
```

---

## 5.5 User pays

```text
Pricing
→ Razorpay checkout
→ Server signature verification
→ Payment row saved
→ Profile plan updated
→ Premium/Pro access
→ Receipt available
```

### Payment safety

- Browser payment success alone trusted nahi hota.
- Backend Razorpay signature + order notes verify karta hai.
- Payment record database me save hota hai.

---

## 5.6 User downloads receipt

```text
Settings
→ Plan & Billing
→ Receipt PDF
→ Backend-generated verified PDF
→ Phone/Laptop direct download
```

Receipt contains only safe payment metadata:

```text
Plan
Amount
Date
Payment ID
Order ID
Receipt number
Support email
```

Never contains:

```text
Card number
Bank details
Razorpay secret
API key
```

---

## 5.7 User uploads profile photo

```text
Settings
→ Change Photo
→ JPG / PNG / WebP
→ Backend validates type/size
→ Private Storage
→ Signed avatar URL
→ Settings + Dashboard avatar update
```

### Photo rule

```text
Maximum 4 MB
Private bucket
No public direct URL
User can remove photo
```

---

## 5.8 User tracks applications

```text
Application Tracker
→ Add company + job role
→ Add job link / location
→ Choose resume used
→ Add notes
→ Set follow-up date
→ Save
```

### Status flow

```text
Saved
  ↓
Applied
  ↓
Interview
  ↓
Offer

or

Rejected
```

### Timeline flow

```text
Application created
→ Status changed
→ Follow-up date set
→ Details updated
→ Timeline visible
```

---

# 6. User report flow — future employer/company fraud report

This is planned with Employer Portal Phase 4.

```text
User sees suspicious job/company
→ Click Report
→ Choose report type
→ Add explanation/proof
→ Submit
→ Admin Trust & Safety Queue
→ Super Admin review
→ Action
```

## Report types

```text
Fraud job
Candidate se paise mang rahe hain
Fake company
Suspicious website/link
Fake salary/job detail
Harassment
Spam
Other concern
```

## Report goes where?

```text
Candidate Report
→ Admin Trust & Safety Queue
→ Super Admin
→ Review status
→ Action + audit log
```

## Possible Admin actions

```text
Mark in review
Request more information
Reject false report
Unpublish job
Suspend company
Close report
Add internal note
```

### Important rule

A report alone company ko automatically remove nahi karegi.

```text
Report ≠ automatic ban
Review + evidence + Admin decision = action
```

---

# 7. Future Employer Portal SOP

## 7.1 Company signup

```text
Company creates employer account
→ Company profile
→ Contact person
→ Business email
→ Website / LinkedIn / location
→ Pending verification
```

## 7.2 Admin verification

```text
New company queue
→ Admin checks basic company details
→ Approve / Reject / Ask for clarification
→ Approved company can submit jobs
```

## 7.3 Company posts a job

```text
Employer Dashboard
→ Create job draft
→ Title
→ Location
→ Experience
→ Salary range
→ Skills
→ Description
→ Deadline
→ Submit for review
```

## 7.4 Job moderation

```text
Job draft
→ Pending review
→ Admin approve/reject
→ Published
→ Candidate can view/apply
```

## 7.5 Candidate applies

```text
Candidate opens approved job
→ Chooses BanaoCV resume
→ Confirms application
→ Employer receives applicant
→ User Application Tracker updated
```

## 7.6 Employer handles candidates

```text
Received
→ Shortlisted
→ Interview
→ Offer
→ Rejected
```

Candidate receives corresponding tracker update.

---

# 8. Company rules

## Company must do

```text
Use real company details
Post real job description
Use candidate data only for hiring
Keep salary/experience information accurate
Use respectful communication
Respond to applicants honestly
```

## Company must never do

```text
Ask candidate for job/interview/registration money
Post fake jobs
Misrepresent salary/company
Harass candidate
Sell candidate data
Use candidate resume outside hiring
```

## If company demands money

```text
Candidate reports
→ Admin review
→ Job unpublished
→ Company suspended/removed if confirmed
```

---

# 9. Candidate rules

## Candidate should

```text
Use genuine resume data
Apply thoughtfully
Use tracker honestly
Report real fraud concerns
Use respectful communication
```

## Candidate must not

```text
Create fake resume
Spam companies
Send abusive messages
Submit false fraud reports
Try to access company private data
```

---

# 10. Admin daily operating SOP

## Daily (5–20 minutes)

```text
1. Open Admin Overview
2. Check new users/resumes/revenue
3. Check open support tickets
4. Check overdue application follow-ups
5. Check Privacy Requests
6. Check Billing Requests
7. Check future company/job/report queue
8. Review audit log for unusual changes
```

## Weekly

```text
1. Download CSV reports
2. Review plan conversion
3. Review template usage
4. Review support resolution status
5. Review application funnel
6. Check failed/refunded payment records
7. Check new employer/job verification queue (future)
```

## Monthly

```text
1. Revenue and refund review
2. AI usage/cost review (when AI active)
3. Legal/refund policy review
4. Data export/deletion request review
5. Backup/check critical Supabase data
6. Review suspicious employer/candidate reports (future)
```

---

# 11. Privacy/account request flow

## Data export

```text
User clicks Download JSON
→ Backend verifies JWT
→ Only that user’s data queried
→ JSON download
```

### Included

```text
Profile
Resumes
Applications
Support tickets
Payment references
Deletion request history
```

### Excluded

```text
Password
OTP
Google token
Reset token
Payment card/bank data
Supabase/Brevo/Razorpay keys
```

## Deletion request

```text
User requests deletion
→ Request saved
→ Admin Privacy Queue
→ Super Admin review
→ Request status updates
→ Separate final deletion process if approved
```

### Important

```text
Request deletion ≠ account immediately deleted
```

User can cancel an active request before final review.

---

# 12. Billing/cancellation request flow

```text
Paid user clicks Request review
→ Billing request saved
→ Admin Billing Queue
→ Super Admin review
→ Status update
→ Separate verified business/Razorpay decision
```

## Possible status

```text
Requested
In Review
Approved
Rejected
Completed
Cancelled
```

### Important

```text
Billing request ≠ automatic cancellation
Billing request ≠ automatic refund
Plan change ≠ automatic Razorpay refund
```

---

# 13. Security mega rules

## Never expose

```text
Password
OTP
Reset URL/token
Google OAuth token
NVIDIA key
OpenAI key
Supabase service key
Brevo API key
Razorpay secret
JWT secret
backend/.env
```

## Never store in GitHub/frontend

```text
Any API key
Any secret
Any real .env file
Any user password
```

## Admin can never see

```text
User password
User OTP
Reset link
Google token
Card number
Bank details
API secrets
```

---

# 14. Current technical architecture tree

```text
GitHub main branch
│
├── Render Static Site
│   ├── frontend/*.html
│   ├── frontend/js/*
│   ├── frontend/assets/*
│   └── banaocv.in
│
├── Render Web Service
│   ├── Express server
│   ├── Auth API
│   ├── Resume API
│   ├── Payment API
│   ├── Profile API
│   ├── Application API
│   ├── Support API
│   ├── Admin API
│   └── NVIDIA AI API (testing)
│
├── Supabase
│   ├── Auth
│   ├── Profiles
│   ├── Resumes
│   ├── Payments
│   ├── Support tickets
│   ├── Applications
│   ├── Application timeline
│   ├── Privacy/deletion requests
│   ├── Billing requests
│   ├── Admin audit logs
│   └── Private photo Storage
│
├── Brevo
│   └── Password recovery / transactional email
│
├── Razorpay
│   ├── Checkout
│   ├── Order verification
│   └── Payment IDs
│
└── NVIDIA
    ├── Current AI test provider
    ├── Key/model valid
    └── Free queue unreliable
```

---

# 15. What is still pending?

## NVIDIA AI 🟡

```text
Key valid
Model valid
Free queue can be very long
Current configuration frozen by owner
Do not market as reliable until repeat browser AI success
```

## Employer Portal 🔵

```text
Approved design/direction
Not built yet
Needs organization/company/jobs/submissions/report data model
```

## Real Job Board / Recruiter ecosystem 🔵

```text
Not built yet
No fake jobs
No scraping
No automatic apply
```

## Legal/business inputs 🔵

```text
Final legal entity/business name
Tax/GST decision with CA
Final refund rules
Final jurisdiction
Final business contact/address
```

---

# 16. Final child-simple summary

```text
USER
→ makes resume
→ saves resume
→ downloads PDF
→ pays if needed
→ uploads photo
→ tracks applications
→ gets follow-up reminders
→ can export data
→ can request account deletion

ADMIN
→ sees real data
→ controls templates
→ reviews support
→ reviews privacy requests
→ reviews billing requests
→ sees application analytics
→ exports reports
→ keeps platform safe

FUTURE COMPANY
→ makes company profile
→ waits for approval
→ posts jobs
→ receives candidates
→ updates candidate status

FUTURE REPORT
→ user reports fraud/fee/fake job
→ Admin receives report
→ Admin verifies
→ job/company can be removed
```

---

# 17. Main contact

```text
supportbanaocv@gmail.com
```

---

## Owner note

Do not call a module "live" until:

```text
Code deployed
Migration run if needed
Browser tested on phone/laptop
Dark/Light checked
Data saved after refresh
Admin review checked where applicable
```
