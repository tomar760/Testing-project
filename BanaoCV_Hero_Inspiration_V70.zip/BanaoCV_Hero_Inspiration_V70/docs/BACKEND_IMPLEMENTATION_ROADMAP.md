# BanaoCV — Backend Completion Roadmap

## Current verified milestones

| Module | Status |
|---|---|
| Supabase project, schema and profiles trigger | Complete |
| Custom Brevo SMTP | Complete |
| Signup OTP email template | Complete |
| Password-reset email template | Complete |
| Google OAuth provider setup | Complete (callback wiring pending) |
| Supabase URL/redirect configuration | Complete |
| Local Express backend health | Complete |
| NVIDIA test adapter | Complete in v4 source |
| Signup, OTP verify, login and JWT `/me` | Tested successfully |
| Profile row creation | Tested successfully |
| Resume create/list/update persistence | Tested successfully |
| Password reset endpoint/page | Added in v4; user reports local check okay |
| Final UI design pages | Complete |

## Remaining MVP integration sequence

### Step 1 — Real editor persistence (next)

```text
Template selection → POST resume draft
Editor opened with ?id=...
GET saved resume data
Input/design changes → debounced PUT autosave
Dashboard Continue Editing → same resume ID
```

**Done when:** browser refresh does not lose a resume and dashboard displays the exact current draft/progress.

### Step 2 — Browser auth/dashboard v4 verification

```text
login.html → real signup/login/OTP
JWT browser session
Dashboard loads real user + real resume list
Logout clears session
```

**Done when:** all browser flow works without PowerShell.

### Step 3 — Premium plan access guard

```text
Free → editor.html
Premium / Pro → premium-editor.html
Backend verifies plan before premium save/export
```

### Step 4 — AI browser integration and quotas

```text
NVIDIA test model benchmark
Hindi → Resume
Score
JD Match
Cover Letter
Free/Premium/Pro credit limits
Admin AI usage records
```

### Step 5 — Google OAuth browser callback

```text
Google button → Supabase OAuth → callback → BanaoCV JWT session → dashboard
```

### Step 6 — Razorpay Test Mode + promo enforcement

```text
Create test order
Checkout callback
Server signature verification
Payment record
Plan unlock
WELCOME79 / creator-code server validation
```

### Step 7 — Settings, support and admin live APIs

```text
Profile updates
Support tickets
Admin roles
Live users/resumes/payments/AI usage
```

### Step 8 — Final QA and deployment

```text
Mobile/laptop browser QA
Security/role checks
No secrets in GitHub
Production SMTP sender/domain
Razorpay live KYC
Deploy frontend + backend
Connect banaocv.in
```

## Definition of final MVP

The product is final enough to launch only after Steps 1–6 pass in the browser and Step 8 deployment/security checks are complete. Admin/support live data can follow immediately after core launch if necessary, but Premium/Pricing claims must not be advertised as live until Step 6 works.
