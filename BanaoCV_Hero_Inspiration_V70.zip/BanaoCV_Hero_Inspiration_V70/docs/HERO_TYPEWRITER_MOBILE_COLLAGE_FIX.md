# BanaoCV Homepage Hero Micro-Fix — V45

## Scope (only these two changes)

1. **Hero rotating phrase**
   - Replaced the instant word swap with a progressive word-by-word writing effect.
   - A small animated caret makes the phrase feel like it is being typed.
   - V47 uses a true per-character typewriter: every letter and space appears every 110ms; the completed phrase remains readable for 2.2 seconds; every letter/space backspaces every 75ms; the next phrase begins after a 520ms gap. This creates a normal full type → hold → character-backspace → next phrase cycle.
   - Existing four phrase text values and hero CTA destinations remain unchanged.
   - Reduced-motion users keep the existing readable static phrase.

2. **Mobile hero visual collage**
   - Compact mobile-only layout for the profile portrait, score badge, sample resume and proof chip.
   - The complete collage now uses a fixed 230px visual stage on phones rather than the previous tall composition that appeared partially/cut off in the initial hero viewport.
   - Dedicated compact animations preserve scale instead of allowing the original animation to override it.

## Explicitly unchanged

- All other homepage content, sections, copy, buttons, links and navigation
- Authentication, Google sign-in, payment, jobs, employer system, application tracker, safety and notifications
- NVIDIA settings/model/timeout
- Database schema and migrations
- Global site/theme system

## Deployment

No Supabase SQL migration and no Render environment variable change is needed. This package only updates the existing homepage source.
