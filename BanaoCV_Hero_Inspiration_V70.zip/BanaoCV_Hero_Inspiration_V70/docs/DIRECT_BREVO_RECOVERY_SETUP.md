# BanaoCV — Direct Brevo Password-Recovery Delivery

## Why this change exists

The original reset path relied on Supabase Auth to create and dispatch a recovery email. The request could appear successful while no fresh transactional event reached Brevo. A later attempt to use Supabase Admin `generateLink` also did not reliably produce a usable link for the existing production account. The hosted Supabase JavaScript Admin `listUsers` call then returned `AuthUnknownError`; BanaoCV reads the same backend-only GoTrue Admin users endpoint with a safe raw HTTP parser instead.

The direct SMTP relay then reached Brevo from Render but timed out (`ETIMEDOUT`) before delivery. Therefore the final delivery transport uses Brevo’s HTTPS Transactional API on port 443 rather than SMTP port 587.

```text
Browser → BanaoCV API → verify existing confirmed Auth user
                         ↓
                    create random single-use BanaoCV reset token
                         ↓
                    store only SHA-256 token hash in Supabase
                         ↓
                    Brevo HTTPS Transactional API sends BanaoCV reset URL
                         ↓
                    reset page consumes token once → Supabase Admin updates password
```

- Supabase remains the source of user identity and the backend-only authority that updates the password.
- The raw reset token exists only in the email URL; the database retains only its SHA-256 hash.
- Tokens expire after 20 minutes by default, become invalid after one successful use, and a new request invalidates prior unused links.
- Brevo must return a Transactional API `messageId` before the browser receives the actual reset-email success response.
- A per-IP recovery limit of 3 requests/hour protects sender reputation.

## Required one-time Supabase migration

Before deploying this flow, run **once** in Supabase SQL Editor:

```text
backend/migrations/002_direct_password_recovery.sql
```

It creates the backend-only `password_reset_tokens` table. Do not edit its SQL, do not expose its rows, and do not add browser/RLS policies.

## One-time Render configuration

Set these values privately in **Render → banaocv-api → Environment**. Never put them in GitHub, frontend code, chat or screenshots.

| Render variable | Value source |
|---|---|
| `BREVO_API_KEY` | A new/private Brevo **API key** created under SMTP & API → API Keys |
| `BREVO_FROM_EMAIL` | Already verified Brevo sender email |
| `BREVO_FROM_NAME` | `BanaoCV` |
| `PASSWORD_RESET_TTL_MINUTES` | Optional; leave unset for secure 20-minute default |

Keep existing values unchanged:

```text
SUPABASE_REDIRECT_URL=https://banaocv.in/reset-password.html
FRONTEND_URL=https://banaocv.in,https://www.banaocv.in
```

The older `BREVO_SMTP_*` variables may remain in Render but are no longer used by the reset-mail feature. Do not change Supabase API keys, Razorpay variables, JWT secret, DNS records or the existing Supabase SMTP configuration.

## v18 delivery transport correction

No new SQL migration is required. v18 replaces only the timed-out Render-to-SMTP connection with Brevo’s HTTPS API. It needs a private `BREVO_API_KEY` in Render; an SMTP key will not work for this value.

## Secure production test

1. Keep the completed migration, deploy the code, add the private Render API key, and wait for the backend to show **Live**.
2. Open `https://banaocv.in/login.html` and hard-refresh (`Ctrl + Shift + R`).
3. Submit **one** password-reset request for the existing confirmed account.
4. The browser must show `Secure reset link email par bhej diya gaya hai` only after Brevo returns a `messageId`.
5. In Brevo Transactional → Logs, a new event must appear immediately or within a short delay.
6. Open the newest email link, set a new unique password, then sign in.

## Failure behavior

- `Reset email abhi send nahi ho paya` means no success was claimed; first confirm the private `BREVO_API_KEY` and verified sender email are present in Render.
- The hourly-limit message means wait one hour; do not repeatedly click reset.
- If Brevo shows accepted/delivered but inbox does not, check Spam, Promotions and All Mail.

## Security rules

- Do not expose `BREVO_API_KEY`, Supabase service-role key, reset URLs, raw reset tokens or passwords.
- Do not log raw reset links, raw tokens, recipient email addresses or API credentials in production code.
- Do not mark a reset request successful before Brevo accepts the HTTPS API request and returns a message ID.
