# Dashboard Controls + Pricing/Login Theme Polish — V51

## Dashboard resume controls

- Reworked Dashboard `Edit` and `Delete` into compact, pill-shaped premium chips.
- Reduced height, padding and visual weight; no more large square-looking controls.
- Edit uses a subtle green/gold-influenced premium visual; Delete uses a restrained red safety treatment.
- Mobile actions remain compact and readable.
- Existing Edit and secure owned-resume Delete behavior is unchanged.

## Pricing page

- Added intentional Light/Dark surface, card, plan, billing toggle, comparison, FAQ, checkout modal and form contrast styling.
- Dark mode uses dark green/charcoal premium surfaces with readable text and visible boundaries.
- Light mode preserves clean ivory/white pricing readability.
- Razorpay checkout, plans, prices, promotion logic and account/payment behavior are untouched.

## Login page

- Added matching dual-theme contrast polish for account card, form fields, Google button, tab switcher, messages, divider, reassurance and theme control.
- Both mobile and desktop Light/Dark states keep labels, text, inputs and calls-to-action readable.
- Login/signup/OTP/Google/recovery handlers are unchanged.

## No infrastructure change

No database migration, Supabase change, Render environment update, API key, payment configuration or Auth behavior change is required.
