# BanaoCV Batch Editor, Dashboard, Homepage & PDF Upgrade — V52

## Included batch scope

### 1. Dashboard profile and journey

- Real profile completion calculated from saved profile fields only: name, career title, location, phone, career goal and optional private profile photo.
- Dashboard profile card shows the actual percentage, missing detail chips and career progress states.
- Dashboard now has a direct Profile modal: edit name, career title, location, phone, language, career goal and optional private photo without leaving Dashboard.
- Existing Settings remains available for advanced profile controls.
- Career journey is now real: Profile → Resume → Jobs → Apply. States update from profile completion, resume count, saved jobs and application count.
- Mobile Dashboard includes a clear Logout action; desktop sidebar logout stays unchanged.

### 2. Homepage Career Toolkit

- Smart Apply Tracker replaces the old generic CSS mock visual with the existing premium people/career application image asset.
- Added a clear tracker status badge and a real workflow message: save roles, track follow-ups and keep chosen resumes ready for manual application.
- Real Application Tracker link remains unchanged. No auto-apply claim/feature was introduced.

### 3. Dashboard sidebar

- Improved BanaoCV logo scale, sidebar font hierarchy, premium icon containers, active navigation state, hover state and logout treatment.
- Routes and existing navigation behavior remain unchanged.

### 4. Resume photo and click-to-edit

- Resume profile photo is opt-in per resume. Existing private account photo is never automatically added.
- User can add/change private profile photo directly from Personal Info in editor, explicitly toggle it for the current resume and manage it in Settings.
- Photo is rendered in the resume preview/PDF only when the current resume has photo enabled.
- Click Name, Title, Contact, Photo, Summary, Experience, Education or Skills in resume preview to open/focus the relevant editor area.

### 5. Cleaner editor and PDF

- Recurring automatic AI tips/floating tip strip are hidden permanently for a cleaner editor. User-initiated AI buttons remain.
- Dedicated full Resume Preview modal added to desktop action rail.
- Editor action buttons are visually refined: Templates, Preview, Share, Download PDF and Premium/Pro Print PDF.
- Standard PDF uses a higher 2.5 scale instead of previous 2 scale; Premium/Pro Print PDF uses 4 scale and is clearly labelled in UI.
- Quality labels are based on actual render scale, not a fake “4K” label. Browser/device limits can still affect unusually large resumes/photos.

## Safety and compatibility

- No database migration or environment update.
- Existing owned resume API, profile private photo route, autosave, template compatibility, Auth, Google, payment, employer marketplace, safety/notifications and frozen NVIDIA config remain unchanged.
- Profile image is user-owned/private and only inserted into a resume when the user opts in for that specific resume.
