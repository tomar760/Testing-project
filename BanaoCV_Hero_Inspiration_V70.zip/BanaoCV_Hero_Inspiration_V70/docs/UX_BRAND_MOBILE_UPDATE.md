# BanaoCV — Logged-In Navigation, Dark Default, Brand & Mobile Update

## Scope approved by owner

This update is deliberately limited to public/user UX and does **not** change the frozen Auth stack, password/reset flow, session issuance, Pro plan, Razorpay logic or backend data APIs.

## Changes included

### Logged-in navigation

- Added `frontend/js/session-nav.js`.
- When an existing BanaoCV browser session is present, public-page `Login` links become a clear `Dashboard` route.
- Login/reset pages retain their normal unauthenticated behavior.

### Dark theme default

- Dark is now the product default for first-time/legacy visitors.
- Light mode appears only after a user deliberately selects it using the one global fixed theme control.
- Legacy auto-saved Light values are ignored because they were created by the old default, not necessarily by a user choice.
- Explicit Light/Dark selections persist across pages.

### One official logo and favicon

- All page brand containers use the same supplied official BanaoCV solid artwork in both Dark and Light themes.
- The logo is larger and consistent in headers, sidebars, login and footer.
- Added the official B/document mark as `banaocv-favicon.png`; every production page references it as browser-tab favicon.

### Homepage mobile cleanup and human proof

- Rebuilt the Career Vault layout from inline desktop grid markup into responsive classes.
- On phones, Career Vault content now stacks vertically; right-side cards no longer overflow/crop or create blank visual space.
- Improved mobile hero spacing, headline/CTA behavior, resume mockup scale and score badge position.
- Added an original BanaoCV people-and-proof hero collage: a sample product-professional portrait, layered sample-face stack, profile-ready signal and populated resume card. It is an original BanaoCV composition, not a copy of another site.
- Replaced cropped portrait Career Toolkit imagery with responsive landscape Job Board and Recruiter Match compositions so faces/content fit inside phone cards.

### Template sample profiles

- Added original illustrative sample profile portraits to populated Template Atelier resume previews.
- Faces are clearly used as sample/illustrative profiles only; they are not real users and are not inserted into a user's actual resume unless the user chooses their own photo in a future live upload flow.

## Validation completed

- JavaScript syntax checks passed for `theme.js`, `brand.js` and `session-nav.js`.
- All 15 production page sources contain `data-theme="dark"`, favicon markup and session navigation script.
- Homepage contains the responsive Career Vault classes and landscape image references.

## Production deployment

A frontend-only GitHub/Render deploy is required. No Render secret, SQL migration, Supabase setting, Brevo setting, DNS record or Auth configuration changes are required.
