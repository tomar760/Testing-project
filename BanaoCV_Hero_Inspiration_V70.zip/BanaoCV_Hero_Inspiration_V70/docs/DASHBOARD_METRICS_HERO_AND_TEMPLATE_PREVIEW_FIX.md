# Dashboard Metrics, Welcome Hero & Template Preview Micro-Fix — V48

## Scope (only requested dashboard/templates changes)

### Dashboard accuracy

Removed two fabricated static numbers that were identical for every user:

```text
128 Profile Views
17 Downloads
```

Replaced with real current-user values:

```text
Applications  → existing private Application Tracker summary total
Saved Jobs    → current user's private Saved Jobs total
```

No artificial profile-view/download tracking has been added. Those actions are not currently tracked server-side, so they are not displayed as fake analytics.

### Dashboard Welcome Hero

- Added a subtle, low-opacity paper/resume sheet behind the greeting.
- Greeting content remains above the paper with correct readable z-index.
- Adjusted mobile positioning/opacity so the design cannot compete with the welcome text.
- No greeting copy, dashboard actions or links were changed.

### Templates Preview control

- Replaced the plain overlay `Preview` button with a premium gold-gradient `Preview Design` button.
- Added eye icon, `Full layout dekho` helper text, subtle depth/shadow and touch-friendly size.
- The existing preview modal and `Use` action remain unchanged.

## Explicitly unchanged

- Authentication, Google login, payments, employer system, jobs, candidate features, safety, notifications, AI configuration and database migrations.
- No Supabase SQL migration or Render environment change is needed.
