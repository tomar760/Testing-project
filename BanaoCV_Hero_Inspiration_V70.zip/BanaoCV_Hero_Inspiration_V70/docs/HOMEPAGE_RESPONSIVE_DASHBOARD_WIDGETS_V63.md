# Homepage Responsive Composition & Dashboard Widget Identities — V63

## Homepage

- Adds phone-first responsive width/spacing constraints across Hero, proof ribbon, story sections, AI showcase, career tools, CTA and footer.
- Prevents content from appearing narrow/left-shifted with excessive empty right-side space on phone widths.
- Keeps user browser zoom available; default layout is responsive/stable rather than forcing browser zoom.
- Mobile hero type caret remains hidden and right visual composition remains unified.
- Floating Guide launcher is hidden only on homepage phone layout to avoid covering hero/content; Guide remains available on app pages and the dedicated Guide page.

## Dashboard

- Application Tracker uses a distinct document/tracker icon treatment.
- Recent Activity uses a distinct activity/history icon treatment.
- Activity row icons use a matching gold activity visual.

No data/API/security/AI/provider/migration/generated image change.
