# BanaoCV — Secure Profile Photo Upload

## What is real

```text
Settings file picker
→ BanaoCV authenticated backend
→ type/size validation
→ private Supabase Storage bucket
→ profile avatar path
→ one-hour signed display URL
→ Settings + Dashboard avatar
```

## Security model

- Bucket is private (`public = false`).
- Browser does not receive direct Supabase Storage upload access.
- Backend validates authenticated user, MIME type and 4 MB maximum size.
- Allowed formats: JPG, PNG, WebP.
- File path is scoped to the authenticated user ID.
- Display uses a short-lived signed URL, not a permanent public URL.
- User can remove their own photo.

## One-time Supabase migration

Run once in Supabase SQL Editor:

```text
backend/migrations/004_private_profile_photos.sql
```

Expected result:

```text
Success. No rows returned
```

The migration adds `profiles.avatar_path` and creates/updates the private `profile-photos` Storage bucket. Do not add public browser Storage policies.

## Browser test

1. Sign in normally.
2. Settings → Your identity → Change photo.
3. Select a JPG, PNG or WebP smaller than 4 MB.
4. Expected: Settings avatar updates immediately.
5. Open Dashboard: sidebar avatar shows the same image.
6. Refresh Settings/Dashboard: avatar remains.
7. Use Remove: initial avatar returns.

## No change required

No Cloudinary account, new API key, Render environment value, Google setting, Auth change, payment change or DNS update is required.
