# BanaoCV — Rendered Viewport QA

## Why this audit was added

Source/static checking alone was not accepted as proof of visual readiness. This pass used a real Chromium renderer against the production source/local equivalent to inspect actual layout and computed colors.

## Tested public pages

- Homepage
- Login
- Templates
- Pricing
- Support
- Privacy
- Terms
- Refund
- 404

## Tested modes and viewports

| Viewport | Width × height | Dark | Light |
|---|---:|---:|---:|
| Phone | 390 × 844 | PASS | PASS |
| Tablet | 768 × 1024 | PASS | PASS |
| Laptop | 1366 × 900 | PASS | PASS |

No horizontal overflow was found in the tested page/mode/viewport matrix.

## Targeted fixes made after rendering review

- Homepage proof ribbon had translucent white cards with low Dark contrast; corrected to dark solid surfaces and mint/high-contrast metric text.
- Career/co-pilot, Career Vault and FAQ labels using dark emerald were raised to readable mint in Dark mode.
- Career Toolkit labels were being visually swallowed by the absolute image area; labels are now elevated solid emerald chips with white text.
- Smart Auto Apply inner profile image was incorrectly captured by a broad Toolkit artwork selector, creating a full-height cropped face on phone. Selectors are now direct-child-only, with a static 42px avatar rule and dedicated mobile layout. Chromium screenshot verification confirmed the corrected compact avatar/CV/company-card journey at 390px.
- Homepage Hero title/subtitle/trust/resume sample now use direct light/dark values.
- Login heading no longer uses transparent gradient text; direct readable colors are used in both modes.
- Login labels, tabs, helper/forgot text and Career Passport surface were checked in rendered Dark/Light phone view.
- Hero CTA mobile width is capped for more balanced phone button scale.

## Notes

- Authenticated product pages require a real browser session; Settings was rendered with safe mocked API responses to verify its plan/profile form layout in both themes.
- Actual production user flows remain subject to existing live QA records: login, reset, Google, dashboard, editor, PDF, Pro/Premium and Admin.
