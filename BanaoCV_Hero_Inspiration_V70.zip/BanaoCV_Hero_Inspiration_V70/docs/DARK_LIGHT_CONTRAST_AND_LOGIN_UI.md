# BanaoCV — Dark/Light Contrast & Login UI Update

## Scope

This update is visual/UI only. It does not change the frozen authentication backend, password-reset email delivery, recovery-token validation, Supabase Auth configuration, session format, payment plan, Razorpay verification or database logic.

## Site-wide contrast protection

The shared `frontend/js/theme.js` now adds an explicit contrast safety layer on every page:

- Native inputs, textareas, selects and placeholders have readable foreground/background/border colors in both themes.
- Common translucent surface classes used across product/public/legal/support/settings pages receive dark-theme surface, border and typography protection.
- Dark and Light color schemes are declared to the browser so native controls/scrollbars follow the active theme.
- Explicit user theme selection remains persistent; Dark stays the default.

## Smart Auto Apply

The old plain role-line visual is replaced with an original animated application journey:

- Sample professional portrait and role-ready CV
- Animated application paths/pulses
- Colourful fictional company state cards: Shortlisted, Applied and Follow-up
- Motion-safe fallback for users with reduced-motion preferences

It is illustrative product storytelling, not a claim that automatic job applications are already live.

## CTA banner

The final homepage CTA now has:

- Layered emerald/amber gradients and animated orbit details
- Illustrative sample-profile face stack
- Career-ready detail signal
- Responsive phone layout and reduced-motion support

## Login visual refresh

- Added a visual-only `Private Career Passport` surface, a stronger card treatment, colourful primary action gradient and illustrative sample-face stack in the desktop story panel.
- Updated Google UI language so it accurately states that Google sign-in setup is in progress; email/password login remains the live option.
- Pressing **Enter** on the Login view now calls the exact existing `handleLogin()` path used by the visible Login button.
- Signup, OTP, forgot-password, reset-password and API calls are unchanged.

## Final hero and Login contrast seal

After live source inspection, explicit component-level contrast rules were also added for the two user-reported areas:

- Homepage hero heading, subheading, trust row, outlined CTA and all sample-resume typography now receive direct Light/Dark values rather than relying only on inherited variables.
- Login heading avoids transparent gradient text, and Login labels, tabs, helper text, forgot link and Career Passport surface now receive direct readable Light/Dark values.

## Rendered validation

- Syntax checks passed for shared theme code and the homepage/login inline scripts.
- Chromium rendered QA was completed for public pages in Phone (390px), Tablet (768px) and Laptop (1366px) widths in Dark and Light modes.
- The audit found/fixed low-contrast homepage proof cards, dark emerald labels and Career Toolkit image-label overlap. No horizontal overflow remained in the tested public page matrix.
- Existing profile assets are local and referenced with sample/illustrative descriptions.
- Full rendered evidence and viewport matrix are recorded in `RENDERED_VIEWPORT_QA_2026-07-24.md`.
