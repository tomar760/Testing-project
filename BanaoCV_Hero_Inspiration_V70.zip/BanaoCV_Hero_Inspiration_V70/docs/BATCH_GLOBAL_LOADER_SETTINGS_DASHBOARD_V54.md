# Global Loader, Settings Photo Flow & Dashboard Refinement — V54

## Global BanaoCV loader

- Shared `js/theme.js` now starts one reusable text-free BanaoCV loader.
- Loader uses CSS and inline SVG only; no image/PNG asset is generated.
- Light/Dark and reduced-motion are supported.

## Settings profile correctness

- Settings completion no longer uses static `72%`; it uses actual name, career title, location, phone, career goal and optional photo fields.
- Static `AT` initial/nav avatar is hidden behind a secure gate and replaced with actual profile photo/initials after profile data loads.
- Profile photo flow is now select → preview → circle/square guide → drag position → zoom → confirm/save.
- Crop is uploaded through the existing private profile-photo endpoint.

## Dashboard refinement

- Dashboard uses Manrope (open web font) for a clean Claude-inspired dashboard style; no proprietary font is copied.
- Recent Activity now uses actual resume, application and saved-job data.
- Active paid plan card has premium shield presentation and improved theme contrast.
- Dashboard sidebar scroll and secure no-flash gate remain active.

## Scope safety

No database migration, secret, environment, payment, Auth/Google, employer marketplace, safety or NVIDIA configuration change.
