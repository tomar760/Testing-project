# BanaoCV — Editor Autosave Integration v5

## What is wired

```text
Template URL → authenticated POST /api/resume create draft
editor.html?id=... → GET /api/resume/:id load draft
Input/design/section changes → 850ms debounce → PUT /api/resume/:id
Dashboard → GET /api/resume → real saved draft / Continue Editing
Premium saved templates → premium-editor.html?id=...
```

## Test flow

1. Keep backend running on port 5000.
2. Serve frontend on port 5500.
3. Login through the real `login.html` UI.
4. Open `templates.html`, select a template.
5. Update content in editor and wait for `Saved` status.
6. Refresh browser; data must remain.
7. Return to dashboard; the same draft should appear with real completion and Continue Editing.

## Notes

- JWT is browser local-storage based for development. Production needs stronger CSP/cookie/session hardening.
- Backend plan verification will later gate Premium Studio actions.
