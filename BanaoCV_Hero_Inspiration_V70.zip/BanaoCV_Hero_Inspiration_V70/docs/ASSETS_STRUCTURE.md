# BanaoCV — Asset Structure

All final frontend visual files belong inside `frontend/assets/` in the GitHub project.

```text
frontend/assets/
├── brand/
│   ├── banaocv-logo-outline.png
│   └── banaocv-logo-solid.png
│
├── profiles/
│   └── aditya-tomar-profile.jpg
│
└── home/
    ├── image1-hero-career.jpg
    ├── image2-ai-guidance.jpg
    ├── image3-job-board.jpg
    ├── image4-recruiter-match.jpg
    ├── image5-career-coach.jpg
    └── image6-success-community.jpg
```

## `brand/`

| Asset | Purpose | Current usage |
|---|---|---|
| `banaocv-logo-outline.png` | Official light/outline BanaoCV logo artwork for marketing, social posts, email headers and future Open Graph graphics | Kept as an official brand asset; not used in small UI headers because inline SVG is sharper/responsive there |
| `banaocv-logo-solid.png` | Official solid BanaoCV logo artwork for dark marketing surfaces, banners, social content and future app-store/share graphics | Kept as an official brand asset; not used in small UI headers because inline SVG is sharper/responsive there |

**Do not delete either logo.** They are useful official brand source assets. Later we can derive favicon, app icon, Open Graph image and email logo variants from them.

## `profiles/`

| Asset | Purpose |
|---|---|
| `aditya-tomar-profile.jpg` | AI-generated fictional portrait used only inside the homepage sample resume mockup. It is not a real user profile. |

## `home/`

| Asset | Homepage placement |
|---|---|
| `image1-hero-career.jpg` | Career co-pilot story section |
| `image2-ai-guidance.jpg` | AI guidance section |
| `image3-job-board.jpg` | Smart Job Board section |
| `image4-recruiter-match.jpg` | Recruiter Match section |
| `image5-career-coach.jpg` | Career guidance section |
| `image6-success-community.jpg` | Community CTA section |

## Why the web headers use inline SVG instead of PNG

The current website headers use inline SVG logo marks because they:

- stay sharp at every phone/laptop resolution;
- inherit light/dark theme colours cleanly;
- load faster for small header icons;
- do not crop the full wide PNG logo into a tiny space.

The PNG logo assets remain valuable for external marketing and future social-preview/favicons.
