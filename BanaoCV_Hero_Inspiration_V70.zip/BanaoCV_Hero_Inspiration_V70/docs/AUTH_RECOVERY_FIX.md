# BanaoCV — Password Recovery Reliability

## Current secure flow

1. User enters email on `login.html`.
2. BanaoCV backend applies a recovery rate limit and checks the existing confirmed Supabase Auth user server-side through the backend-only GoTrue Admin HTTP endpoint. This avoids the hosted SDK `AuthUnknownError` seen with `listUsers`.
3. Backend creates a cryptographically random 256-bit token; only its SHA-256 hash is saved to the backend-only `password_reset_tokens` table.
4. Backend makes a BanaoCV reset URL containing the raw token and sends it through Brevo's HTTPS Transactional API directly.
5. The browser receives actual success only after Brevo returns a transactional message ID.
6. `reset-password.html` submits the raw token and new password over HTTPS.
7. Backend atomically consumes the token once, then uses Supabase Admin to set the new password.

The token is single-use, the latest requested token invalidates older unused ones, and it expires after 20 minutes by default. This completely avoids the previous Supabase recovery-email and `generateLink` dispatch path that did not reliably create a fresh Brevo event.

## Required production configuration

1. Run `backend/migrations/002_direct_password_recovery.sql` once in Supabase SQL Editor.
2. Keep `SUPABASE_REDIRECT_URL=https://banaocv.in/reset-password.html` in Render; it is now the safe BanaoCV reset-page base URL.
3. Add the private Brevo API key and verified sender values to the Render backend as documented in `DIRECT_BREVO_RECOVERY_SETUP.md`.

## Delivery and security behavior

- Brevo delivers a BanaoCV-generated reset URL; Supabase Admin remains the backend-only authority that changes passwords.
- The server never sends SMTP credentials, reset links, user identifiers or raw tokens to browser logs/responses.
- Passwords are never readable/recoverable from Supabase. They can only be replaced through a valid reset URL.
- Recovery requests are limited to three per IP address per hour.

## Production validation

1. Deploy code, migration and private Render SMTP settings.
2. Request exactly one reset link for the existing confirmed account.
3. Confirm a fresh Brevo Transactional Log event appears.
4. Open the newest link, set a new unique password and sign in.
