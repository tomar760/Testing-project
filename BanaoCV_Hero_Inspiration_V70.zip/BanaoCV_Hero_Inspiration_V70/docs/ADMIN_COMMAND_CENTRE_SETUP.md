# BanaoCV — Secure Live Admin Command Centre

## What this implementation makes real

The Admin Command Centre replaces mock records with authenticated server data:

- Server-side role check before `admin.html` loads data.
- Real users: email, plan, role, resume count, completion, location and last sign-in.
- Real resume drafts: template, completion, state and update time.
- Real Razorpay records already saved in BanaoCV's `payments` table.
- Real support queue: status, priority and admin reply updates.
- Real template usage and server-enforced template availability.
- Real period comparison: signups, resumes and paid revenue.
- Real charts/funnel calculated from stored records.
- Real server-safe health statuses without exposing API keys/secrets.
- Server-generated CSV downloads and immutable Admin audit entries.

## Security model

```text
Browser JWT → /api/admin → JWT middleware → profiles.role lookup → role guard → data/action
```

- A hidden frontend link is **not** used as security.
- The backend fetches the current profile role for each protected Admin request.
- `super_admin` has full role/plan/template controls.
- `admin` has real operational data/template control but cannot grant roles.
- `support_agent` may work only on support tickets.
- Normal `user` has no Admin API access.
- Passwords, reset links/tokens, SMTP/API keys, card data and Supabase credentials are never returned by these endpoints.

## Required one-time migration

Run this once in Supabase SQL Editor:

```text
backend/migrations/003_admin_command_centre.sql
```

Expected result:

```text
Success. No rows returned
```

The migration creates:

- `admin_audit_logs`
- `template_admin_settings`
- profile role/status support plus indexes

## Secure owner assignment — after deployment

Use the Supabase SQL Editor privately. Replace only `YOUR_LOGGED_IN_BANAOCV_EMAIL` with the email of the BanaoCV account that should be the owner. Do not paste the email into GitHub or chat.

```sql
update public.profiles
set role = 'super_admin', updated_at = now()
where id = (
  select id
  from auth.users
  where lower(email) = lower('YOUR_LOGGED_IN_BANAOCV_EMAIL')
);
```

Then sign out and sign in again once, open `https://banaocv.in/admin.html`, and verify the real Command Centre loads.

## Future additional administrators

A Super Admin can assign these roles from the real Users drawer:

| Role | Allowed scope |
|---|---|
| `super_admin` | All data, roles, plan access, templates, reports, system and audit logs |
| `admin` | Operational data, templates, reports, system; cannot grant roles |
| `support_agent` | Support ticket queue/status/priority/reply only |
| `user` | No Admin access |

Never share one admin password. Every administrator must use their own BanaoCV account.

## Intentionally not included

- No automatic Razorpay refund/charge action.
- No direct password/view/reset-token access.
- No automatic user suspension/deletion action.
- No fake job/recruiter/AI data. AI remains visibly paused until a production provider is selected.
