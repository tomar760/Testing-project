# Hero, Dashboard Real Data & AI Reliability — V62

## Homepage mobile hero

- Removed the mobile typewriter caret that could appear as an unwanted coloured vertical line inside the headline.
- Strengthened the right-side mobile career visual background/pattern so the hero composition feels intentional rather than leaving an empty visual area.
- Existing headline copy, typewriter words, CTA destinations and profile collage remain intact.

## Dashboard data integrity

Replaced remaining static/fabricated dashboard widgets:

- Static AI Coach advice → **BanaoCV Guide** real entry
- Static Overall Score 86 → **Career Snapshot** graph with actual resume count, completion values and bars
- Static Daily Tips → **Next Steps** driven by actual profile/resume/application state
- Recent Activity remains actual resume/application/saved-job data
- Active paid plan uses actual plan data with premium shield visual

## BanaoCV Guide reliability

- Backend fallback layer now answers common BanaoCV questions without depending entirely on Groq.
- If Groq response fails/malformed, user sees curated resume/profile/jobs/cover-letter/support guidance rather than generic server error.
- Unknown topics get honest Support action rather than hallucinated feature claims.
- Frontend mini launcher also has local fallback if API request fails.

## Visual refinements

- AI Guide desktop/mobile shell uses chat-only scrolling.
- Dark Guide page contrast improved.
- Floating Guide launcher icon fit tightened.
- Editor AI tools get distinct icon treatments.

No migration, key, environment, payment/Auth core, marketplace or generated image asset change.
