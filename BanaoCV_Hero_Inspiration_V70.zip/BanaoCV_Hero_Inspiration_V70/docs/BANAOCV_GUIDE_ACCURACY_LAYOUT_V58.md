# BanaoCV Guide Accuracy & Layout Correction — V58

## Guide reliability

Guide now has two answer layers:

1. **Deterministic curated fallback** for common BanaoCV intents:
   - Resume / Templates / Editor
   - Profile / Settings
   - Jobs / Applications / Withdrawal
   - Cover Letter
   - Plans
   - Support
   - Sensitive-data refusal

2. **Groq answer layer** only when it returns a valid useful structured answer. If provider errors, malformed JSON or insufficient action mapping occur, the curated fallback answer/actions are returned instead of a generic server error.

Unknown questions receive an honest Help/Support route rather than invented facts.

## Guide page layout

Desktop:

- Fixed app viewport
- Fixed header/sidebar/composer
- Only messages container scrolls

Mobile:

- Full-height chat shell
- Sidebar collapses
- Quick prompts remain in chat
- Only chat messages scroll

## Visual corrections

- Stronger Dark mode Guide atmosphere and card depth
- Floating launcher mark has fixed square fit, overflow clipping and centred SVG
- Editor AI tool icon shapes/colours/spacing are refined for Hindi Resume, Score, Guided Summary, JD Match and Cover Letter

## Safety

No key, user sensitive data, cross-user data or sensitive action is exposed. Support remains draft + user confirmation.
