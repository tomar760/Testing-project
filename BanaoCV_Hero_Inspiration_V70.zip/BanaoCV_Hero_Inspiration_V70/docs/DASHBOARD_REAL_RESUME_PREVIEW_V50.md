# Dashboard Real Resume Preview Micro-Fix — V50

## Purpose

Before editing/deleting a resume, users can now identify it visually from the Dashboard instead of seeing identical generic document lines.

## What each Dashboard row shows

- Existing profile photo, when user has uploaded one
- Initials fallback when no profile photo exists
- Actual saved resume name from `content.name` / resume title
- Actual saved role/title from `content.title`
- Template/design accent colour when available
- First saved experience role/company indicator
- Summary and Skills section fill indicators
- Current completion percentage
- Existing last-updated metadata

The Dashboard does not invent profile data. It reads only the current user’s existing saved resume content/design and existing private profile avatar URL.

## Resume controls retained

- Latest edited resume: prominent **Continue Editing** + Delete
- Other resumes: normal **Edit** + Delete
- Delete confirmation and secure owned-resume API behavior remain unchanged

## Safety / scope

- No new database fields or migration
- No public exposure of resume/profile content
- No Auth, payment, jobs, employer, safety, notifications or AI change
- No fake profile views/downloads
