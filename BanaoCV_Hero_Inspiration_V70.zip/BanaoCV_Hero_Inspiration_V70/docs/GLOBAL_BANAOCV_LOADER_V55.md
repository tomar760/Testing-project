# Global BanaoCV Loader — V55

## Goal

Replace generic spinner/loading cards with one distinctive BanaoCV visual loading identity used everywhere.

## Design

The loader is pure CSS + inline SVG:

- Three animated career/orbit tracks
- Floating BanaoCV document card
- Two glowing opportunity sparks
- Emerald, gold and mint brand palette
- No text
- No PNG/image asset
- No external loader library

## Consistent use

The same loader is used for:

- Normal initial page loading through shared `js/theme.js`
- Premium Editor secure plan/session gate
- Dashboard private session gate
- Settings private session gate

## Safety

- Secure gates still hide private/premium content until verification completes.
- Light and Dark backgrounds are supported.
- Reduced-motion preference disables animation.
- No route, Auth, payment, plan, backend or environment behavior was changed.
