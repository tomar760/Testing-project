# BanaoCV — Real AI Editor Integration v7

## Browser features wired

```text
Hindi/Hinglish input → POST /api/ai/hindi-to-resume → editable resume data
AI score button → POST /api/ai/score → score ring, breakdown and tips
JD Match → POST /api/ai/jd-match → match/missing keywords and summary hint
Cover Letter → POST /api/ai/cover-letter → editable generated text
```

## Local test

1. Run backend with `AI_PROVIDER=nvidia` and a valid NVIDIA test model/key.
2. Serve frontend at port 5500.
3. Login using real BanaoCV account.
4. Open a saved resume in editor.
5. Test each AI action once.

## Current limits

Backend retains its general AI 30/hour limiter. Plan-aware free/Premium/Pro credit enforcement is the next payment/entitlement module, after Razorpay test integration.
