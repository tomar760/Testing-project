# BanaoCV — Backend Setup Checklist

The backend foundation is ready in `backend/`. No real secret has been added to the project.

## What you need to create / provide when ready

- [ ] **Supabase project** — Project URL, anonymous key and **service-role key**
- [ ] Run `backend/schema.sql` once in Supabase SQL Editor
- [ ] Supabase Email Auth enabled; configure email confirmation / OTP template
- [ ] **OpenAI API key** for AI resume, score, JD Match and cover letter
- [ ] **Razorpay** test keys first, then live keys when launching
- [ ] Optional Cloudinary keys only if users will upload profile photos
- [ ] Final frontend URLs for local, Vercel preview and production domain
- [ ] A long random JWT secret (32+ characters)

## Local run

```bash
cd backend
cp .env.example .env
# Put real values only inside .env; do not commit it.
npm install
npm run check
npm run dev
```

Then open:

```text
http://localhost:5000/api/health
```

## Next coding delivery

After setup values are ready, frontend will be connected in this order:

1. Login/signup/token storage
2. Selected template → create real resume record
3. Editor autosave + resume reopening
4. Dashboard: recently edited / incomplete resume + Continue Editing
5. AI tools
6. Razorpay and plan gating
