# BanaoCV Employer Portal — Phase 4F: Job Detail & Saved Jobs

## Why this phase

The verified employer marketplace now has a complete application, safety and notification flow. Phase 4F improves candidate decision-making without introducing scraped/fake jobs or automatic applications:

```text
Public approved Job Board
→ Shareable full Job Detail page
→ Candidate manually chooses Apply, Save or Report
→ Private Saved Jobs shortlist
```

## New pages

| Page | Animated background | Purpose |
|---|---|---|
| `job.html?id=<published-job-id>` | Gateway Field | Full approved job/company detail, manual resume-selected apply, save and report actions |
| `saved-jobs.html` | Bookmark Orbit | Current user's private saved opportunities and remove action |

Both pages are responsive and use the shared persistent Dark/Light theme system.

## Safety and privacy rules

- `job.html` returns content only for a currently published job from an approved company.
- A candidate can save only a currently public, approved, non-expired job.
- Saved Jobs are private to the authenticated user.
- If a job later becomes paused, rejected, expired or its company loses approved status, the saved row remains but full private/public job data is not exposed. The candidate sees only **Opportunity unavailable** and can remove the saved row.
- Save is not apply. Applying still requires the user to select their own BanaoCV resume and submit manually.
- Report action continues to use the private Trust & Safety route.

## APIs

All saved-job routes require the BanaoCV session token.

```text
GET    /api/jobs/saved
POST   /api/jobs/:id/save
DELETE /api/jobs/:id/save
```

Existing public detail route:

```text
GET /api/jobs/:id
```

## Database migration

Run after migration 012:

```text
backend/migrations/013_candidate_saved_jobs.sql
```

Expected result:

```text
Success. No rows returned
```

## Explicit non-features

- No automatic application
- No scraped / imported third-party jobs
- No fake job data
- No candidate fee workflow
- No visibility of a user's saved job list to employer, other candidates or public visitors
