# BanaoCV — User Features & Support Migration

Run `backend/migrations/001_user_features_and_support.sql` once in Supabase SQL Editor before deploying settings/support live APIs.

It adds:

```text
profiles: phone, location, career title, language, goal, notifications, role, AI credit balance
support_tickets: user support ticket table + index + RLS
```

After migration, deploy backend and frontend updates. Never run this in a browser; use Supabase SQL Editor.
