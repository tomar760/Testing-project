# Templates Mobile Dark Contrast & Dashboard Resume Actions — V60

## Templates mobile Dark mode

- Dark filter panel now has true dark surface, readable label/pill/search contrast and active-state visibility.
- Template card metadata/footer/title/sample note/action all receive page-specific Dark-mode contrast rather than relying on generic global card styles.
- Phone filters use a compact three-column grid with full-width search, readable touch targets and stable spacing.
- Template cards use mobile-safe card/footer spacing and no horizontal overflow.

## Fixed controls on phone

- Global theme button is compact/mobile-safe.
- Floating Guide launcher is reduced to compact icon form at bottom safe area so it no longer visually dominates template content.

## Dashboard resume actions

- Edit/Delete controls now share responsive compact premium chip styling on phone/tablet/laptop/desktop.
- Actions have stable height, consistent gap, non-clipped labels and correct grid placement on normal, featured and locked resume rows.

No API, security, loader, AI provider, route, migration or generated image change.
