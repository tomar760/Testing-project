# BanaoCV Employer Portal — Phase 4E: Private In-App Notifications

## Purpose

Phase 4E adds a private in-app notification centre for real BanaoCV workflow events. It deliberately avoids automatic external email/WhatsApp delivery until the owner separately approves a delivery and consent policy.

## Events covered

| Trigger | Recipient | Private notification |
|---|---|---|
| Candidate applies through an approved BanaoCV job | Active members of that employer organization | **New applicant** with a link to the employer applicant pipeline |
| Employer changes an applicant status | The applying candidate | **Application update** with a link to the candidate Application Tracker |
| Candidate submits a Trust & Safety report | Active Super Admin accounts | **Trust & Safety report** with a link to Admin → Trust & Safety queue |

Notifications are not public, do not contain passwords/OTP/reset links/bank/card data, and do not expose candidate details beyond the consented employer application pipeline.

## New private page

```text
notifications.html
```

The page uses a dedicated **Pulse Loom** animated background. It provides:

- Current user's most recent notifications only
- Unread count
- Per-notification read action
- Mark all read action
- Safe contextual open links

The link is added to the Job Board, Employer pages, desktop Dashboard sidebar and Admin sidebar.

## API

All routes require a BanaoCV session token and return/update only the current user's rows.

```text
GET   /api/notifications
PATCH /api/notifications/:id/read
PATCH /api/notifications/read-all
```

## Database migration

Run after `011_employer_trust_and_safety.sql`:

```text
backend/migrations/012_in_app_notifications.sql
```

Expected SQL Editor result:

```text
Success. No rows returned
```

## Reliability and safety

- The event-notification helper is fail-safe. A notification-table issue is logged server-side but never cancels a completed candidate application, employer status update or safety report.
- Table RLS is enabled with no direct browser table policies. Authenticated backend API routes mediate reads and state changes.
- This phase does **not** alter BanaoCV email/password login, Google login, Razorpay, plans, receipt generation or the frozen NVIDIA configuration.
- This phase does **not** send automatic email, WhatsApp or push notifications. Those require separate owner approval for user consent, delivery frequency and opt-out handling.
