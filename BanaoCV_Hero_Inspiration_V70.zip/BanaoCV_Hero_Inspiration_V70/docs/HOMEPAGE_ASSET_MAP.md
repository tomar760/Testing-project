# BanaoCV Homepage — Image Asset Map

All long-homepage visuals live in **`assets/home/`** relative to `index.html`.
Replace an image with another image using the **same filename** to avoid changing any code. JPEG is preferred; use at least **1024 × 1536 px** for these vertical crops.

| Image file | Appears in | Placement / visual brief | Current state |
|---|---|---|---|
| `assets/home/image1-hero-career.jpg` | Homepage — “Aapka career co-pilot” section, after hero | Professional at laptop with a resume/AI visual; subject ideally right-weighted to keep text separate | AI-generated and placed |
| `assets/home/image2-ai-guidance.jpg` | Homepage — “AI-powered guidance” section | Job seeker using a laptop; subtle AI/document imagery; warm, trustworthy | AI-generated and placed |
| `assets/home/image3-job-board.jpg` | Homepage — Smart Job Board card | Person browsing job opportunities on phone/tablet; avoid readable brand logos or text | AI-generated and placed |
| `assets/home/image4-recruiter-match.jpg` | Homepage — Recruiter Match card | Candidate/profile connected to opportunities or recruiters by elegant lines | AI-generated and placed |
| `assets/home/image5-career-coach.jpg` | Homepage — Career Guidance section | Friendly one-to-one mentor and job seeker conversation | AI-generated and placed |
| `assets/home/image6-success-community.jpg` | Homepage — BanaoCV Community CTA near the bottom | Diverse Indian young professionals celebrating career success | AI-generated and placed |
| `assets/aditya-tomar-profile.jpg` | Homepage hero resume mockup | Square professional profile headshot used only for the sample Aditya Tomar resume | AI-generated and placed |

## Replacement rules
1. Keep the same **folder + filename**.
2. Use clear, well-lit, premium imagery. Avoid embedded text, watermarks and third-party company logos.
3. Keep the subject near the center/right for `image1` and `image2`; the UI crops images using `object-fit: cover`.
4. If you supply another aspect ratio, use at least 1000 px on the shortest edge so mobile crops stay sharp.
5. The homepage works without external image URLs—the files are intentionally local for Arena previews and deployment reliability.
