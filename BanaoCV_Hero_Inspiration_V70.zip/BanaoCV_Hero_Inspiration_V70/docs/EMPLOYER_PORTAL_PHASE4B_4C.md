# BanaoCV — Employer Portal Phase 4B + 4C

## Phase 4B — Moderated Job Posting

### Employer workflow

```text
Approved employer
→ Create job draft
→ Save draft OR Submit for Admin review
→ Super Admin review
→ Published / Rejected / Paused / Expired
→ Only Published jobs appear publicly
```

### Job fields

- Title
- Location
- Employment type
- Experience level
- Salary range
- Skills
- Description
- Apply deadline

### Admin moderation

Admin → Jobs Review shows company, job, deadline, details, review note and status.

Super Admin can set:

```text
Draft
Pending Review
Published
Paused
Rejected
Expired
```

No job is public until `Published`.

## Phase 4C — Candidate Apply & Employer Applicant Pipeline

### Candidate workflow

```text
Public Job Board
→ Open approved job
→ Login if needed
→ Choose owned BanaoCV resume
→ Confirm application
→ Employer receives submission
→ Candidate Application Tracker entry created
```

### Employer applicant workflow

```text
Employer Applicants
→ Choose published job
→ View candidate name / role / chosen resume
→ View selected resume content
→ Update status
```

Employer statuses:

```text
Received
Shortlisted
Interview
Offer
Rejected
```

### Candidate tracker synchronization

| Employer status | Candidate tracker result |
|---|---|
| Submitted | Applied |
| Shortlisted | Applied + timeline activity note |
| Interview | Interview |
| Offer | Offer |
| Rejected | Rejected |

## Security rules

- Candidate can apply only with a resume they own.
- Candidate can apply only once per job.
- Employer sees resume only after candidate consent/application.
- Employer can access only applicants for jobs in their own approved organization.
- Public API shows only `Published` jobs from `Approved` companies.
- No automatic application submission.
- No job scraping/fake jobs.
- Candidate fee demand remains prohibited and will be covered by Trust & Safety Phase 4D.

## Migration

Run after migration 009:

```text
backend/migrations/010_employer_jobs_and_applicant_pipeline.sql
```

Expected:

```text
Success. No rows returned
```

## Browser test

1. Create/approve employer in Phase 4A.
2. Employer → Job Posts → create a job → submit review.
3. Super Admin → Jobs Review → publish job.
4. Public `jobs.html` → confirm published job visible.
5. Job seeker logs in, selects resume and applies.
6. Employer → Applicants → update Submitted/Shortlisted/Interview/Offer/Rejected.
7. Candidate → Application Tracker → confirm status/timeline update.
