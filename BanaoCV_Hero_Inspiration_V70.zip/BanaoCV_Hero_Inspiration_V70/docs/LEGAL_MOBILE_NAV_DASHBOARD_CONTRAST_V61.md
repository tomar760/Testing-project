# Legal Mobile Navigation & Dashboard Contrast — V61

## Dashboard profile completion

- Added page-specific Light mode opaque profile card, dark readable text, visible missing-field chips, stronger progress track and readable Complete Profile button.
- Added equivalent explicit Dark mode card/text/chip/button contrast.

## Legal pages mobile navigation

Applies to:

```text
terms.html
refund.html
privacy.html
```

- Section navigator is sticky below mobile header.
- Users can tap section pills at any point while reading; they do not need to return to the page top.
- Horizontal scrolling section pills have compact touch targets and Light/Dark contrast.
- Target sections use mobile scroll offset so headings are not hidden under the sticky navigator.

No legal content, provider, security, route, migration or generated image change.
