# BanaoCV — Public Production Cleanup

## Included in v12

- Homepage Career Guidance CTA → support page
- Homepage final CTA → editor start
- Template language updated to 24+ designs
- Refund wording aligned away from unconfirmed 7-day claim
- Footer/about/contact/career links no longer use `#`
- Added BanaoCV Career Vault differentiator section
- Dashboard sidebar/mobile navigation links wired
- Shared persistent theme toggle (`js/theme.js`) uses localStorage across all pages
- Official supplied PNG logos injected where brand containers exist (`js/brand.js`)
- Support email standardised to `supportbanaocv@gmail.com`

## Theme behavior

A user changes theme once from the fixed global BanaoCV toggle. The setting persists in localStorage across pages until the user changes it again. Legacy page-local theme buttons are hidden.

## Manual QA after deploy

Test every navigation button in header/sidebar/footer/mobile tabs plus dark/light text contrast in each major page.
