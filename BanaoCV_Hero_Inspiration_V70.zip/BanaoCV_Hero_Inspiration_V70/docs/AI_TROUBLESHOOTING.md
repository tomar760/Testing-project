# BanaoCV — NVIDIA AI Troubleshooting

## First rule

Use one NVIDIA key only. Never paste it into chat, GitHub, frontend code or screenshots.

## Browser-first test

After deployment, test from a normal logged-in editor:

1. Click one AI feature once.
2. Wait for response/error.
3. Do not spam buttons or start multiple requests.

The backend now uses direct HTTPS fetch to:

```text
https://integrate.api.nvidia.com/v1/chat/completions
```

This avoids the earlier Node OpenAI-client connection path.

## Safe error meanings

| Browser/server error | Meaning / action |
|---|---|
| NVIDIA AI key not configured | Add private `NVIDIA_API_KEY` in Render backend Environment |
| NVIDIA model available nahi hai | Confirm exact model slug in NVIDIA Build catalogue and update `NVIDIA_MODEL` privately |
| NVIDIA free usage limit/queue active | Wait and retry one request later; never rotate keys |
| NVIDIA AI response timeout | Free endpoint is busy; wait and retry later |
| AI returned invalid JSON | Model responded but did not follow structured JSON; adjust prompt/model later |

## Local diagnostic

Use the existing Windows file only if needed:

```text
TEST_NVIDIA_AI.bat
```

It prints provider/base/model/status/message, never the key.

## Future OpenAI switch

Keep OpenAI only as a private future placeholder:

```env
AI_PROVIDER=openai
OPENAI_API_KEY=your-private-openai-key
OPENAI_MODEL=gpt-4o-mini
```

Do not switch until the owner explicitly wants paid/provider-backed AI.
