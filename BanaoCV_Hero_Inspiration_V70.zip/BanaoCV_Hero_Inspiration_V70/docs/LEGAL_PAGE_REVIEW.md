# BanaoCV — Legal / Trust Page Review Checklist

The UI pages `privacy.html`, `terms.html` and `refund.html` are production-ready layouts with bilingual summary + detailed English policy drafts. **They must be reviewed and finalised by the BanaoCV business owner or qualified legal professional before launch.**

Before publishing, replace or confirm:

- Registered legal entity name and business address
- Support and grievance contact details
- Governing law / jurisdiction
- Exact refund window, eligibility, exclusions and cancellation treatment
- Subscription renewal/billing details if Pro becomes recurring
- Data retention period and deletion process
- Any third-party processor list required by applicable law
- Effective date and final policy version

New public support pages:

```text
pricing.html
privacy.html
terms.html
refund.html
support.html
404.html
```
