# BanaoCV — Razorpay Browser Integration v9

## Browser flow

```text
Logged-in user clicks Premium / Pro
→ frontend POST /api/payment/create-order
→ server creates Razorpay order with server-owned plan/amount
→ Razorpay Test checkout opens
→ browser receives Razorpay response
→ frontend POST /api/payment/verify
→ backend verifies HMAC + fetches Razorpay order
→ Supabase payment record + profile plan update
→ success UI
```

## Test prerequisites

- `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` are test-mode values in backend `.env`.
- User must be logged in through BanaoCV UI before opening checkout.
- Use Razorpay official test payment methods only; never use a real card in Test Mode.

## Security

- Browser never receives Razorpay secret.
- Plan amount is checked from Razorpay order notes/server config, not trusted from browser.
- Promo input UI is informational until server-side promo quote/redeem tables are added.
