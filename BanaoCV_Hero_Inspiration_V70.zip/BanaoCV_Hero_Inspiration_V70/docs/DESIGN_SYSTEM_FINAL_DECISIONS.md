# BanaoCV — Final Design System Decisions

This document records the owner-approved decisions after reviewing `DESIGN-SYSTEM.md` against the current production code.

## Typography

| Element | Final font |
|---|---|
| Major headings / display text | Sora 700/800 |
| Buttons / navigation / important labels | Sora 700/800 |
| Logo | Official BanaoCV image artwork |
| Body copy / forms / tables / helper text | Hind 400/500/600/700 |

## Core palette

| Token | Value | Usage |
|---|---|---|
| Emerald | `#0E6B4F` | Primary actions/links/signals |
| Emerald Dark | `#0A5240` | Hover/deep accents |
| Emerald Deep | `#0B2E22` | Dark sections/sidebar/chrome |
| Amber | `#E8A33D` | Primary CTA/highlight |
| Amber Dark | `#C9862A` | Amber hover/text accent |
| Cobalt | `#274DE0` | AI-related / limited analytics accent only |
| Mint | `#2FBF71` | Success/progress/visible Dark-mode signals |
| Danger | `#C0392B` | Destructive warning/error only |
| Light background | `#FBF8F0` | Light theme base |
| Dark background | `#0F1512` | Dark theme base |

## Approved preservation rule

Current unique page backgrounds are preserved. Do **not** replace them with old reference motifs merely because an earlier document lists a different idea.

Examples preserved:

- Homepage: Drifting Grid + career signal visuals
- Dashboard: Career Home / arch/slab visual system
- Login: Career Passport / Seal-style visual system
- Settings: Identity Weave
- Application Tracker: CSS Career Signal Field
- Admin: Command signal/data visual system
- 404: Route Recalculation

## Contrast rule

Every page must pass Dark and Light rendered QA at phone, tablet and laptop widths before being called complete. Sora/Hind typography must not compromise text readability.

## Refund rule

Do not add a public 7-day full refund guarantee until the business owner finalizes and approves that commercial/legal policy.
