# Loader & Dashboard Mobile Stability — V59

## Loader

The shared text-free loader now releases shortly after DOM readiness instead of waiting for full `window.load`. This avoids waiting on slow images, fonts or CDN resources.

Secure pages remain safe because Dashboard, Settings and Premium Editor retain their independent private-content/session/plan gates until verified data checks complete.

## Dashboard mobile Chrome stability

- Dashboard no longer updates its CSS viewport value for normal Chrome resize/address-bar events.
- `--vh` refreshes only after orientation change.
- Mobile Dashboard shell uses stable `100svh` rather than a changing dynamic viewport height.
- Hero/profile/journey/stat cards are constrained to mobile width; horizontal overflow and regular reflow/jump are reduced.

No routes, account data, AI, plan/security behavior or generated image assets changed.
