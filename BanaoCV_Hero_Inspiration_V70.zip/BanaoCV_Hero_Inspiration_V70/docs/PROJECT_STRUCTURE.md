# BanaoCV — Final GitHub Project Structure

This is the clean, final structure used in the GitHub-ready project ZIP. It includes only approved/current source files, final generated assets, backend foundation and working documentation. It intentionally excludes browser previews, temporary backups, old flattened backend files, ZIP files, secrets and `node_modules`.

```text
BanaoCV/
├── README.md                         # Project overview, local setup and status
├── .gitignore                        # Keeps secrets/dependencies out of Git
├── frontend/                         # Static public/user/admin product UI
│   ├── index.html                    # Long-form public homepage
│   ├── login.html                    # Login, signup, OTP, Google sign-in UI
│   ├── dashboard.html                # User Career Home / saved draft UI
│   ├── templates.html                # Template Atelier + Premium Collection
│   ├── editor.html                   # Free / normal Resume Studio
│   ├── premium-editor.html           # Dedicated Premium / Pro Studio route
│   ├── pricing.html                  # Free, Premium ₹79 launch, Pro plans
│   ├── settings.html                 # User profile, security, billing, privacy controls
│   ├── support.html                  # Help, support form UI and FAQ
│   ├── privacy.html                  # Privacy Policy draft
│   ├── terms.html                    # Terms of Service draft
│   ├── refund.html                   # Refund & Cancellation Policy draft
│   ├── 404.html                      # Branded page-not-found page
│   ├── admin.html                    # Admin Command Centre UI
│   ├── js/
│   │   ├── api.js                   # Shared browser API client / JWT session helper
│   │   ├── theme.js                 # One persistent global dark/light toggle
│   │   └── brand.js                 # Uses supplied official brand PNG artwork
│   └── assets/
│       ├── brand/
│       │   ├── banaocv-logo-outline.png  # Official light/outline brand artwork
│       │   └── banaocv-logo-solid.png    # Official solid/dark brand artwork
│       ├── profiles/
│       │   └── aditya-tomar-profile.jpg  # AI-generated hero/resume mock portrait
│       └── home/
│           ├── image1-hero-career.jpg
│           ├── image2-ai-guidance.jpg
│           ├── image3-job-board.jpg
│           ├── image4-recruiter-match.jpg
│           ├── image5-career-coach.jpg
│           └── image6-success-community.jpg
│
├── backend/                          # Express API (deploy separately)
│   ├── package.json                  # Node dependencies / npm scripts
│   ├── server.js                     # Express server and API route mounting
│   ├── .env.example                  # Environment variable template; no secrets
│   ├── schema.sql                    # Supabase tables, RLS, indexes and triggers
│   ├── README.md                     # Backend setup/API endpoint docs
│   ├── config/
│   │   ├── supabase.js               # Supabase backend clients
│   │   ├── openai.js                 # OpenAI configuration
│   │   └── cloudinary.js             # Future optional upload configuration
│   ├── middleware/
│   │   ├── auth.js                   # JWT bearer-token validation
│   │   └── rateLimit.js              # API/auth/AI rate limits
│   ├── routes/
│   │   ├── auth.js                   # Signup/login/OTP/reset/me routes
│   │   ├── resume.js                 # Resume CRUD/autosave routes
│   │   ├── ai.js                     # Resume AI routes
│   │   └── payment.js                # Razorpay order/verification routes
│   └── controllers/
│       ├── authController.js
│       ├── resumeController.js
│       ├── aiController.js
│       └── paymentController.js
│
└── docs/                             # Decisions, setup and product documents
    ├── PROJECT_NOTES.md              # Living project decision/change log
    ├── IMPLEMENTATION_STATUS_AND_NEXT_STEPS.md # Verified status + ordered remaining work
    ├── MASTER_HANDOFF_PROMPT.md       # Complete future-agent/project continuation prompt
    ├── PROJECT_STRUCTURE.md          # This final structure map
    ├── BACKEND_SETUP_CHECKLIST.md    # Supabase/OpenAI/Razorpay setup steps
    ├── HOMEPAGE_ASSET_MAP.md         # Homepage image placement/replacement guide
    ├── ASSETS_STRUCTURE.md            # Complete logo/image folder and usage guide
    ├── LEGAL_PAGE_REVIEW.md          # Legal pages finalisation checklist
    ├── COST_AND_AI_PLAN.md           # Cost, AI provider and quota strategy
    ├── AI_PROVIDER_SETUP.md           # NVIDIA test provider and production AI handoff
    ├── AI_TROUBLESHOOTING.md          # One-click NVIDIA model/timeout diagnosis
    ├── AUTH_DASHBOARD_INTEGRATION.md  # Real auth/dashboard browser integration guide
    ├── EDITOR_AUTOSAVE_INTEGRATION.md # Real editor draft/autosave browser integration
    ├── AI_EDITOR_INTEGRATION.md       # Real NVIDIA AI editor action guide
    ├── RAZORPAY_BROWSER_INTEGRATION.md# Real Razorpay Test Mode checkout flow
    ├── USER_PRODUCT_FEATURES_MIGRATION.md # Settings/support/profile migration instructions
    ├── PUBLIC_PRODUCTION_CLEANUP.md # Homepage/nav/theme/logo/support cleanup
    ├── AUTH_RECOVERY_FIX.md          # Reset-password and public-support behavior
    ├── PRICING_AND_PROMO_STRATEGY.md # ₹79 launch / ₹99 regular / Pro strategy
    ├── PREMIUM_TEMPLATE_COLLECTION.md# Premium template catalogue rules
    └── PREMIUM_ACCESS_GUARD.md       # Required server-side Premium access guard
```

## Frontend navigation flow

```text
index.html
  ├── login.html
  ├── templates.html
  │     ├── editor.html              (Free templates)
  │     └── premium-editor.html      (Premium templates; backend guard later)
  ├── dashboard.html
  │     └── settings.html
  ├── pricing.html
  ├── support.html
  └── privacy.html / terms.html / refund.html
```

## Important deployment note

- `frontend/` is static and can deploy to a static host.
- `backend/` is a separate Express service and needs its own host/runtime.
- Put live secrets only in `backend/.env` locally or deployment environment variables. Never commit `.env`.
- Current UI is final/approved. Real auth, database, payment, role guard, autosave and promo enforcement are the next backend-integration phase.
