# BanaoCV — Real Google Browser Sign-In

## What is implemented

The existing Supabase Google provider is now connected to the BanaoCV browser session:

```text
Login Google button
→ BanaoCV backend asks Supabase for Google OAuth URL
→ Google account consent
→ Supabase returns to banaocv.in/login.html?oauth=google
→ Browser sends short-lived Supabase session tokens to BanaoCV backend over HTTPS
→ Backend validates the Google session and issues the same BanaoCV JWT used by email login
→ Dashboard
```

Email/password login, signup OTP and password reset are not changed.

## Security model

- Google Client Secret stays only in Supabase Google provider settings.
- Supabase service-role key stays only in backend/Render.
- Browser receives no service key, Google Client Secret or API credential.
- BanaoCV backend accepts a Google callback only after validating the provided Supabase session and Google identity.
- The normal BanaoCV JWT/session is issued only after that validation.

## Required production configuration

The prior provider configuration should already exist:

- Google Cloud Authorized redirect URI:
  `https://apgunutxfbxbfyeimjnx.supabase.co/auth/v1/callback`
- Google Cloud Authorized JavaScript origin:
  `https://banaocv.in`
- Supabase Google provider: enabled with the private Client ID/Secret.
- Supabase redirect allow-list: includes `https://banaocv.in/**`.

Add this **non-secret** Render backend Environment value after code deployment:

```text
GOOGLE_OAUTH_REDIRECT_URL=https://banaocv.in/login.html?oauth=google
```

No Google Client Secret goes in Render, GitHub or chat.

## Browser test

1. Wait for frontend and backend deployments to be Live.
2. Use an Incognito/private browser window.
3. Open `https://banaocv.in/login.html`.
4. Click **Google Se Continue Karo**.
5. Select the Google account and complete consent.
6. Expected: return to BanaoCV, then Dashboard opens with the Google account email/name.
7. Refresh Dashboard; the BanaoCV session should remain valid.
8. Log out and use email/password login separately to confirm existing Auth remains unaffected.

Do not screenshot or share Google tokens, account passwords, Client Secret, Supabase keys or browser callback URLs with tokens.
