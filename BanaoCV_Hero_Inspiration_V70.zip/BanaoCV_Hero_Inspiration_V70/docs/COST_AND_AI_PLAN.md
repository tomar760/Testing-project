# BanaoCV — Minimum Cost & AI Provider Plan

**Prepared:** 16 July 2026 (India)  
**Important:** Provider pricing, exchange rates and free-tier rules can change. Confirm final pricing in each provider dashboard before launch.

## Recommended deployment by stage

| Stage | Frontend | Backend | Database/Auth | AI | Estimated fixed cost |
|---|---|---|---|---|---|
| Local development | Local browser/server | Local Node.js | Supabase Free | NVIDIA Developer API for testing only | ₹0/month |
| Private beta | Render static site (free) | Render Free / Railway trial | Supabase Free | Small paid budget or test-only NVIDIA | ₹0–₹1,000/month + domain |
| Public beta | Render static site (free) | Render Starter ($7) or Railway Hobby ($5) | Supabase Free (with inactivity caveat) | Paid API budget | approx. ₹800–₹2,000/month + AI usage |
| Reliable commercial launch | Render Starter ($7) | Render Starter ($7) or Railway Hobby ($5) | Supabase Pro ($25) | Paid provider with spending cap | approx. ₹3,500–₹5,500/month + AI usage + payment fees |

> USD estimates use roughly ₹96/USD around 16 July 2026. Card/GST/tax treatment can change the final INR bill.

## Fixed-cost detail

- **Supabase Free:** ₹0; useful for development/beta. It includes 500 MB database, 50,000 MAUs and 1 GB storage, but a free project can pause after one week of inactivity.
- **Supabase Pro:** $25/month, roughly ₹2,400 before card/tax effects; recommended before taking real customer payments because it does not have the inactivity-pause limitation and includes backups.
- **Render static frontend:** free for the static HTML site.
- **Render backend:** Starter is $7/month, roughly ₹675 before card/tax effects. Use Free only for demos because cold starts/sleep behaviour are not suitable for a polished customer product.
- **Railway alternative:** Hobby is $5/month, roughly ₹480, with $5 included resource usage. It is a good low-cost backend alternative.
- **Domain:** `.in` is usually about ₹500–₹900/year, so roughly ₹40–₹75/month when spread over the year. Check the renewal price, not just a first-year offer.
- **Google OAuth:** no direct per-login platform cost in the normal setup.
- **Cloudinary:** optional; defer until real profile-photo uploads are required.

## Razorpay cost

Standard domestic Razorpay transactions are generally **2% + 18% GST on that fee**, which is an effective **2.36%** on the transaction amount. There is normally no setup fee or AMC on the standard plan.

| Customer pays | Approx. Razorpay fee | Approx. received before your own taxes/expenses |
|---:|---:|---:|
| ₹99 | ₹2.34 | ₹96.66 |
| ₹299 | ₹7.06 | ₹291.94 |
| ₹699 | ₹16.50 | ₹682.50 |

International cards, EMI and premium methods can cost more. GST invoice/accounting treatment should be confirmed with an accountant.

## NVIDIA NIM free API — correct use

- NVIDIA Developer Program/NIM free endpoint access is suitable for **local development, prototyping, testing and benchmarking**.
- NVIDIA’s official FAQ says serving real end users or business transactions counts as production use and requires NVIDIA AI Enterprise or another authorised production route.
- Therefore: **do not base a live paid BanaoCV launch on the free NVIDIA developer endpoints.**
- One NVIDIA test key is enough for our local/staging benchmark. It can help us compare model quality before selecting the live provider.

## Multiple free NVIDIA keys

Do **not** rotate 5–6 free keys to bypass quota/credit/rate limits. That can violate provider terms and can cause account/key suspension. We will not design the production system around quota evasion.

What we *can* build safely:

1. One authorised primary paid provider/model.
2. A legitimate secondary provider/model as a failover for outages/errors.
3. Exponential backoff for 429/rate-limit responses.
4. Per-user AI quotas and a hard monthly spending cap.
5. Logging so admin can see AI usage and cost.

If multiple keys belong to permitted paid accounts/workspaces and their terms explicitly allow it, they can be used for reliability—but not as a way to evade a free tier.

## Low-cost AI launch plan

### Development now
- Test with **one** NVIDIA free key only.
- Benchmark resume generation, JD Match and cover letter quality.
- No real customer traffic.

### Public launch
- Use a paid, production-authorised provider with a hard spend limit.
- Set product quotas:

| Plan | Suggested AI allowance |
|---|---|
| Free | 3–5 AI actions/day |
| Premium ₹79 launch offer / ₹99 regular later | 25–50 lifetime AI credits, or a clearly stated limited monthly allowance |
| Pro monthly/annual | Fair-use monthly allowance, e.g. 100–300 AI actions/month |

**Important pricing correction:** a ₹99 one-time Premium plan should not promise unlimited AI forever. It creates uncapped future cost. Keep unlimited templates/no watermark, but cap AI credits or make AI a monthly/fair-use benefit.

## Cost controls we will code

- Strict server-side AI rate limit per user and plan
- Maximum resume/JD input length
- Queue/lock duplicate AI requests
- Cache identical JD Match/score results for a short period
- Admin AI usage/cost dashboard
- Monthly provider budget alert and automatic disable/fallback policy
- Payment webhook verification before unlocking paid AI quota

## Sources checked on 16 July 2026

- NVIDIA NIM official FAQ: https://docs.api.nvidia.com/nim/docs/product
- Supabase pricing: https://supabase.com/pricing
- Render pricing: https://render.com/pricing
- Render free/static site docs: https://render.com/docs/free
- Railway pricing: https://docs.railway.com/pricing/plans
- Vercel pricing: https://vercel.com/pricing
- Razorpay pricing explanation: https://razorpay.com/blog/razorpay-payment-gateway-pricing-explained/
