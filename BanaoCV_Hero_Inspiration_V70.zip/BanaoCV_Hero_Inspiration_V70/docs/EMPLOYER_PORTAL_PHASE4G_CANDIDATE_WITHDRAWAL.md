# BanaoCV Employer Portal — Phase 4G: Candidate Application Withdrawal & Consent Controls

## Why this phase

A candidate who manually applies to a BanaoCV employer job needs a clear way to withdraw. Removing only the private tracker row would be unsafe because the employer submission and selected-resume access could remain active.

Phase 4G creates an explicit, auditable withdrawal path:

```text
Candidate clicks Withdraw in Application Tracker
→ employer submission changes to withdrawn
→ candidate tracker changes to withdrawn
→ follow-up is cleared and private timeline records withdrawal
→ employer active members receive a private withdrawal notification
→ employer candidate identity/note/resume access is redacted/revoked
→ employer cannot modify the withdrawn submission
```

## Candidate experience

In `applications.html`:

- Employer-sourced application cards show **Withdraw**, not Edit/Remove.
- Candidate sees a confirmation explaining that employer notification and resume-access revocation will happen.
- After confirmation, status becomes **Withdrawn**.
- The timeline records the withdrawal.
- Manual tracker-only applications retain their existing Edit and Remove controls.

## Employer privacy/consent handling

For a withdrawn submission in `employer-applicants.html`:

- Candidate name, email, career title, location and candidate note are redacted.
- Resume ID is removed from the API response and the resume endpoint denies access.
- Employer status controls are removed.
- Any status-update API attempt is denied.
- Employer members see a private in-app withdrawal notification without unnecessary candidate data.

## Admin visibility

Admin Application Tracker status filters/counts now include `withdrawn`, while retaining existing operational history.

## Migration

Run once after migration 013:

```text
backend/migrations/014_candidate_application_withdrawal.sql
```

The migration:

- Adds `withdrawn` to allowed tracker statuses.
- Adds `candidate_application_withdrawn` to allowed private notification types.

Expected SQL result:

```text
Success. No rows returned
```

## Safety rules

- Candidate withdrawal is limited to an authenticated candidate's own employer-sourced application.
- No automatic job applications are added.
- No candidate fee, scrape or fake job behavior is introduced.
- Notification creation is fail-safe: its failure cannot prevent the withdrawal itself.
- Core Auth, Google Sign-In, payments, receipts and frozen NVIDIA settings are untouched.
