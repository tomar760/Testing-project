# BanaoCV — AI Provider Setup (NVIDIA First)

## Current provider: NVIDIA Build / NIM

BanaoCV starts with **one** private NVIDIA development key for testing. The backend now calls NVIDIA's OpenAI-compatible Chat Completions HTTPS endpoint using native server `fetch`, avoiding the previous Node OpenAI-client connection path.

Required private Render backend values:

```env
AI_PROVIDER=nvidia
NVIDIA_API_KEY=your-private-nvapi-key
NVIDIA_BASE_URL=https://integrate.api.nvidia.com/v1
NVIDIA_MODEL=meta/llama-3.3-70b-instruct
AI_TIMEOUT_MS=45000
AI_MAX_TOKENS=1400
```

Do not send the key in chat, GitHub, a screenshot or frontend code.

## What the NVIDIA path does

```text
Editor AI action
→ authenticated BanaoCV API
→ NVIDIA HTTPS /chat/completions
→ strict JSON parsing
→ resume / score / JD match / cover-letter UI
```

If NVIDIA returns a model, key, rate-limit or timeout error, the browser gets a clear Hinglish message and does not show fake AI success.

## Groq beta provider (recommended next test)

Groq support is ready in source as an OpenAI-compatible backend provider. Render needs only:

```env
AI_PROVIDER=groq
GROQ_API_KEY=your-private-groq-api-key
```

Code defaults use:

```text
https://api.groq.com/openai/v1
llama-3.3-70b-versatile
AI_TIMEOUT_MS=45000
AI_MAX_TOKENS=1400
```

Do not share the key in chat, GitHub, screenshots or frontend files. Existing NVIDIA environment values can remain but are ignored while the provider is `groq`.

## Future OpenAI placeholder

No change is needed now. When the owner chooses OpenAI later, only private Render environment values need to be added/changed:

```env
AI_PROVIDER=openai
OPENAI_API_KEY=your-private-openai-key
OPENAI_MODEL=gpt-4o-mini
```

Do not add an OpenAI key now unless the owner explicitly chooses to switch.

## Safe testing

After deployment and adding the NVIDIA key privately to Render:

1. Open the editor with a normal logged-in account.
2. Use a short Hindi/Hinglish resume prompt.
3. Wait for one response; do not repeatedly click.
4. Test score, JD Match and cover letter only after resume draft response works.
5. Review Admin → System: NVIDIA status is `testing` until one real browser response is confirmed.

For local diagnostic only, use `TEST_NVIDIA_AI.bat`. It prints no secret key.

## Limits

- NVIDIA developer/free access is for development/testing, not unlimited public usage.
- Do not rotate multiple free keys or bypass provider quotas.
- 429/queue/timeout should show a retry-later message; do not auto-retry indefinitely.

## AI routes

```text
POST /api/ai/hindi-to-resume
POST /api/ai/score
POST /api/ai/jd-match
POST /api/ai/cover-letter
```
