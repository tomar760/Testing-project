# BanaoCV — Application Tracker Phase 2

## What Phase 2 adds

The tracker now records a private application activity timeline:

```text
Created
Status changed
Follow-up set/cleared
Application details updated
```

Users see this through the **Timeline** action on each application card.

## Follow-up logic

The backend summary calculates:

- `overdueFollowUps` — follow-up date before today, active status
- `dueTodayFollowUps` — follow-up date today, active status
- Upcoming follow-ups

Dashboard displays a compact Applied / Interview / Offer / Follow-up momentum summary. Admin → Applications shows status totals plus overdue/today follow-up counts.

## Security

- Application activity records include `user_id` and application ownership.
- User can fetch a timeline only for their own application.
- Admin receives application operations data through existing server-side Admin roles.
- No automated application submission is added.

## One-time migration

Run after migration 006:

```text
backend/migrations/007_application_timeline_and_followups.sql
```

Expected:

```text
Success. No rows returned
```

## Browser test

1. Add an application.
2. Change status from Saved to Applied or Interview.
3. Set/update follow-up date.
4. Open **Timeline** and verify events.
5. Refresh tracker; data remains.
6. Check Dashboard application summary.
7. Admin → Applications: verify counts and follow-up analytics.
