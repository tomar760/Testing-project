@echo off
setlocal
cd /d "%~dp0backend"
echo.
echo ==============================================
echo   Starting BanaoCV Backend API on port 5000
Echo ==============================================
echo.
if not exist "node_modules" (
  echo First setup: installing backend packages. Please wait...
  call npm install
)
npm run dev
pause
