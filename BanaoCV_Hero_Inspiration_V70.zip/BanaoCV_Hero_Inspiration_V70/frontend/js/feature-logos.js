/* BanaoCV final feature-logo library — owner-approved marks only.
   This file only decorates explicit [data-feature-mark] references. */
(function () {
  'use strict';

  const ASSETS = {
    activity: 'assets/brand/feature-logos/recent-activity-pulse-trail.svg',
    applications: 'assets/brand/feature-logos/application-tracker-focus-board.svg',
    snapshot: 'assets/brand/feature-logos/career-snapshot-progress-arc.svg',
    guide: 'assets/brand/feature-logos/banaocv-guide-clarity-prism.svg'
  };

  const LABELS = {
    activity: 'Recent Activity',
    applications: 'Application Tracker',
    snapshot: 'Career Snapshot',
    guide: 'BanaoCV Guide'
  };

  function addSharedStyles() {
    if (document.getElementById('bcv-feature-logo-styles')) return;
    const style = document.createElement('style');
    style.id = 'bcv-feature-logo-styles';
    style.textContent = `
      [data-feature-mark] { --feature-mark-size: 25px; }
      .bcv-feature-mark { width:var(--feature-mark-size); height:var(--feature-mark-size); flex:0 0 var(--feature-mark-size); display:inline-block; object-fit:contain; object-position:center; vertical-align:middle; }
      [data-feature-mark] > .bcv-feature-mark:first-child { margin-right:8px; }
      h1[data-feature-mark], h2[data-feature-mark], h3[data-feature-mark], h4[data-feature-mark], .bcv-feature-mark-title { display:flex; align-items:center; gap:8px; }
      h1[data-feature-mark] > .bcv-feature-mark:first-child, h2[data-feature-mark] > .bcv-feature-mark:first-child, h3[data-feature-mark] > .bcv-feature-mark:first-child, h4[data-feature-mark] > .bcv-feature-mark:first-child, .bcv-feature-mark-title > .bcv-feature-mark:first-child { margin-right:0; }
      a[data-feature-mark], button[data-feature-mark], span[data-feature-mark], small[data-feature-mark], b[data-feature-mark] { display:inline-flex; align-items:center; gap:7px; }
      a[data-feature-mark] > .bcv-feature-mark:first-child, button[data-feature-mark] > .bcv-feature-mark:first-child, span[data-feature-mark] > .bcv-feature-mark:first-child, small[data-feature-mark] > .bcv-feature-mark:first-child, b[data-feature-mark] > .bcv-feature-mark:first-child { margin-right:0; }
      [data-feature-mark-size="tiny"] { --feature-mark-size: 18px; }
      [data-feature-mark-size="nav"] { --feature-mark-size: 20px; }
      [data-feature-mark-size="small"] { --feature-mark-size: 23px; }
      [data-feature-mark-size="medium"] { --feature-mark-size: 30px; }
      [data-feature-mark-size="large"] { --feature-mark-size: 42px; }
      h3[data-feature-mark]::before, h2[data-feature-mark]::before { display:none !important; content:none !important; }
      @media(max-width:600px){ [data-feature-mark-size="large"]{--feature-mark-size:34px;} }
    `;
    document.head.appendChild(style);
  }

  function renderFeatureMarks() {
    addSharedStyles();
    document.querySelectorAll('[data-feature-mark]').forEach((node) => {
      const type = node.getAttribute('data-feature-mark');
      if (!ASSETS[type] || node.querySelector(':scope > .bcv-feature-mark')) return;
      const img = document.createElement('img');
      img.className = 'bcv-feature-mark';
      img.src = ASSETS[type];
      img.alt = '';
      img.setAttribute('aria-hidden', 'true');
      img.decoding = 'async';
      node.prepend(img);
      if (!node.getAttribute('aria-label') && !node.textContent.trim()) node.setAttribute('aria-label', LABELS[type]);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', renderFeatureMarks, { once: true });
  else renderFeatureMarks();

  window.BanaoCVFeatureLogos = Object.freeze({ assets: ASSETS, labels: LABELS, render: renderFeatureMarks });
}());
