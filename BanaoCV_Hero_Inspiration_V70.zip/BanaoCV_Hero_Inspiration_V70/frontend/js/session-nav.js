/* Logged-in public navigation: never show a Login CTA to an active BanaoCV session. */
(function () {
  const TOKEN_KEY = 'banaocv.session.token';
  const AUTH_PAGES = new Set(['login.html', 'reset-password.html']);

  function hasSession() {
    try { return Boolean(localStorage.getItem(TOKEN_KEY)); } catch { return false; }
  }

  function pageName() {
    return location.pathname.split('/').pop() || 'index.html';
  }

  function updateNavigation() {
    if (!hasSession() || AUTH_PAGES.has(pageName())) return;

    document.querySelectorAll('a[href^="login.html"]').forEach((link) => {
      // Contextual login/auth links become a clear route back to the real user home.
      link.href = 'dashboard.html';
      link.classList.add('bcv-session-dashboard-link');
      link.setAttribute('aria-label', 'Dashboard kholo');
      link.textContent = 'Dashboard';
    });

    const style = document.createElement('style');
    style.textContent = `
      .bcv-session-dashboard-link{white-space:nowrap!important}
      @media(max-width:860px){.bcv-session-dashboard-link{display:inline-flex!important;padding:8px 11px!important;min-height:38px!important;font-size:12px!important}}
    `;
    document.head.appendChild(style);
  }

  document.addEventListener('DOMContentLoaded', updateNavigation);
})();
