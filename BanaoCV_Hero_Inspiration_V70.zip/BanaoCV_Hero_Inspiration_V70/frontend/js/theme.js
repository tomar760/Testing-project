/* One persistent BanaoCV theme control shared by every page. Default: Dark. */
(function () {
  const KEY = 'banaocv.theme';
  const EXPLICIT_KEY = 'banaocv.theme.user-choice';
  const DEFAULT_THEME = 'dark';
  const root = document.documentElement;

  // One text-free BanaoCV loader for every page. It uses only inline SVG/CSS,
  // so no generated image asset or external loader is required.
  root.classList.add('bcv-loading');
  const bootStyle = document.createElement('style');
  bootStyle.textContent = `
    html.bcv-loading body > *:not(.bcv-page-loader):not(.premium-access-gate):not(.dashboard-private-gate):not(.settings-private-gate){visibility:hidden!important;pointer-events:none!important}
    .bcv-page-loader{position:fixed!important;inset:0!important;z-index:10000!important;display:flex!important;align-items:center!important;justify-content:center!important;background:var(--ivory,#0f1512)!important;opacity:1;transition:opacity .28s ease!important}
    .bcv-page-loader.is-leaving{opacity:0!important;pointer-events:none!important}
    .bcv-loader-scene{position:relative;width:112px;height:112px;display:grid;place-items:center;filter:drop-shadow(0 18px 26px rgba(4,29,20,.22))}
    .bcv-loader-track{position:absolute;border-radius:50%;border:1.5px solid rgba(76,210,135,.34);border-left-color:transparent;border-bottom-color:transparent;animation:bcvTrackSpin 2.4s linear infinite}
    .bcv-loader-track.one{width:106px;height:106px;animation-duration:2.8s}
    .bcv-loader-track.two{width:84px;height:84px;border-color:rgba(255,215,131,.55);border-right-color:transparent;border-top-color:transparent;animation-duration:2s;animation-direction:reverse}
    .bcv-loader-track.three{width:62px;height:62px;border-color:rgba(255,255,255,.26);border-left-color:transparent;animation-duration:1.45s}
    .bcv-loader-card{position:relative;z-index:2;width:50px;height:62px;border-radius:14px 14px 18px 14px;background:linear-gradient(145deg,#fff6df,#f2bf62);display:grid;place-items:center;color:#0b3a2a;box-shadow:inset 0 1px 0 rgba(255,255,255,.82),0 10px 20px rgba(0,0,0,.22);animation:bcvCardFloat 1.75s ease-in-out infinite}
    .bcv-loader-card::before{content:"";position:absolute;right:0;top:0;border-style:solid;border-width:0 0 14px 14px;border-color:transparent transparent rgba(14,107,79,.30) transparent;border-radius:0 11px 0 0}
    .bcv-loader-card svg{width:26px;height:26px;stroke:currentColor;fill:none;stroke-width:2.1;stroke-linecap:round;stroke-linejoin:round}
    .bcv-loader-spark{position:absolute;z-index:3;width:8px;height:8px;border-radius:50%;background:#ffd783;box-shadow:0 0 0 4px rgba(255,215,131,.12),0 0 16px rgba(255,215,131,.8);animation:bcvSparkPulse 1.55s ease-in-out infinite}
    .bcv-loader-spark.a{right:6px;top:22px}.bcv-loader-spark.b{left:10px;bottom:18px;animation-delay:.55s;background:#6fe0a2;box-shadow:0 0 0 4px rgba(111,224,162,.12),0 0 16px rgba(111,224,162,.65)}
    @keyframes bcvTrackSpin{to{transform:rotate(360deg)}}
    @keyframes bcvCardFloat{0%,100%{transform:translateY(0) rotate(-4deg)}50%{transform:translateY(-8px) rotate(4deg)}}
    @keyframes bcvSparkPulse{0%,100%{transform:scale(.72);opacity:.55}50%{transform:scale(1.25);opacity:1}}
    html[data-theme="light"] .bcv-page-loader{background:#fbf8f0!important}
    html[data-theme="dark"] .bcv-page-loader{background:#0f1512!important}
    @media(prefers-reduced-motion:reduce){.bcv-loader-track,.bcv-loader-card,.bcv-loader-spark{animation:none!important}}
    .bcv-guide-launcher{position:fixed!important;right:18px!important;bottom:22px!important;min-height:48px!important;z-index:9997!important;display:flex!important;align-items:center!important;gap:9px!important;padding:8px 12px 8px 8px!important;border:1px solid rgba(14,107,79,.18)!important;border-radius:17px!important;background:rgba(255,255,255,.94)!important;color:#0e6b4f!important;box-shadow:0 14px 30px rgba(14,40,31,.18)!important;backdrop-filter:blur(14px)!important;font-family:'Sora',sans-serif!important;font-size:11px!important;font-weight:800!important;cursor:pointer!important}.bcv-guide-launcher-mark{width:32px!important;height:32px!important;flex:0 0 32px!important;border-radius:11px!important;display:grid!important;place-items:center!important;overflow:hidden!important;line-height:0!important;background:linear-gradient(145deg,#0e6b4f,#073d2b)!important;color:#ffd783!important}.bcv-guide-launcher-mark img{width:100%!important;height:100%!important;display:block!important;object-fit:contain!important;transform:translateY(0)!important}.bcv-guide-launcher-mark svg{width:18px!important;height:18px!important;display:block!important;stroke:currentColor!important;fill:none!important;stroke-width:2!important;transform:translateY(0)!important}.bcv-guide-panel{position:fixed!important;right:18px!important;bottom:82px!important;z-index:9998!important;width:min(360px,calc(100vw - 28px))!important;display:none!important;overflow:hidden!important;border:1px solid rgba(14,107,79,.17)!important;border-radius:21px!important;background:rgba(255,255,255,.97)!important;color:#16281f!important;box-shadow:0 24px 60px rgba(14,40,31,.24)!important;backdrop-filter:blur(16px)!important}.bcv-guide-panel.open{display:block!important;animation:bcvGuideEnter .24s ease both}.bcv-guide-head{display:flex!important;align-items:center!important;gap:9px!important;padding:13px 14px!important;background:linear-gradient(135deg,#092e22,#0e6b4f)!important;color:#fff!important}.bcv-guide-head b{font-family:'Sora',sans-serif!important;font-size:12px!important}.bcv-guide-head span{display:block!important;color:#c9e4d6!important;font-size:9px!important;margin-top:2px!important}.bcv-guide-close{margin-left:auto!important;width:28px!important;height:28px!important;border-radius:9px!important;background:rgba(255,255,255,.10)!important;color:#fff!important;font-size:17px!important}.bcv-guide-messages{max-height:260px!important;overflow:auto!important;padding:12px!important;display:grid!important;gap:8px!important}.bcv-guide-message{padding:9px 10px!important;border-radius:12px!important;background:#edf5ef!important;color:#264236!important;font-size:11px!important;line-height:1.45!important}.bcv-guide-message.user{background:rgba(232,163,61,.17)!important;color:#624512!important;margin-left:28px!important}.bcv-guide-actions{display:flex!important;gap:6px!important;flex-wrap:wrap!important;margin-top:6px!important}.bcv-guide-actions a{padding:6px 7px!important;border-radius:8px!important;background:rgba(14,107,79,.09)!important;color:#0e6b4f!important;font-size:9px!important;font-weight:800!important;text-decoration:none!important}.bcv-guide-quick{display:flex!important;gap:5px!important;flex-wrap:wrap!important;padding:0 12px 9px!important}.bcv-guide-quick button{padding:6px 7px!important;border:1px solid rgba(14,107,79,.12)!important;border-radius:8px!important;background:#f6faf7!important;color:#0e6b4f!important;font-size:9px!important;font-weight:800!important}.bcv-guide-form{display:flex!important;gap:6px!important;padding:10px 12px 12px!important;border-top:1px solid rgba(14,40,31,.10)!important}.bcv-guide-form input{min-width:0!important;flex:1!important;border:1px solid rgba(14,40,31,.14)!important;border-radius:10px!important;background:#fff!important;color:#16281f!important;padding:9px!important;font:inherit!important;font-size:11px!important}.bcv-guide-form button{width:34px!important;border-radius:10px!important;background:#0e6b4f!important;color:#fff!important;font-size:15px!important}@keyframes bcvGuideEnter{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}html[data-theme="dark"] .bcv-guide-launcher,html[data-theme="dark"] .bcv-guide-panel{background:rgba(21,33,27,.96)!important;border-color:rgba(255,255,255,.13)!important;color:#f0eee6!important}.bcv-guide-panel .bcv-guide-message{background:rgba(255,255,255,.07)!important;color:#d8e5dc!important}.bcv-guide-panel .bcv-guide-message.user{background:rgba(232,163,61,.16)!important;color:#ffe0a1!important}.bcv-guide-panel .bcv-guide-quick button,.bcv-guide-panel .bcv-guide-form input{background:rgba(255,255,255,.06)!important;border-color:rgba(255,255,255,.13)!important;color:#eef4ee!important}.bcv-guide-panel .bcv-guide-actions a{background:rgba(76,210,135,.12)!important;color:#98ebbf!important}@media(max-width:700px){.bcv-guide-launcher{right:12px!important;bottom:76px!important;padding:7px!important;border-radius:14px!important}.bcv-guide-launcher>span:last-child{display:none!important}.bcv-guide-panel{right:12px!important;bottom:126px!important}.bcv-guide-panel .bcv-guide-messages{max-height:230px!important}}
  `;
  document.head.appendChild(bootStyle);

  function userChosenTheme() {
    try {
      // Older builds automatically saved "light" on first visit. That was not
      // an actual user preference, so ignore it and honour the new dark default.
      return localStorage.getItem(EXPLICIT_KEY) === '1' ? localStorage.getItem(KEY) : null;
    } catch { return null; }
  }

  function apply(theme, persistChoice = false) {
    const next = theme === 'light' ? 'light' : 'dark';
    if (root.getAttribute('data-theme') !== next) root.setAttribute('data-theme', next);
    if (persistChoice) {
      try {
        localStorage.setItem(KEY, next);
        localStorage.setItem(EXPLICIT_KEY, '1');
      } catch { /* storage unavailable */ }
    }

    const button = document.querySelector('.bcv-global-theme-toggle');
    if (button) {
      const dark = next === 'dark';
      button.setAttribute('aria-label', dark ? 'Light mode on karo' : 'Dark mode on karo');
      button.title = dark ? 'Light mode' : 'Dark mode';
      button.innerHTML = dark ? '☀' : '☾';
    }
    if (window.BanaoCVBrand?.refresh) window.BanaoCVBrand.refresh(next);
  }

  // Apply dark before page rendering unless this user explicitly selected Light.
  apply(userChosenTheme() || DEFAULT_THEME);
  window.BanaoCVTheme = { apply, current: () => root.getAttribute('data-theme') || DEFAULT_THEME };

  document.addEventListener('DOMContentLoaded', () => {
    const pageLoader = document.createElement('div');
    pageLoader.className = 'bcv-page-loader';
    pageLoader.setAttribute('aria-hidden', 'true');
    pageLoader.innerHTML = '<span class="bcv-loader-scene"><i class="bcv-loader-track one"></i><i class="bcv-loader-track two"></i><i class="bcv-loader-track three"></i><span class="bcv-loader-card"><svg viewBox="0 0 24 24"><path d="M7 3h8l3 3v15H7z"/><path d="M15 3v4h4M10 14l1.7 1.7L15.5 12"/></svg></span><i class="bcv-loader-spark a"></i><i class="bcv-loader-spark b"></i></span>';
    document.body.appendChild(pageLoader);
    const releaseLoader = () => {
      root.classList.remove('bcv-loading');
      pageLoader.classList.add('is-leaving');
      setTimeout(() => pageLoader.remove(), 320);
    };
    // Do not wait for every image/font/CDN resource; private pages keep their own secure gates.
    // This prevents a global loader from appearing stuck on slower Chrome/mobile networks.
    setTimeout(releaseLoader, 180);

    const style = document.createElement('style');
    style.textContent = `
      html[data-theme="light"]{color-scheme:light}
      html[data-theme="dark"]{color-scheme:dark}
      /* Approved core typography: Sora for display hierarchy/actions, Hind for body/UI copy. */
      body, input, select, textarea{font-family:'Hind',sans-serif!important}
      :is(h1,h2,h3,h4,h5,h6,.headline,.story-title,.section-title,.lost,.code,.auth-box h2,.lp-mid h1,.page-title h1,.hero h1,.metric b,.stat-num,.plan-card b,.application h3,.timeline-modal h2,.modal h2,.drawer h2){font-family:'Sora',sans-serif!important;font-weight:700!important;letter-spacing:-.035em!important}
      :is(button,.btn,.button,.save,.add-btn,.row-button,.danger-btn,.upload,.receipt-btn,.download,.continue-btn,.upgrade-btn,.filter,.pill-btn,.table-link,.nav a,.nav-item){font-family:'Sora',sans-serif!important;font-weight:700!important}
      .theme-toggle:not(.bcv-global-theme-toggle), .theme:not(.bcv-global-theme-toggle){display:none!important}
      .bcv-global-theme-toggle{position:fixed!important;right:18px!important;top:18px!important;z-index:9999!important;width:44px!important;height:44px!important;border-radius:14px!important;border:1px solid rgba(14,40,31,.13)!important;background:rgba(255,255,255,.94)!important;color:#0E6B4F!important;box-shadow:0 10px 24px rgba(14,40,31,.16)!important;display:grid!important;place-items:center!important;font-size:20px!important;font-family:Arial,sans-serif!important;cursor:pointer!important;backdrop-filter:blur(10px)!important}
      html[data-theme="dark"] .bcv-global-theme-toggle{background:rgba(21,33,27,.94)!important;color:#ffd783!important;border-color:rgba(255,255,255,.16)!important;box-shadow:0 10px 24px rgba(0,0,0,.35)!important}
      /* Global contrast safety net for pages that use translucent white cards or native form controls. */
      html[data-theme="dark"] :is(input,textarea,select){background-color:rgba(255,255,255,.065)!important;color:#f4f1e8!important;border-color:rgba(255,255,255,.18)!important;caret-color:#ffd783!important}
      html[data-theme="dark"] :is(input,textarea,select)::placeholder{color:#b7c2ba!important;opacity:1!important}
      html[data-theme="light"] :is(input,textarea,select){background-color:rgba(255,255,255,.9)!important;color:#16281f!important;border-color:rgba(14,40,31,.16)!important}
      html[data-theme="light"] :is(input,textarea,select)::placeholder{color:#607068!important;opacity:1!important}
      html[data-theme="dark"] :is(.profile-complete,.settings-nav,.card,.panel,.quick>a,.faq-item,.toc,.doc,.legal-card){background-color:rgba(26,36,32,.90)!important;color:var(--ink)!important;border-color:rgba(255,255,255,.13)!important}
      html[data-theme="dark"] :is(.profile-complete,.settings-nav,.card,.panel,.quick>a,.faq-item,.toc,.doc,.legal-card) :is(p,small,label){color:var(--muted)!important}
      html[data-theme="dark"] :is(.profile-complete,.settings-nav,.card,.panel,.quick>a,.faq-item,.toc,.doc,.legal-card) :is(h1,h2,h3,h4,h5,h6,b,strong,summary){color:var(--ink)!important}
      html[data-theme="light"] :is(.profile-complete,.settings-nav,.card,.panel,.quick>a,.faq-item,.toc,.doc,.legal-card){color:var(--ink)!important}
      /* Dashboard-only Claude-inspired open font treatment; no proprietary font is copied. */
      body.dashboard-claude,body.dashboard-claude input,body.dashboard-claude select,body.dashboard-claude textarea{font-family:'Manrope','Hind',sans-serif!important}
      body.dashboard-claude :is(h1,h2,h3,h4,h5,h6,.greeting h1,.panel-head h2,.stat-num,.profile-completion-copy b,.j-step span,.sidebar .nav a,.sidebar .sb-logo span){font-family:'Manrope','Hind',sans-serif!important;letter-spacing:-.028em!important}
      /* Universal responsive guard rails: layout fits the viewport; browser zoom remains user-controlled. */
      html{max-width:100%;-webkit-text-size-adjust:100%;text-size-adjust:100%}
      body{max-width:100vw!important;min-width:320px!important;overflow-x:hidden!important}
      img,video,canvas{max-width:100%!important;height:auto}
      :is(input,select,textarea){max-width:100%!important}
      @supports(min-height:100svh){body{min-height:100svh}}
      @media(max-width:820px){body{min-width:0!important}.bcv-global-theme-toggle{right:10px!important;top:10px!important;width:40px!important;height:40px!important;border-radius:12px!important;font-size:18px!important}.bcv-guide-panel{max-width:calc(100vw - 20px)!important}.bcv-guide-launcher{max-width:calc(100vw - 20px)!important}}
      @media(max-width:360px){.bcv-global-theme-toggle{width:38px!important;height:38px!important}.bcv-guide-panel{right:8px!important;bottom:116px!important;width:calc(100vw - 16px)!important}}
    `;
    document.head.appendChild(style);

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'bcv-global-theme-toggle';
    button.addEventListener('click', () => apply(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true));
    document.body.appendChild(button);
    apply(root.getAttribute('data-theme') || DEFAULT_THEME);

    // Small contextual launcher for authenticated users. Detailed chat/support flow lives on ai-guide.html.
    const currentPage = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    const guideBlocked = new Set(['login.html', 'reset-password.html', 'ai-guide.html']);
    let guideToken = '';
    try { guideToken = localStorage.getItem('banaocv.session.token') || ''; } catch { guideToken = ''; }
    if (guideToken && !guideBlocked.has(currentPage) && !document.body.classList.contains('premium-access-pending')) {
      const apiBase = () => ['localhost', '127.0.0.1'].includes(location.hostname) ? 'http://localhost:5000/api' : 'https://banaocv-api.onrender.com/api';
      const launcher = document.createElement('button');
      launcher.type = 'button';
      launcher.className = 'bcv-guide-launcher';
      launcher.innerHTML = '<span class="bcv-guide-launcher-mark"><img src="assets/brand/feature-logos/banaocv-guide-clarity-prism.svg" alt=""></span><span>Ask BanaoCV Guide</span>';
      const panel = document.createElement('section');
      panel.className = 'bcv-guide-panel';
      panel.innerHTML = '<div class="bcv-guide-head"><span class="bcv-guide-launcher-mark"><img src="assets/brand/feature-logos/banaocv-guide-clarity-prism.svg" alt=""></span><div><b>BanaoCV Guide</b><span>Website, career aur support help</span></div><button class="bcv-guide-close" aria-label="Close">×</button></div><div class="bcv-guide-messages"><div class="bcv-guide-message">Namaste! Resume, jobs, applications, settings ya support ke baare mein pucho.</div></div><div class="bcv-guide-quick"><button data-guide-quick="Mujhe is page par kya karna chahiye?">Is page ki help</button><button data-guide-quick="Mera profile kaise complete karun?">Profile help</button><button data-guide-quick="Support ticket kaise raise karun?">Support help</button></div><form class="bcv-guide-form"><input maxlength="2200" placeholder="BanaoCV Guide se pucho…"><button type="submit">↗</button></form>';
      const messages = panel.querySelector('.bcv-guide-messages');
      const input = panel.querySelector('input');
      const history = [];
      function appendGuideMessage(text, role, actions) {
        const node = document.createElement('div'); node.className = `bcv-guide-message ${role || ''}`; node.textContent = text;
        if (actions?.length) { const actionsNode = document.createElement('div'); actionsNode.className = 'bcv-guide-actions'; actions.forEach((action) => { const link = document.createElement('a'); link.href = action.href; link.textContent = action.label; actionsNode.appendChild(link); }); node.appendChild(actionsNode); }
        messages.appendChild(node); messages.scrollTop = messages.scrollHeight;
      }
      function miniGuideFallback(message) {
        const text = String(message || '').toLowerCase();
        if (/resume|cv|template|editor/.test(text)) return { reply: 'Resume banane ke liye Templates ya Resume Editor kholo.', actions: [{ label: 'Templates dekho', href: 'templates.html' }, { label: 'Resume Editor kholo', href: 'editor.html' }] };
        if (/profile|complete|photo|setting/.test(text)) return { reply: 'Profile completion ke liye Settings ya Dashboard kholo.', actions: [{ label: 'Settings kholo', href: 'settings.html' }] };
        if (/job|apply|application|tracker/.test(text)) return { reply: 'Jobs se manual apply karo aur Applications page par status track karo.', actions: [{ label: 'Jobs dekho', href: 'jobs.html' }, { label: 'Applications kholo', href: 'applications.html' }] };
        if (/support|issue|problem|ticket/.test(text)) return { reply: 'Support issue ke liye Support page kholo. Ticket submit se pehle aap confirm karoge.', actions: [{ label: 'Support kholo', href: 'support.html' }] };
        return { reply: 'Resume, profile, jobs, applications, cover letter ya support ke baare mein pucho.', actions: [{ label: 'BanaoCV Guide kholo', href: 'ai-guide.html' }] };
      }
      async function askGuide(message) {
        const text = String(message || '').trim(); if (!text) return;
        appendGuideMessage(text, 'user'); history.push({ role: 'user', text }); input.value = ''; input.disabled = true;
        try {
          const response = await fetch(`${apiBase()}/guide/chat`, { method: 'POST', headers: { Authorization: `Bearer ${guideToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ message: text, page: currentPage, history }) });
          const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || 'Guide abhi response nahi de paaya.');
          appendGuideMessage(data.reply, 'assistant', data.actions); history.push({ role: 'assistant', text: data.reply });
        } catch (error) { const fallback = miniGuideFallback(text); appendGuideMessage(fallback.reply, 'assistant', fallback.actions); history.push({ role: 'assistant', text: fallback.reply }); }
        finally { input.disabled = false; input.focus(); }
      }
      launcher.addEventListener('click', () => { panel.classList.toggle('open'); if (panel.classList.contains('open')) input.focus(); });
      panel.querySelector('.bcv-guide-close').addEventListener('click', () => panel.classList.remove('open'));
      panel.querySelector('.bcv-guide-form').addEventListener('submit', (event) => { event.preventDefault(); askGuide(input.value); });
      panel.querySelectorAll('[data-guide-quick]').forEach((quick) => quick.addEventListener('click', () => askGuide(quick.dataset.guideQuick)));
      document.body.append(launcher, panel);
    }

    // Existing hidden inline toggles may still change the theme attribute.
    new MutationObserver(() => apply(root.getAttribute('data-theme') || DEFAULT_THEME))
      .observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  });
})();
