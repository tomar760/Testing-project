/* BanaoCV payment receipt renderer. Uses server-verified payment data only. */
(function (window) {
  const planLabel = (receipt) => receipt.planLabel || String(receipt.plan || '').replaceAll('_', ' ');
  const money = (receipt) => new Intl.NumberFormat('en-IN', {
    style: 'currency', currency: receipt.currency || 'INR', maximumFractionDigits: 0,
  }).format(Number(receipt.amountInr || 0));
  const date = (value) => value ? new Date(value).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
  const escape = (value) => String(value || '—').replace(/[&<>'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));

  function element(receipt) {
    const node = document.createElement('article');
    node.style.cssText = 'position:fixed;left:-10000px;top:0;width:760px;background:#fffdf8;color:#16281f;padding:42px;font-family:Arial,sans-serif;line-height:1.45;z-index:-1';
    node.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:24px;border-bottom:2px solid #0e6b4f;padding-bottom:22px">
        <div><div style="font-size:29px;font-weight:900;color:#0e6b4f;letter-spacing:-1px">Banao<span style="color:#e8a33d">CV</span></div><div style="font-size:11px;color:#617168;letter-spacing:1.5px;font-weight:700">CAREER DOCUMENT · PAYMENT RECEIPT</div></div>
        <div style="text-align:right"><div style="font-size:11px;color:#617168;text-transform:uppercase;font-weight:700">Receipt number</div><div style="font-weight:800;color:#0e6b4f">${escape(receipt.receiptNumber)}</div><div style="display:inline-block;margin-top:8px;padding:5px 9px;border-radius:20px;background:#dff3e6;color:#117443;font-size:11px;font-weight:800">PAYMENT SUCCESSFUL</div></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:32px;padding:27px 0">
        <div><div style="font-size:11px;color:#617168;text-transform:uppercase;font-weight:700;margin-bottom:7px">Billed to</div><div style="font-size:17px;font-weight:800">${escape(receipt.customer?.name)}</div><div style="color:#516159;font-size:13px">${escape(receipt.customer?.email)}</div></div>
        <div><div style="font-size:11px;color:#617168;text-transform:uppercase;font-weight:700;margin-bottom:7px">Payment date</div><div style="font-size:14px;font-weight:700">${escape(date(receipt.paidAt))}</div><div style="color:#516159;font-size:12px">Currency: ${escape(receipt.currency || 'INR')}</div></div>
      </div>
      <div style="border:1px solid #dce7df;border-radius:16px;overflow:hidden"><div style="display:grid;grid-template-columns:1fr auto;background:#eaf5ee;padding:12px 15px;font-size:11px;font-weight:800;color:#0b3d2d;text-transform:uppercase"><span>Description</span><span>Amount</span></div><div style="display:grid;grid-template-columns:1fr auto;padding:18px 15px;gap:12px"><div><div style="font-size:16px;font-weight:800">${escape(planLabel(receipt))}</div><div style="font-size:12px;color:#617168;margin-top:3px">BanaoCV career and resume platform access</div></div><div style="font-size:20px;font-weight:900;color:#0e6b4f">${escape(money(receipt))}</div></div></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:22px;font-size:11px;color:#52625a"><div><b style="display:block;color:#26362e;margin-bottom:4px">Payment reference</b>${escape(receipt.paymentId || '—')}</div><div><b style="display:block;color:#26362e;margin-bottom:4px">Order reference</b>${escape(receipt.orderId || '—')}</div></div>
      <div style="margin-top:26px;padding-top:15px;border-top:1px solid #dce7df;display:flex;justify-content:space-between;gap:16px;font-size:10.5px;color:#617168"><span>This receipt is generated from BanaoCV's verified payment record.</span><span>Help: ${escape(receipt.issuer?.supportEmail || 'supportbanaocv@gmail.com')}</span></div>`;
    return node;
  }

  async function download(receipt) {
    const node = element(receipt);
    document.body.appendChild(node);
    const filename = `BanaoCV-Receipt-${String(receipt.receiptNumber || 'payment').replace(/[^a-z0-9-]/gi, '')}.pdf`;
    try {
      if (window.html2pdf) {
        await window.html2pdf().set({ margin: 0, filename, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2, useCORS: true }, jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' } }).from(node).save();
      } else {
        const printWindow = window.open('', '_blank', 'noopener,noreferrer');
        if (!printWindow) throw new Error('PDF window block ho gaya. Browser popup allow karo.');
        printWindow.document.write(`<!doctype html><html><head><title>${escape(filename)}</title><style>@page{size:A4;margin:0}body{margin:0}</style></head><body>${node.outerHTML}</body></html>`);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
      }
    } finally {
      node.remove();
    }
  }

  async function downloadServerPdf(path, fallbackName = 'BanaoCV-Receipt.pdf') {
    const token = window.BanaoCV?.session?.getToken?.() || '';
    const response = await fetch(`${window.BanaoCV.apiBase()}${path}`, { headers: { Authorization: `Bearer ${token}` } });
    if (!response.ok) {
      let message = 'Receipt PDF download nahi ho paya.';
      try { message = (await response.json()).error || message; } catch { /* PDF/HTML error body */ }
      throw new Error(message);
    }
    const disposition = response.headers.get('content-disposition') || '';
    const match = disposition.match(/filename="?([^";]+)"?/i);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = match?.[1] || fallbackName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  window.BanaoCVReceipt = { download, downloadServerPdf, element };
})(window);
