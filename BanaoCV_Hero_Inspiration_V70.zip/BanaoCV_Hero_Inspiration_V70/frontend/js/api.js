/* BanaoCV browser API client. It contains no secret credentials. */
(function (window) {
  const STORAGE_TOKEN = 'banaocv.session.token';
  const STORAGE_USER = 'banaocv.session.user';
  const DEFAULT_API_BASE = ['localhost', '127.0.0.1'].includes(window.location.hostname)
    ? 'http://localhost:5000/api'
    : 'https://banaocv-api.onrender.com/api';

  function apiBase() {
    return window.BANAOCV_API_BASE || localStorage.getItem('banaocv.api.base') || DEFAULT_API_BASE;
  }

  function getToken() {
    return localStorage.getItem(STORAGE_TOKEN) || '';
  }

  function getUser() {
    try { return JSON.parse(localStorage.getItem(STORAGE_USER) || 'null'); } catch { return null; }
  }

  function setSession(payload) {
    if (!payload?.token) throw new Error('Session token missing.');
    localStorage.setItem(STORAGE_TOKEN, payload.token);
    localStorage.setItem(STORAGE_USER, JSON.stringify(payload.user || {}));
  }

  function clearSession() {
    localStorage.removeItem(STORAGE_TOKEN);
    localStorage.removeItem(STORAGE_USER);
  }

  async function request(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    // FormData must keep its browser-generated multipart boundary; JSON remains the default for API bodies.
    if (options.body && !headers['Content-Type'] && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';

    let response;
    try {
      response = await fetch(`${apiBase()}${path}`, { ...options, headers });
    } catch {
      throw new Error('Server se connection nahi ho paya. Backend running hai kya?');
    }

    let data = {};
    try { data = await response.json(); } catch { /* non-JSON response */ }
    if (!response.ok) {
      if (response.status === 401) clearSession();
      throw new Error(data.error || 'Request complete nahi ho payi.');
    }
    return data;
  }

  function requireSession(nextPage) {
    if (!getToken()) {
      const next = encodeURIComponent(nextPage || `${location.pathname.split('/').pop() || 'dashboard.html'}${location.search}`);
      location.href = `login.html?next=${next}`;
      return false;
    }
    return true;
  }

  window.BanaoCV = {
    apiBase,
    request,
    session: { getToken, getUser, set: setSession, clear: clearSession },
    requireSession,
  };
})(window);
