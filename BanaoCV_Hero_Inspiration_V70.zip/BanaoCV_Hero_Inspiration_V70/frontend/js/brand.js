/* One official BanaoCV logo across light/dark UI plus browser-tab icon. */
(function () {
  const selectors = ['.logo', '.brand', '.lp-logo', '.tb-logo', '.sb-logo', '.mob-logo', '.footer-logo', '.footer-brand'];
  const LOGO = 'assets/brand/banaocv-logo-primary.png';
  const FAVICON = 'assets/brand/banaocv-favicon.png';

  function ensureFavicon() {
    let icon = document.querySelector('link[rel="icon"]');
    if (!icon) {
      icon = document.createElement('link');
      icon.rel = 'icon';
      document.head.appendChild(icon);
    }
    icon.type = 'image/png';
    icon.href = FAVICON;
  }

  function refresh() {
    document.querySelectorAll('.bcv-brand-logo').forEach((img) => { img.src = LOGO; });
  }

  function replace() {
    ensureFavicon();
    selectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((node) => {
        if (node.dataset.bcvBrandDone || !/Banao\s*CV/i.test(node.textContent || '')) return;
        node.dataset.bcvBrandDone = 'true';
        node.innerHTML = `<img class="bcv-brand-logo" src="${LOGO}" alt="BanaoCV">`;
      });
    });

    const style = document.createElement('style');
    style.textContent = `
      [data-bcv-brand-done="true"]{gap:0!important;display:flex!important;align-items:center!important;line-height:0!important}
      .bcv-brand-logo{width:158px!important;height:62px!important;object-fit:contain!important;object-position:left center!important;display:block!important}
      .sidebar .bcv-brand-logo,.sb-logo .bcv-brand-logo{width:144px!important;height:56px!important}
      .lp-logo .bcv-brand-logo,.tb-logo .bcv-brand-logo{width:154px!important;height:60px!important}
      .footer-logo .bcv-brand-logo,.footer-brand .bcv-brand-logo{width:150px!important;height:59px!important}
      @media(max-width:700px){.bcv-brand-logo{width:132px!important;height:52px!important}.sidebar .bcv-brand-logo,.sb-logo .bcv-brand-logo{width:124px!important;height:49px!important}.lp-logo .bcv-brand-logo,.tb-logo .bcv-brand-logo{width:138px!important;height:54px!important}}
    `;
    document.head.appendChild(style);
    refresh();
  }

  window.BanaoCVBrand = { refresh };
  document.addEventListener('DOMContentLoaded', replace);
})();
