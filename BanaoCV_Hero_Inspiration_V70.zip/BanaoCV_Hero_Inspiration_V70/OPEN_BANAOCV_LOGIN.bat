@echo off
start "" "http://localhost:5500/login.html"
